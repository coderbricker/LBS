// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.data;

import java.util.ArrayList;

/**
 * group members
 */
public class GroupMember {
	
	private String groupId;
	private ArrayList<Member> members = new ArrayList<Member>();
	
	/**
	 * a group member class must has groupId
	 */
	public GroupMember(String groupId) {
		this.groupId = groupId;
	}
		
	/**
	 * <p>add a member, cover the old one if cover is true</P>
	 * @param account
	 * @param nick
	 * @param role
	 * @param cover
	 */
	public void add(String account, String nick, String role, boolean cover) {
		int location = contain(account);
		if (location > -1) {
			if (cover) {
				members.get(location).nick = nick;
				members.get(location).role = role;
			}
		} else {
			members.add(new Member(account, nick, role));
		}
	}

	/**
	 * <p>add a new member, if the member exits, cover it</P>
	 * @param account
	 * @param nick
	 * @param role
	 */
	public void add(String account, String nick, String role) {
		add(account, nick, role, true);
	}
	
	/**
	 * <p></P>
	 * @param member
	 */
	public void add(Member member) {
		add(member.account, member.nick, member.role);
	}
	
	/**
	 * <p></P>
	 * @param account
	 */
	public void remove(String account) {

		int location = contain(account);
		if (location > -1) {
			members.remove(location);
		}
	}
	
	/**
	 * <p></P>
	 * @param account
	 * @return
	 */
	public Member get(String account) {
		int location = contain(account);
		if (location > -1) {
			return members.get(location);
		} else {
			return null;
		}
	}
	
	
	/**
	 * <p>get owners</P>
	 * @return
	 */
	public ArrayList<String> getOwners() {
		ArrayList<String> owners = new ArrayList<String>();
		for (int i = 0; i < members.size(); ++i) {
			if (members.get(i).role.equals("owner")) {
				owners.add(members.get(i).account);
			}
		}
		
		return owners;
	}
	
	/**
	 * <p>Whether contain this member</P>
	 * @param memberId
	 * @return the member location in members list. >-1, contain; -1: not contain
	 */
	public int contain(String memberId) {
		for (int i = 0; i < members.size(); ++i) {
			if (members.get(i).account.equals(memberId)) {
				return i;
			}
		}
		
		return -1;
	}
	

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId1) {
		this.groupId = groupId1;
	}

	public ArrayList<Member> getMembers() {
		return members;
	}

	public void setMembers(ArrayList<Member> members1) {
		this.members = members1;
	}
	
	
}
