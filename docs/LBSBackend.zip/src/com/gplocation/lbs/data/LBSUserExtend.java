// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.data;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import org.xmlpull.v1.XmlPullParser;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.Xml;

/**
 * encapsulate the information of LBS platform user
 */
public class LBSUserExtend implements Parcelable {
    private String userName;
    private String userId;
    private String userNick;
    private String vCardPhone;
    private String vCardEmail;
    private String host;
    private String userPassword;
    private String domain;
    private int port;

    public LBSUserExtend(String userName, String userId, String userNick, String vCardPhone, String vCardEmail, 
    		String host, String userPassword, String domain, int port) {
        this.userName = userName;
        this.userId = userId;
        this.userNick = userNick;
        this.vCardPhone = vCardPhone;
        this.vCardEmail = vCardEmail;
        this.host = host;
        this.userPassword = userPassword;
        this.domain = domain;
        this.port = port;

    }
    
    public LBSUserExtend(Parcel source) {
    	userName = source.readString();
    	userId = source.readString();
    	userNick = source.readString();
    	vCardPhone = source.readString();
    	vCardEmail = source.readString();
    	host = source.readString();
    	userPassword = source.readString();
    	domain = source.readString();
    	port = source.readInt();
    }
    
    

    public static LBSUser getUserFromExtend(LBSUserExtend lbsUserExtend) {
    	String email = lbsUserExtend.getvCardEmail();
    	String userId = lbsUserExtend.getUserId();
    	String nick = lbsUserExtend.getUserNick();
    	String phone = lbsUserExtend.getvCardPhone();
    	
    	return new LBSUser(userId, nick, email, phone);
    }
    
    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

      
    @Override
    public String toString() {
		return "userName =" + userName + " userId =" + userId 
				+ "userNick =" + userNick + " vCardPhone=" + vCardPhone 
				+ " vCardEmail=" + vCardEmail + " userPassword=" + userPassword 
				+ " host =" + host + " domain =" + domain
				+ "port =" + port;
    }
    
    /**
     * <p></P>
     * @param xmlStr
     * @return
     * @throws Exception
     */
    public static LBSUserExtend getLBSUser(String xmlStr) throws Exception {
        XmlPullParser parser = Xml.newPullParser();
        InputStream xmlInputStream = new ByteArrayInputStream(xmlStr.getBytes("UTF-8"));
        parser.setInput(xmlInputStream, "UTF-8");
        int event = parser.getEventType();
        String userName = "";
        String userId = "";
        String host = "";
        String userPassword = "";
        String domain = "";
        int port = 0;
        while (event != XmlPullParser.END_DOCUMENT) {
            switch (event) {
            case XmlPullParser.START_DOCUMENT:
                break;
            case XmlPullParser.START_TAG:
                if ("user-account".equals(parser.getName())) {
                    userName = parser.nextText();
                } else if ("server-ip".equals(parser.getName())) {
                    host = parser.nextText();
//                    host = Preference.BASEURL;
                } else if ("password".equals(parser.getName())) {
                    userPassword = parser.nextText();
                } else if ("domain".equals(parser.getName())) {
                    domain = parser.nextText();
                } else if ("server-port".equals(parser.getName())) {
                    port = Integer.parseInt(parser.nextText());
                }
                break;
            default:
                break;
            }
            event = parser.next();

        }
        return new LBSUserExtend(userName, userId, "", "", "", host, userPassword, domain, port);
    }
	@Override
	public int describeContents() {
		return 0;
	}
	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(userName);
		dest.writeString(userId);
		dest.writeString(userNick);
		dest.writeString(vCardPhone);
		dest.writeString(vCardEmail);
        dest.writeString(host);
        dest.writeString(userPassword);
        dest.writeString(domain);
        dest.writeInt(port);
	}
	
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getvCardPhone() {
		return vCardPhone;
	}

	public void setvCardPhone(String vCardPhone) {
		this.vCardPhone = vCardPhone;
	}

	public String getvCardEmail() {
		return vCardEmail;
	}

	public void setvCardEmail(String vCardEmail) {
		this.vCardEmail = vCardEmail;
	}

	public String getUserNick() {
		return userNick;
	}

	public void setUserNick(String userNick) {
		this.userNick = userNick;
	}

	public static final Parcelable.Creator<LBSUserExtend> CREATOR = new Parcelable.Creator<LBSUserExtend>() {

        @Override
        public LBSUserExtend createFromParcel(Parcel source) {
            return new LBSUserExtend(source);
        }

        @Override
        public LBSUserExtend[] newArray(int size) {
            return new LBSUserExtend[size];
        }
    };

}
