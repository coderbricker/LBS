package com.gplocation.lbs.client.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;

import com.gplocation.lbs.application.MainApplication;
import com.gplocation.lbs.engine.InternalXmppEngine;
import com.gplocation.lbs.manager.AuthorityManager;
import com.gplocation.lbs.manager.DBManager;
import com.gplocation.lbs.manager.ReceiveManager;
import com.gplocation.lbs.service.LBSCoreService;
import com.gplocation.lbs.utils.Constants;

public class Internal extends IInternal.Stub {

	private static final  String TAG = "Internal";
	
	private Handler xmppHandler;
	private Context context;
	private String appId;
	
	public Internal(Context context, String appId, Handler handler) {
		this.xmppHandler = handler;
		this.context = context;
		this.appId = appId;
	}
	
	
	@Override
	public void listen(IInternalListener listener, int eventType)
			throws RemoteException {
		MainApplication mainApplication = (MainApplication) ((LBSCoreService) context).getApplication();
		ReceiveManager receiveManager = mainApplication.receiveManager;
		AuthorityManager authorityManager = mainApplication.authorityManager;
		if (authorityManager.get(appId) != null) {
			receiveManager.getInternalListeners().add(listener, appId);
		}
	}

	@Override
	public void setUserMap(String user, String password, String email, String phone) throws RemoteException {
		Log.d(TAG, "setUserMap");

		Message msg = new Message();
		msg.what = InternalXmppEngine.SET_USER_MAP_MSG;
		Bundle bl = new Bundle();
		bl.putInt("type", Constants.MESSAGE_INTERAL_TYPE);
		bl.putString("appId", appId);
		bl.putString("userNick", user);
		bl.putString("password", password);
		bl.putString("email", email);
		bl.putString("phone", phone);
		msg.setData(bl);

		xmppHandler.sendMessage(msg);
	}

	@Override
	public void getUserMap(String email, String phone) throws RemoteException {
		Log.d(TAG, "getUserMap");

		Message msg = new Message();
		msg.what = InternalXmppEngine.GET_USER_MAP_MSG;
		Bundle bl = new Bundle();
		bl.putInt("type", Constants.MESSAGE_INTERAL_TYPE);
		bl.putString("appId", appId);
		bl.putString("email", email);
		bl.putString("phone", phone);
		msg.setData(bl);

		xmppHandler.sendMessage(msg);
	}

	
	/**
	 * @see com.gplocation.lbs.client.IGeneral#searchThirdApps(java.lang.String, int)
	 */
	@Override
	public void searchThirdApps(String key, int maxCount) throws RemoteException {
		Log.d(TAG, "getThirdApps");

		Message msg = new Message();
		msg.what = InternalXmppEngine.SEARCH_THIRD_APP_MSG;
		Bundle bl = new Bundle();
		bl.putInt("type", Constants.MESSAGE_INTERAL_TYPE);
		bl.putString("key", key);
		bl.putString("appId", appId);
		bl.putInt("count", maxCount);
		msg.setData(bl);
		xmppHandler.sendMessage(msg);
	}


	@Override
	public boolean removeAuthenticate(String appId) throws RemoteException {
		DBManager dbManager = new DBManager(context);
		dbManager.remvoeAuthoryDB(appId);
		
		MainApplication mainApplication = (MainApplication) ((LBSCoreService) context).getApplication();
		AuthorityManager authorityManager = mainApplication.authorityManager;
		authorityManager.remove(appId);
		
		mainApplication.receiveManager.removeListener(appId);
		
		return true;
	}


	@Override
	public boolean getAuthenticate(String appId) throws RemoteException {
		MainApplication mainApplication = (MainApplication) ((LBSCoreService) context).getApplication();
		AuthorityManager authorityManager = mainApplication.authorityManager;
		
		if (authorityManager.get(appId) != null) {
			return true;
		} else {
			return false;
		}
	}


	@Override
	public void login(String email, String pass) throws RemoteException {
		Log.d(TAG, "login");

		Message msg = new Message();
		msg.what = InternalXmppEngine.NEW_USER_LOGIN_MSG;
		Bundle bl = new Bundle();
		bl.putInt("type", Constants.MESSAGE_INTERAL_TYPE);
		bl.putString("email", email);
		bl.putString("password", pass);
		bl.putString("appId", appId);
		msg.setData(bl);
		xmppHandler.sendMessage(msg);
	}


	@Override
	public void setShareLocationTime(String startHour, String endHour)
			throws RemoteException {
		Log.d(TAG, "setShareLocationTime");

		Message msg = new Message();
		msg.what = InternalXmppEngine.SET_SHARE_LOCATION_TIME;
		Bundle bl = new Bundle();
		bl.putInt("type", Constants.MESSAGE_INTERAL_TYPE);
		bl.putString("start", startHour);
		bl.putString("end", endHour);
		bl.putString("appId", appId);
		msg.setData(bl);
		xmppHandler.sendMessage(msg);
	}

}
