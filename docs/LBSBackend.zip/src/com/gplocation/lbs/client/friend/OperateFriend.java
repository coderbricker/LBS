// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.client.friend;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;

import com.gplocation.lbs.application.MainApplication;
import com.gplocation.lbs.engine.RosterXmppEngine;
import com.gplocation.lbs.manager.AuthorityManager;
import com.gplocation.lbs.manager.ReceiveManager;
import com.gplocation.lbs.service.LBSCoreService;
import com.gplocation.lbs.utils.Constants;

public class OperateFriend extends IOperateFriend.Stub {
	private static final String TAG = "OperateFriend";
	private Handler xmppHandler;
	private String appId;
	private Context context;
	private ReceiveManager receiveManager;
	
    public OperateFriend(Context context, String appId, Handler handler) {
    	this.context = context;
    	this.appId = appId;
    	xmppHandler = handler;
    	
    	receiveManager = ((MainApplication) ((LBSCoreService) context).getApplication()).receiveManager;
    }

	/**
	 * @see com.gplocation.lbs.client.friend.IOperateFriend#listen(com.gplocation.lbs.client.friend.IFriendListener, int)
	 */
	@Override
	public void listen(IFriendListener listener, int eventType)
			throws RemoteException {
		MainApplication mainApplication = (MainApplication) ((LBSCoreService) context).getApplication();
		AuthorityManager authorityManager = mainApplication.authorityManager;
		if (authorityManager.get(appId) != null) {
			receiveManager.getFriendListeners().add(listener, appId);
		}
	}
	
	@Override
	public void addFriend(String friendNick, String userID)
			throws RemoteException {
		Log.d(TAG, "addFriend");
		
		Message msg = new Message();
		msg.what = RosterXmppEngine.ADD_FRIEND_MSG;
		
		Bundle bl = new Bundle();
		bl.putInt("type", Constants.MESSAGE_FRIEND_TYPE);
		bl.putString("friendId", userID);
		bl.putString("nick", friendNick);
		bl.putString("appId", appId);
		msg.setData(bl);
		
		xmppHandler.sendMessage(msg);
	}

	@Override
	public void removeFriend(String friendID) throws RemoteException {
		Log.d(TAG, "removeFriend");
		
		Message msg = new Message();
		msg.what = RosterXmppEngine.REMOVE_FRIEND_MSG;
		
		Bundle bl = new Bundle();
		bl.putInt("type", Constants.MESSAGE_FRIEND_TYPE);
		bl.putString("friendId", friendID);
		bl.putString("appId", appId);
		msg.setData(bl);
		
		xmppHandler.sendMessage(msg);
	}
}
