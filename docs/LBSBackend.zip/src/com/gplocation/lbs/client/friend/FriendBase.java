// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.client.friend;

import java.util.List;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;

import com.gplocation.lbs.application.MainApplication;
import com.gplocation.lbs.engine.RosterXmppEngine;
import com.gplocation.lbs.manager.AuthorityManager;
import com.gplocation.lbs.manager.ReceiveManager;
import com.gplocation.lbs.manager.RosterManager;
import com.gplocation.lbs.service.LBSCoreService;
import com.gplocation.lbs.utils.Constants;


/**
 * freind read interface
 */
public class FriendBase extends IFriend.Stub {

	private static final String TAG = "FriendBase";
	private Handler xmppHandler;
    private ReceiveManager receiveManager;  
    private String appId;
    private RosterManager rosterManager;
    private Context context;
    
    public FriendBase(Context context, String appId, Handler handler) {
    	this.context = context;
    	this.appId = appId;
    	xmppHandler = handler;
        rosterManager = ((MainApplication) ((LBSCoreService) context).getApplication()).rosterManager;
        receiveManager = ((MainApplication) ((LBSCoreService) context).getApplication()).receiveManager;
    }
    
	/**
	 * @see com.gplocation.lbs.client.friend.IFriend#listen(com.gplocation.lbs.client.friend.IFriendListener, int)
	 */
	@Override
	public void listen(IFriendListener listener, int eventType)
			throws RemoteException {
		MainApplication mainApplication = (MainApplication) ((LBSCoreService) context).getApplication();
		AuthorityManager authorityManager = mainApplication.authorityManager;
		if (authorityManager.get(appId) != null) {
			receiveManager.getFriendListeners().add(listener, appId);
		}
	}

	/**
	 * @see com.gplocation.lbs.client.friend.IFriend#getAllFriends()
	 */
	@Override
	public List<com.gplocation.lbs.data.Friend> getAllFriends()
			throws RemoteException {
		return rosterManager.getAllFriend();
	}

	/**
	 * @see com.gplocation.lbs.client.friend.IFriend#getOnlineFriends()
	 */
	@Override
	public List<com.gplocation.lbs.data.Friend> getOnlineFriends()
			throws RemoteException {
		return rosterManager.getOnlineFriend();
	}

	/**
	 * @see com.gplocation.lbs.client.friend.IFriend#sendMessage(java.lang.String, java.lang.String, boolean)
	 */
	@Override
	public void sendMessage(String toFriendId, String text, boolean withLocation)
			throws RemoteException {
		Log.d(TAG, "sendMessage");
		
		Message msg = new Message();
		msg.what = RosterXmppEngine.SEND_MESSAGE_MSG;
		
		Bundle bl = new Bundle();
		bl.putInt("type", Constants.MESSAGE_FRIEND_TYPE);
		bl.putString("friendId", toFriendId);
		bl.putString("text", text);
		bl.putBoolean("withLocation", withLocation);
		bl.putString("appId", appId);
		msg.setData(bl);
		
		xmppHandler.sendMessage(msg);
		
	}

	/**
	 * @see com.gplocation.lbs.client.friend.IFriend#sendBinaryMessage(java.lang.String, byte[], boolean)
	 */
	@Override
	public void sendBinaryMessage(String toFriendId, byte[] data,
			boolean withLocation) throws RemoteException {
		Log.d(TAG, "sendBinaryMessage");
		
		Message msg = new Message();
		msg.what = RosterXmppEngine.SEND_BINARY_MESSAGE_MSG;
		
		Bundle bl = new Bundle();
		bl.putInt("type", Constants.MESSAGE_FRIEND_TYPE);
		bl.putString("friendId", toFriendId);
		bl.putByteArray("text", data);
		bl.putBoolean("withLocation", withLocation);
		bl.putString("appId", appId);
		msg.setData(bl);
		
		xmppHandler.sendMessage(msg);
	}

	/**
	 * @see com.gplocation.lbs.client.friend.IFriend#requestLocation(java.lang.String)
	 */
	@Override
	public void requestLocation(String friendId) throws RemoteException {
		Log.d(TAG, "requestLocation");
		
		Message msg = new Message();
		msg.what = RosterXmppEngine.REQUEST_LOCATION_MSG;
		
		Bundle bl = new Bundle();
		bl.putInt("type", Constants.MESSAGE_FRIEND_TYPE);
		bl.putString("friendId", friendId);
		bl.putString("appId", appId);
		msg.setData(bl);
		
		xmppHandler.sendMessage(msg);
	}

	/**
	 * @see com.gplocation.lbs.client.friend.IFriend#followLocation(java.lang.String)
	 */
	@Override
	public void followLocation(String friendId) throws RemoteException {
		Log.d(TAG, "followLocation");
		
		Message msg = new Message();
		msg.what = RosterXmppEngine.FOLLOW_LOCATION_MSG;
		
		Bundle bl = new Bundle();
		bl.putInt("type", Constants.MESSAGE_FRIEND_TYPE);
		bl.putString("friendId", friendId);
		bl.putString("appId", appId);
		msg.setData(bl);
		
		xmppHandler.sendMessage(msg);
	}
	
	/**
	 * @see com.gplocation.lbs.client.friend.IFriend#stopSharingLoaction(java.lang.String)
	 */
	@Override
	public void stopSharingLoaction(String toFriendId) throws RemoteException {
		Log.d(TAG, "stopSharingLoaction");
		
		Message msg = new Message();
		msg.what = RosterXmppEngine.STOP_SHARE_LOCATION_MSG;
		
		Bundle bl = new Bundle();
		bl.putInt("type", Constants.MESSAGE_FRIEND_TYPE);
		bl.putString("friendId", toFriendId);
		bl.putString("appId", appId);
		msg.setData(bl);
		
		xmppHandler.sendMessage(msg);
	}

	/**
	 * @see com.gplocation.lbs.client.friend.IFriend#stopFollowLocation(java.lang.String)
	 */
	@Override
	public void stopFollowLocation(String friendId) throws RemoteException {
		Log.d(TAG, "stopFollowLocation");
		
		Message msg = new Message();
		msg.what = RosterXmppEngine.STOP_FOLLOW_LOCATION_MSG;
		
		Bundle bl = new Bundle();
		bl.putInt("type", Constants.MESSAGE_FRIEND_TYPE);
		bl.putString("friendId", friendId);
		bl.putString("appId", appId);
		msg.setData(bl);
		
		xmppHandler.sendMessage(msg);
		
	}

	/**
	 * @see com.gplocation.lbs.client.friend.IFriend#shareLocation(java.lang.String, boolean, int)
	 */
	@Override
	public void shareLocation(String toFriendId, boolean isContinuesly,
			int inteval) throws RemoteException {
		Log.d(TAG, "shareLocation");
		
		Message msg = new Message();
		msg.what = RosterXmppEngine.SHARE_LOCATION_MSG;
		
		Bundle bl = new Bundle();
		bl.putInt("type", Constants.MESSAGE_FRIEND_TYPE);
		bl.putString("friendId", toFriendId);
		bl.putBoolean("continuse", isContinuesly);
		bl.putInt("interval", inteval);
		bl.putString("appId", appId);
		msg.setData(bl);
		
		xmppHandler.sendMessage(msg);
		
	}

	/**
	 * @see com.gplocation.lbs.client.friend.IFriend#shareLocationByDistance(java.lang.String, boolean, int)
	 */
	@Override
	public void shareLocationByDistance(String toFriendId,
			boolean isContinuesly, int distance) throws RemoteException {
		Log.d(TAG, "shareLocationByDistance");
		
		Message msg = new Message();
		msg.what = RosterXmppEngine.SHARE_LOCATION_DISTANCE_MSG;
		
		Bundle bl = new Bundle();
		bl.putInt("type", Constants.MESSAGE_FRIEND_TYPE);
		bl.putString("friendId", toFriendId);
		bl.putBoolean("continuse", isContinuesly);
		bl.putInt("distance", distance);
		bl.putString("appId", appId);
		msg.setData(bl);
		
		xmppHandler.sendMessage(msg);
		
	}



}
