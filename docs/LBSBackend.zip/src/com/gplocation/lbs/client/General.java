// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.client;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;

import com.gplocation.lbs.application.MainApplication;
import com.gplocation.lbs.backend.R;
import com.gplocation.lbs.client.friend.FriendBase;
import com.gplocation.lbs.client.friend.IFriend;
import com.gplocation.lbs.client.friend.IOperateFriend;
import com.gplocation.lbs.client.friend.OperateFriend;
import com.gplocation.lbs.client.group.GroupBase;
import com.gplocation.lbs.client.group.IGroup;
import com.gplocation.lbs.client.group.IOperateGroup;
import com.gplocation.lbs.client.group.OperateGroup;
import com.gplocation.lbs.client.internal.IInternal;
import com.gplocation.lbs.client.internal.Internal;
import com.gplocation.lbs.client.pubsub.IPublish;
import com.gplocation.lbs.client.pubsub.ISubscribe;
import com.gplocation.lbs.client.pubsub.Publish;
import com.gplocation.lbs.client.pubsub.Subscribe;
import com.gplocation.lbs.data.LBSUser;
import com.gplocation.lbs.data.LBSUserExtend;
import com.gplocation.lbs.engine.GeneralXmppEngine;
import com.gplocation.lbs.manager.AuthorityManager;
import com.gplocation.lbs.manager.BinderManager;
import com.gplocation.lbs.manager.ReceiveManager;
import com.gplocation.lbs.service.LBSCoreService;
import com.gplocation.lbs.utils.Constants;

/**
 * genearl interface
 */
public class General extends IGeneral.Stub {

	private static final String TAG = "General";

	private Handler xmppHandler;
	private AuthorityManager authorityManager;
	private ReceiveManager receiveManager;
	private LBSUserExtend userInfo;
	private Context context;
	
	private BinderManager binderManager;
	
	private Object [] iBinderLock = new Object [10];
	
	/**
	 * if the 3rd application is not authenticated, it will send back to 3rd with this string
	 */
	private String authenticateError;

	public General(Context context, Handler handler,
			LBSUserExtend userInfo) {
		this.context = context;
		xmppHandler = handler;
		this.userInfo = userInfo;
		MainApplication mainApplication = (MainApplication) ((LBSCoreService) context).getApplication();
		this.authorityManager = mainApplication.authorityManager;
		receiveManager = mainApplication.receiveManager;
		binderManager = mainApplication.binderManager;
		
		authenticateError = context.getString(R.string.exception_not_authenticate);
		
		for (int i=0; i<10; ++i) {
			iBinderLock[i] = new Object();
		}
	}

	/**
	 * @see com.gplocation.lbs.client.IGeneral#authenticate(java.lang.String,
	 *      java.lang.String, java.lang.String, java.lang.String,
	 *      com.gplocation.lbs.client.IGeneralListener)
	 */
	@Override
	public void authenticate(String appName, String appId, String vendor,
			String certificate, IGeneralListener listener)
			throws RemoteException {
		Log.d(TAG, "authenticate");

		if (authorityManager.get(appId) != null) {
			receiveManager.getGeneralListeners().add(listener, appId);
			
			try {
				receiveManager.getGeneralListeners().get(appId).receiveAuthenticateResult(true, "");
			} catch (RemoteException e) {
				e.printStackTrace();
			}	
						
			return ;
		} 
		
		
		Message msg = new Message();
		msg.what = GeneralXmppEngine.AUTHENTICAT_MSG;
		Bundle bl = new Bundle();
		bl.putInt("type", Constants.MESSAGE_GENERAL_TYPE);
		bl.putString("appName", appName);
		bl.putString("appId", appId);
		bl.putString("vendor", vendor);
		bl.putString("certificate", certificate);
		msg.setData(bl);

		receiveManager.getGeneralListeners().add(listener, appId);
		xmppHandler.sendMessage(msg);
	}

	/**
	 * @see com.gplocation.lbs.client.IGeneral#registerInToLBSPlatform(java.lang.String,
	 *      java.lang.String, com.gplocation.lbs.client.IGeneralListener, int)
	 */
	@Override
	public boolean registerInToLBSPlatform(String packageName, String appId,
			IGeneralListener listener, int eventTypes) throws RemoteException {

		Log.d(TAG, "registerInToLBSPlatform");

		if (authorityManager.get(appId) != null) {
			receiveManager.getGeneralListeners().add(listener, appId);
			return true;
		} else {
			RemoteException exception = new RemoteException();
	        exception.initCause(new Throwable(authenticateError));
			throw exception;
		}

	}

	/**
	 * @see com.gplocation.lbs.client.IGeneral#isServiceAvailable(java.lang.String)
	 */
	@Override
	public boolean isServiceAvailable() throws RemoteException {
		Log.d(TAG, "isServiceAvailable");
		int connection = ((MainApplication) ((LBSCoreService) context)
				.getApplication()).xmppConnectionState;
		Log.d(TAG, "isServiceAvailable +" + connection);
		if (Constants.CONNECTION_CONNECTED == connection) {
			return true;
		} 
		
		return false;
	}

	/**
	 * @see com.gplocation.lbs.client.IGeneral#getUserInfo(java.lang.String)
	 */
	@Override
	public LBSUser getUserInfo() throws RemoteException {
		Log.d(TAG, "getUserInfo" + authorityManager);
		Log.d(TAG, "userInfo");
		return LBSUserExtend.getUserFromExtend(userInfo);
	}
	
	
	@Override
	public IBinder getFriendReadBinder(String appId) throws RemoteException {
		if (authorityManager.getFriendAuthority(appId) != null 
				&& authorityManager.getFriendAuthority(appId).contains("r")) {
		
			Log.d(TAG, "iBinderLock=" + iBinderLock + iBinderLock[0]);
			synchronized (iBinderLock[0]) {
				IBinder returnBinder = (IBinder) binderManager.getReadFriends().get(appId);
				Log.d(TAG, "getFriendReadBinder + iBinder=" + returnBinder);
				if (returnBinder == null) {
					returnBinder = new FriendBase(context, appId, xmppHandler);
					binderManager.getReadFriends().add(((IFriend) returnBinder), appId);
				}
				Log.d(TAG, "getFriendReadBinder + iBinder=" + returnBinder);
	    		return returnBinder;
			}
			
			
    	}  else {
			Log.d(TAG, "getFriendReadBinder throw exception");
			RemoteException exception = new RemoteException();
	        exception.initCause(new Throwable(authenticateError));
			throw exception;
		}		
	}

	@Override
	public IBinder getFriendWriteBinder(String appId) throws RemoteException {
		if (authorityManager.getFriendAuthority(appId) != null 
				&& authorityManager.getFriendAuthority(appId).contains("w")) {
			
			synchronized (iBinderLock[1]) {
				IBinder returnBinder = (IBinder) binderManager.getWriteFriends().get(appId);
				if (returnBinder == null) {
					returnBinder = new OperateFriend(context, appId, xmppHandler);
					binderManager.getWriteFriends().add(((IOperateFriend) returnBinder), appId);
				}
				
	    		return returnBinder;
			}
    	}  else {
			Log.d(TAG, "getFriendWriteBinder throw exception");
			RemoteException exception = new RemoteException();
	        exception.initCause(new Throwable(authenticateError));
			throw exception;
		}
	}

	@Override
	public IBinder getGroupReadBinder(String appId) throws RemoteException {
		if (authorityManager.getGroupAuthority(appId) != null
				&& authorityManager.getGroupAuthority(appId).contains("r")) {
			synchronized (iBinderLock[2]) {
				IBinder returnBinder = (IBinder) binderManager.getReadGroups().get(appId);
				if (returnBinder == null) {
					returnBinder = new GroupBase(context, appId, xmppHandler);
					binderManager.getReadGroups().add(((IGroup) returnBinder), appId);
				}
				
	    		return returnBinder;
			}
    	}  else {
			Log.d(TAG, "getGroupReadBinder throw exception");
			RemoteException exception = new RemoteException();
	        exception.initCause(new Throwable(authenticateError));
			throw exception;
		}
	}

	@Override
	public IBinder getGroupWriteBinder(String appId) throws RemoteException {
		if (authorityManager.getGroupAuthority(appId) != null
				&& authorityManager.getGroupAuthority(appId).contains("w")) {
			synchronized (iBinderLock[3]) {
				IBinder returnBinder = (IBinder) binderManager.getWriteGroups().get(appId);
				if (returnBinder == null) {
					returnBinder = new OperateGroup(context, appId, xmppHandler);
					binderManager.getWriteGroups().add(((IOperateGroup) returnBinder), appId);
				}
				
	    		return returnBinder;
			}
    	}  else {
			Log.d(TAG, "getGroupWriteBinder throw exception");
			RemoteException exception = new RemoteException();
	        exception.initCause(new Throwable(authenticateError));
			throw exception;
		}
	}

	@Override
	public IBinder getPublishBinder(String appId) throws RemoteException {
		if (authorityManager.getPubsubAuthority(appId) != null
				&& authorityManager.getPubsubAuthority(appId).contains("p")) {
			synchronized (iBinderLock[4]) {
				IBinder returnBinder = (IBinder) binderManager.getPublish().get(appId);
				if (returnBinder == null) {
					returnBinder = new Publish(context, appId, xmppHandler);
					binderManager.getPublish().add(((IPublish) returnBinder), appId);
				}
				
	    		return returnBinder;
			}
    	}  else {
			Log.d(TAG, "getPublishBinder throw exception");
			RemoteException exception = new RemoteException();
	        exception.initCause(new Throwable(authenticateError));
			throw exception;
		}
	}

	@Override
	public IBinder getSubscribeBinder(String appId) throws RemoteException {
		if (authorityManager.getPubsubAuthority(appId) != null
				&& authorityManager.getPubsubAuthority(appId).contains("s")) {
			
			synchronized (iBinderLock[5]) {
				IBinder returnBinder = (IBinder) binderManager.getSubscribe().get(appId);
				if (returnBinder == null) {
					returnBinder = new Subscribe(context, appId, xmppHandler);
					binderManager.getSubscribe().add(((ISubscribe) returnBinder), appId);
				}
				
	    		return returnBinder;
			}
    	}  else {
			Log.d(TAG, "getSubscribeBinder throw exception");
			RemoteException exception = new RemoteException();
	        exception.initCause(new Throwable(authenticateError));
			throw exception;
		}
	}

	@Override
	public IBinder getInternalBinder(String appId) throws RemoteException {
		if (appId.equals(Constants.DEFAULT_APPID)) {
			synchronized (iBinderLock[6]) {
				IBinder returnBinder = (IBinder) binderManager.getInternal().get(appId);
				if (returnBinder == null) {
					returnBinder = new Internal(context, appId, xmppHandler);
					binderManager.getInternal().add(((IInternal) returnBinder), appId);
				}
				
	    		return returnBinder;
			}
		} else {
			Log.d(TAG, "getInternalBinder throw exception");
			RemoteException exception = new RemoteException();
	        exception.initCause(new Throwable(authenticateError));
			throw exception;
		}
	}
	
}
