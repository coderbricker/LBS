// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.client.pubsub;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.RemoteException;

import com.gplocation.lbs.application.MainApplication;
import com.gplocation.lbs.engine.PubsubXmppEngine;
import com.gplocation.lbs.manager.ReceiveManager;
import com.gplocation.lbs.service.LBSCoreService;
import com.gplocation.lbs.utils.Constants;

/**
 * 
 * Publish interface
 */
public class Publish extends IPublish.Stub {
    
    private Handler xmppHandler;
    private String appId;
    private ReceiveManager receiveManager;
    private Context context;
    
    public Publish(Context context, String appId, Handler handler) {
        this.context = context;
        this.appId = appId;
        this.xmppHandler = handler;
        receiveManager = ((MainApplication) ((LBSCoreService) this.context).getApplication()).receiveManager;
    }

    /**
     * 
     * @see com.gplocation.lbs.client.pubsub.IPublish#publishItem(java.lang.String, java.lang.String, boolean)
     * publish an item to service
     */
	@Override
	public void publishItem(String topic, String content,
			boolean withLocation) throws RemoteException {
	    Message msg = new Message();
        msg.what = PubsubXmppEngine.PUBLISH;
        
        Bundle bl = new Bundle();
        bl.putInt("type", Constants.MESSAGE_PUBSUB_TYPE);
        bl.putString("topic", topic);
        bl.putString("appId", appId);
        bl.putString("content", content);
        bl.putBoolean("withLocation", withLocation);
        msg.setData(bl);
        
        xmppHandler.sendMessage(msg);
	}

    @Override
    public void listen(IPubSubListener listener, int eventType) throws RemoteException {
        receiveManager.getPubSubListeners().add(listener, appId);        
    }

}
