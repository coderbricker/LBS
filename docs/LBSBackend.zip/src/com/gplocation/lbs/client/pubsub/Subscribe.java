// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.client.pubsub;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.RemoteException;

import com.gplocation.lbs.application.MainApplication;
import com.gplocation.lbs.engine.PubsubXmppEngine;
import com.gplocation.lbs.manager.ReceiveManager;
import com.gplocation.lbs.service.LBSCoreService;
import com.gplocation.lbs.utils.Constants;

/**
 * Subscribe interface
 */
public class Subscribe extends ISubscribe.Stub {
    private Handler xmppHandler;
    private String appId;
    private Context context;
    private ReceiveManager receiveManager;
    
    public Subscribe(Context context, String appId, Handler handler) {
        this.context = context;
        this.appId = appId;
        this.xmppHandler = handler;
        receiveManager = ((MainApplication) ((LBSCoreService) this.context).getApplication()).receiveManager;
    }
	@Override
	public void fetchTopics(String parentPath, String patten)
			throws RemoteException {
	    Message msg = new Message();
        msg.what = PubsubXmppEngine.FETCHTOPICS;
        
        Bundle bl = new Bundle();
        bl.putInt("type", Constants.MESSAGE_PUBSUB_TYPE);
        bl.putString("parentPath", parentPath);
        bl.putString("patten", patten);
        bl.putString("appId", appId);
        msg.setData(bl);
        
        xmppHandler.sendMessage(msg);
	}

	/**
	 * subscribe a topic with location or without location
	 * (non-Javadoc)
	 * @see com.gplocation.lbs.client.pubsub.ISubscribe#subscribe(java.lang.String, boolean)
	 */
	@Override
	public void subscribe(String topic) throws RemoteException {
	    Message msg = new Message();
        msg.what = PubsubXmppEngine.SUBSCRIBE;
        
        Bundle bl = new Bundle();
        bl.putInt("type", Constants.MESSAGE_PUBSUB_TYPE);
        bl.putString("topic", topic);
        bl.putString("appId", appId);
        msg.setData(bl);
        
        xmppHandler.sendMessage(msg);
	}
	
	/**
	 * register IPubSubListener to back server
	 * (non-Javadoc)
	 * @see com.gplocation.lbs.client.pubsub.ISubscribe#listen(com.gplocation.lbs.client.pubsub.IPubSubListener, int)
	 */
    @Override
    public void listen(IPubSubListener listener, int eventType) throws RemoteException {
        receiveManager.getPubSubListeners().add(listener, appId);
        ((MainApplication) ((LBSCoreService) this.context).getApplication()).lbsPubsubManager.initSubscribed(appId);
        
    }
    @Override
    public void unSubscribe(String topic) throws RemoteException {
        Message msg = new Message();
        msg.what = PubsubXmppEngine.UNSUBSCRIBE;
        
        Bundle bl = new Bundle();
        bl.putInt("type", Constants.MESSAGE_PUBSUB_TYPE);
        bl.putString("topic", topic);
        bl.putString("appId", appId);
        msg.setData(bl);
        
        xmppHandler.sendMessage(msg);
    }

}
