// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.client.group;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;

import com.gplocation.lbs.application.MainApplication;
import com.gplocation.lbs.data.GroupInfo;
import com.gplocation.lbs.data.Member;
import com.gplocation.lbs.data.Setting;
import com.gplocation.lbs.engine.GroupXmppEngine;
import com.gplocation.lbs.manager.AuthorityManager;
import com.gplocation.lbs.manager.DBManager;
import com.gplocation.lbs.manager.GroupManager;
import com.gplocation.lbs.manager.GroupMemberManager;
import com.gplocation.lbs.manager.ReceiveManager;
import com.gplocation.lbs.service.LBSCoreService;
import com.gplocation.lbs.utils.Constants;

/**
 * IGroup interface
 */
public class GroupBase extends IGroup.Stub {
	
	private static final String TAG = "GroupBase";
	
	private Handler xmppHandler;
	private String appId;
    private ReceiveManager receiveManager;
    private GroupManager groupManager;
    private GroupMemberManager groupMemberManager;
    private Context context;
    
	
    public GroupBase(Context context, String appId, Handler handler) {
        this.context = context;
    	this.appId = appId;
    	xmppHandler = handler;
    	
    	groupManager = ((MainApplication) ((LBSCoreService) context).getApplication()).groupManager;
    	groupMemberManager = ((MainApplication) ((LBSCoreService) context).getApplication()).groupMemberManager;
    	receiveManager = ((MainApplication) ((LBSCoreService) context).getApplication()).receiveManager;
    }

	/**
	 * @see com.gplocation.lbs.client.group.IGroup#listen(com.gplocation.lbs.client.group.IGroupListener, int)
	 */
	@Override
	public void listen(IGroupListener listener, int eventType)
			throws RemoteException {
		MainApplication mainApplication = (MainApplication) ((LBSCoreService) context).getApplication();
		AuthorityManager authorityManager = mainApplication.authorityManager;
		if (authorityManager.get(appId) != null) {
			receiveManager.getGroupListeners().add(listener, appId);
		}
	}

	/**
	 * @see com.gplocation.lbs.client.group.IGroup#getJoinedGroups()
	 */
	@Override
	public List<GroupInfo> getJoinedGroups() throws RemoteException {
		return groupManager.getGroupList();
	}

	/**
	 * @see com.gplocation.lbs.client.group.IGroup#getGroupMembers(java.lang.String)
	 */
	@Override
	public List<Member> getGroupMembers(String groupId)
			throws RemoteException {
		
		if (groupMemberManager.getMembers(groupId) != null) {
			return groupMemberManager.getMembers(groupId).getMembers();
		} else {
			return null;
		}
	}

	/**
	 * @see com.gplocation.lbs.client.group.IGroup#getGroupSetting(java.lang.String, java.lang.String)
	 */
	@Override
	public List<Setting> getGroupSetting(String groupId, String settingName)
			throws RemoteException {
		
		DBManager dbManager = new DBManager(context);
		return dbManager.readGroupSetting(appId, groupId, settingName);
		
		
//		return groupSettingManager.getSetting(groupID, appId, settingName);
	}

	/**
	 * @see com.gplocation.lbs.client.group.IGroup#getGroupInfo(java.lang.String)
	 */
	@Override
	public GroupInfo getGroupInfo(String groupId) throws RemoteException {
		return groupManager.getGroupInfo(groupId);
	}

	/**
	 * @see com.gplocation.lbs.client.group.IGroup#sendGroupMessage(java.lang.String, java.lang.String, boolean)
	 */
	@Override
	public void sendGroupMessage(String groupID, String text,
			boolean withLocation) throws RemoteException {
		Log.d(TAG, "sendGroupMessage");
		
		Message msg = new Message();
		msg.what = GroupXmppEngine.SEND_MESSAGE_MSG;
		
		Bundle bl = new Bundle();
		bl.putInt("type", Constants.MESSAGE_GROUP_TYPE);
		bl.putString("groupId", groupID);
		bl.putBoolean("withLocation", withLocation);
		bl.putString("text", text);
		bl.putString("appId", appId);
		msg.setData(bl);
		
		xmppHandler.sendMessage(msg);
	}

	/**
	 * @see com.gplocation.lbs.client.group.IGroup#shareLocation(java.lang.String, boolean)
	 */
	@Override
	public void shareLocation(String groupID, boolean isContinously, int interval)
			throws RemoteException {
		Log.d(TAG, "shareLocation");
		
		Message msg = new Message();
		msg.what = GroupXmppEngine.SHARE_LOCATION_MSG;
		
		Bundle bl = new Bundle();
		bl.putInt("type", Constants.MESSAGE_GROUP_TYPE);
		bl.putString("groupId", groupID);
		bl.putBoolean("continous", isContinously);
		bl.putInt("interval", interval);
		bl.putString("appId", appId);
		msg.setData(bl);
		
		xmppHandler.sendMessage(msg);
	}

	
	/**
	 * @see com.gplocation.lbs.client.group.IGroup#stopShareLocation(java.lang.String)
	 */
	@Override
	public void stopShareLocation(String groupID) throws RemoteException {
		Log.d(TAG, "stopShareLocation");
		
		Message msg = new Message();
		msg.what = GroupXmppEngine.STOP_SHARE_LOCATION_MSG;
		
		Bundle bl = new Bundle();
		bl.putInt("type", Constants.MESSAGE_GROUP_TYPE);
		bl.putString("groupId", groupID);
		bl.putString("appId", appId);
		msg.setData(bl);
		
		xmppHandler.sendMessage(msg);
	}
	
	
	/**
	 * @see com.gplocation.lbs.client.group.IGroup#excuteGroupSetting(java.lang.String, java.lang.String)
	 */
	@Override
	public void excuteGroupSetting(String groupID, String settingName)
			throws RemoteException {
		Log.d(TAG, "excuteGroupSetting");
		
		Message msg = new Message();
		msg.what = GroupXmppEngine.EXCUTE_SETTING_MSG;
		
		Bundle bl = new Bundle();
		bl.putInt("type", Constants.MESSAGE_GROUP_TYPE);
		bl.putString("groupId", groupID);
		bl.putString("settingName", settingName);
		bl.putString("appId", appId);
		msg.setData(bl);
		
		xmppHandler.sendMessage(msg);
		
	}

	/**
	 * @see com.gplocation.lbs.client.group.IGroup#stopExcuteGroupSetting(java.lang.String, java.lang.String)
	 */
	@Override
	public void stopExcuteGroupSetting(String groupID, String settingName)
			throws RemoteException {
		Log.d(TAG, "stopExcuteGroupSetting");
		
		Message msg = new Message();
		msg.what = GroupXmppEngine.STOP_EXCUTE_SETTING_MSG;
		
		Bundle bl = new Bundle();
		bl.putInt("type", Constants.MESSAGE_GROUP_TYPE);
		bl.putString("groupId", groupID);
		bl.putString("settingName", settingName);
		bl.putString("appId", appId);
		msg.setData(bl);
		
		xmppHandler.sendMessage(msg);
	}

	/**
	 * @see com.gplocation.lbs.client.group.IGroup#getRoles(java.lang.String, java.lang.String)
	 */
	@Override
	public String getRole(String groupId, String memberID)
			throws RemoteException {
		String res = null;
		if (this.groupMemberManager.getMembers(groupId) != null 
				&& this.groupMemberManager.getMembers(groupId).get(memberID) != null) {
			res = this.groupMemberManager.getMembers(groupId).get(memberID).role;
		}
		return res;
	}

	/**
	 * @see com.gplocation.lbs.client.group.IGroup#getOwners(java.lang.String)
	 */
	@Override
	public List<String> getOwners(String groupId) throws RemoteException {
		ArrayList<String> owners = null;
		if (this.groupMemberManager.getMembers(groupId) != null) {
			owners = this.groupMemberManager.getMembers(groupId).getOwners();
		}
		
		return owners;
	}

	
	/**
	 * @see com.gplocation.lbs.client.group.IGroup#searchGroups(java.lang.String, int)
	 */
	@Override
	public void searchGroups(String pattern, int resultCount)
			throws RemoteException {
		Log.d(TAG, "searchGroups");
		
		Message msg = new Message();
		msg.what = GroupXmppEngine.SEARCH_MSG;
		
		Bundle bl = new Bundle();
		bl.putInt("type", Constants.MESSAGE_GROUP_TYPE);
		bl.putString("pattern", pattern);
		bl.putInt("resultCount", resultCount);
		bl.putString("appId", appId);
		msg.setData(bl);
		
		xmppHandler.sendMessage(msg);
	}

	
	/**
	 * @see com.gplocation.lbs.client.group.IGroup#acceptInvitationToGroup(java.lang.String)
	 */
	@Override
	public void acceptInvitationToGroup(String groupId)
			throws RemoteException {
		Log.d(TAG, "approveInvitationToGroup");
		
		Message msg = new Message();
		msg.what = GroupXmppEngine.APPROVE_INVITATION_MSG;
		
		Bundle bl = new Bundle();
		bl.putInt("type", Constants.MESSAGE_GROUP_TYPE);
		bl.putString("groupId", groupId);
		bl.putString("appId", appId);
		msg.setData(bl);
		
		xmppHandler.sendMessage(msg);
		
	}
}
