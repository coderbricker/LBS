// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.client.group;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Parcelable;
import android.os.RemoteException;
import android.util.Log;

import com.gplocation.lbs.application.MainApplication;
import com.gplocation.lbs.data.GroupInfo;
import com.gplocation.lbs.data.Setting;
import com.gplocation.lbs.engine.GroupXmppEngine;
import com.gplocation.lbs.manager.AuthorityManager;
import com.gplocation.lbs.manager.ReceiveManager;
import com.gplocation.lbs.service.LBSCoreService;
import com.gplocation.lbs.utils.Constants;

public class OperateGroup extends IOperateGroup.Stub {

	private static final String TAG = "OperateGroup";
	private Handler xmppHandler;
	private String appId;
	private Context context;
	private ReceiveManager receiveManager;
	
	public OperateGroup(Context context, String appId, Handler handler) {
    	this.context = context;
    	this.appId = appId;
    	xmppHandler = handler;
    	
    	receiveManager = ((MainApplication) ((LBSCoreService) context).getApplication()).receiveManager;
    }
	
	
	/**
	 * @see com.gplocation.lbs.client.group.IOperateGroup#listen(com.gplocation.lbs.client.group.IGroupListener, int)
	 */
	@Override
	public void listen(IGroupListener listener, int eventType)
			throws RemoteException {
		MainApplication mainApplication = (MainApplication) ((LBSCoreService) context).getApplication();
		AuthorityManager authorityManager = mainApplication.authorityManager;
		if (authorityManager.get(appId) != null) {
			receiveManager.getGroupListeners().add(listener, appId);
		}
	}

		
	/**
	 * <p></P>
	 * @param groupName
	 * @param description
	 * @throws RemoteException
	 */
	@Override
	public void createGroup(String groupName, String description)
			throws RemoteException {

		Log.d(TAG, "create");
		
		Message msg = new Message();
		msg.what = GroupXmppEngine.CREATE_MSG;
		
		Bundle bl = new Bundle();
		bl.putInt("type", Constants.MESSAGE_GROUP_TYPE);
		//note it is not group Id
		bl.putString("groupName", groupName);
		bl.putString("description", description);
		bl.putString("appId", appId);
		msg.setData(bl);
		
		xmppHandler.sendMessage(msg);
	}

	/**
	 * @see com.gplocation.lbs.client.group.IOperateGroup#removeGroup(java.lang.String)
	 */
	@Override
	public void removeGroup(String groupID) throws RemoteException {
		Log.d(TAG, "removeGroup");
		
		Message msg = new Message();
		msg.what = GroupXmppEngine.REMOVE_MSG;
		
		Bundle bl = new Bundle();
		bl.putInt("type", Constants.MESSAGE_GROUP_TYPE);
		//note it is not group Id
		bl.putString("groupId", groupID);
		bl.putString("appId", appId);
		msg.setData(bl);
		
		xmppHandler.sendMessage(msg);
	}

	
	/**
	 * @see com.gplocation.lbs.client.group.IOperateGroup#exitGroup(java.lang.String)
	 */
	@Override
	public void exitGroup(String groupId) throws RemoteException {
		Log.d(TAG, "exitGroup");
		
		Message msg = new Message();
		msg.what = GroupXmppEngine.EXIT_MSG;
		
		Bundle bl = new Bundle();
		bl.putInt("type", Constants.MESSAGE_GROUP_TYPE);
		//note it is not group Id
		bl.putString("groupId", groupId);
		bl.putString("appId", appId);
		msg.setData(bl);
		
		xmppHandler.sendMessage(msg);
	}
	
	/**
	 * @see com.gplocation.lbs.client.group.IOperateGroup#changeGroupInfo(java.lang.String, com.gplocation.lbs.data.GroupInfo)
	 */
	@Override
	public void changeGroupInfo(String groupID, GroupInfo groupInfo)
			throws RemoteException {
		Log.d(TAG, "changeGroupInfo");
		
		Message msg = new Message();
		msg.what = GroupXmppEngine.CHANGE_INFO_MSG;
		
		Bundle bl = new Bundle();
		bl.putInt("type", Constants.MESSAGE_GROUP_TYPE);
		//note it is not group Id
		bl.putString("groupId", groupID);
		bl.putParcelable("groupInfo", groupInfo);
		bl.putString("appId", appId);
		msg.setData(bl);
		
		xmppHandler.sendMessage(msg);
	}

	/**
	 * @see com.gplocation.lbs.client.group.IOperateGroup#setMembersAsOwner(java.lang.String, java.lang.String)
	 */
	@Override
	public void setMembersAsOwner(String groupID, String memberID)
			throws RemoteException {
		Log.d(TAG, "setMembersAsOwner");
		
		Message msg = new Message();
		msg.what = GroupXmppEngine.SET_MEMBER_AS_OWNER_MSG;
		
		Bundle bl = new Bundle();
		bl.putInt("type", Constants.MESSAGE_GROUP_TYPE);
		//note it is not group Id
		bl.putString("groupId", groupID);
		bl.putString("memberId", memberID);
		bl.putString("appId", appId);
		msg.setData(bl);
		
		xmppHandler.sendMessage(msg);
		
	}


	/**
	 * @see com.gplocation.lbs.client.group.IOperateGroup#inviteUser(java.lang.String, java.lang.String)
	 */
	@Override
	public void inviteUser(String groupId, String userId)
			throws RemoteException {
		Log.d(TAG, "inviteUser");
		
		Message msg = new Message();
		msg.what = GroupXmppEngine.INVITE_USER_MSG;
		
		Bundle bl = new Bundle();
		bl.putInt("type", Constants.MESSAGE_GROUP_TYPE);
		//note it is not group Id
		bl.putString("groupId", groupId);
		bl.putString("memberId", userId);
		bl.putString("appId", appId);
		msg.setData(bl);
		
		xmppHandler.sendMessage(msg);
		
	}

	
	/**
	 * @see com.gplocation.lbs.client.group.IOperateGroup#removeMember(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public void removeMember(String groupId, String memberId, String memberNick)
			throws RemoteException {
		Log.d(TAG, "removeMember");
		
		Message msg = new Message();
		msg.what = GroupXmppEngine.REMOVE_MEMBER_MSG;
		
		Bundle bl = new Bundle();
		bl.putInt("type", Constants.MESSAGE_GROUP_TYPE);
		//note it is not group Id
		bl.putString("groupId", groupId);
		bl.putString("memberId", memberId);
		bl.putString("nick", memberNick);
		bl.putString("appId", appId);
		msg.setData(bl);
		
		xmppHandler.sendMessage(msg);
		
	}

	/**
	 * @see com.gplocation.lbs.client.group.IOperateGroup#joinGroup(java.lang.String)
	 */
	@Override
	public void joinGroup(String groupId) throws RemoteException {
		Log.d(TAG, "joinGroup");
		
		Message msg = new Message();
		msg.what = GroupXmppEngine.JOIN_MSG;
		
		Bundle bl = new Bundle();
		bl.putInt("type", Constants.MESSAGE_GROUP_TYPE);
		//note it is not group Id
		bl.putString("groupId", groupId);
		bl.putString("appId", appId);
		msg.setData(bl);
		
		xmppHandler.sendMessage(msg);
		
	}

	
	/**
	 * @see com.gplocation.lbs.client.group.IOperateGroup#setGroupSetting(java.lang.String, java.lang.String, java.util.List)
	 */
	@Override
	public void setGroupSetting(String groupID, String settingName,
			List<Setting> gSetting) throws RemoteException {

		Log.d(TAG, "setGroupSetting");
		
		Message msg = new Message();
		msg.what = GroupXmppEngine.SET_SETTING_MSG;
		
		Bundle bl = new Bundle();
		bl.putInt("type", Constants.MESSAGE_GROUP_TYPE);
		//note it is not group Id
		bl.putString("groupId", groupID);
		bl.putString("settingName", settingName);
		bl.putParcelableArrayList("setting", (ArrayList<? extends Parcelable>) gSetting);
		bl.putString("appId", appId);
		msg.setData(bl);
		
		xmppHandler.sendMessage(msg);
	}

}
