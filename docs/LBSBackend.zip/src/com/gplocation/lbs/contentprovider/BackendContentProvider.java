/** Access to backend database
 * joined group, group setting, authenticated apps 
 * 
 */
package com.gplocation.lbs.contentprovider;

import java.util.HashMap;
import java.util.Map;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.provider.BaseColumns;
import android.text.TextUtils;
import android.util.Log;

/** Content provider to operate tables in db
 * @author jianbinxu
 *
 */
public class BackendContentProvider extends ContentProvider {

	private static final String TAG = "BackendContentProvider";
    
    //db setting
    private static final String LBS_DB_NAME = "lbs.db";
    private static final int LBS_USE_DB_VER = 2;

	private static final int JOINED_GROUP = 1;
	private static final int JOINED_GROUP_ID = 2;
	private static final int GROUP_SETTING = 3;
	private static final int GROUP_SETTING_ID = 4;
	private static final int AUTH_APPS = 5;
	private static final int AUTH_APPS_ID = 6; 
    
	private BackendDBHelper dBHelper = null;
    
    //content uri helper
    private static UriMatcher sUriMatcher;
    
    private static Map<String, String> sJoinedGroupProjectionMap;
    private static Map<String, String> sGroupSettingProjectionMap;    
    private static Map<String, String> sAuthAppsProjectionMap;
    
    static {
        sUriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
        //joined group
        sUriMatcher.addURI(JoinedGroup.AUTHORITY, "joinedgroup", JOINED_GROUP);
        sUriMatcher.addURI(JoinedGroup.AUTHORITY, "joinedgroup/#", JOINED_GROUP_ID);
        
        //group setting
        sUriMatcher.addURI(GroupSetting.AUTHORITY, "groupsetting", GROUP_SETTING);
        sUriMatcher.addURI(GroupSetting.AUTHORITY, "groupsetting/#", GROUP_SETTING_ID);

        //authenticated apps
        sUriMatcher.addURI(AuthenticatedApp.AUTHORITY, "authentiatedapp", AUTH_APPS);
        sUriMatcher.addURI(AuthenticatedApp.AUTHORITY, "authentiatedapp/#", AUTH_APPS_ID);
        
        //setup field projection for all the tables
        sJoinedGroupProjectionMap = new HashMap<String, String>();
        sJoinedGroupProjectionMap.put(JoinedGroup._ID, JoinedGroup._ID);
        sJoinedGroupProjectionMap.put(JoinedGroup.User_ID, JoinedGroup.User_ID);
        sJoinedGroupProjectionMap.put(JoinedGroup.Group_ID, JoinedGroup.Group_ID);
        sJoinedGroupProjectionMap.put(JoinedGroup.Group_Name, JoinedGroup.Group_Name);
        sJoinedGroupProjectionMap.put(JoinedGroup.Group_Description, JoinedGroup.Group_Description);
        sJoinedGroupProjectionMap.put(JoinedGroup.Role, JoinedGroup.Role);
        
        sGroupSettingProjectionMap = new HashMap<String, String>();
        sGroupSettingProjectionMap.put(GroupSetting._ID, GroupSetting._ID);
        sGroupSettingProjectionMap.put(GroupSetting.Group_ID, GroupSetting.Group_ID);
        sGroupSettingProjectionMap.put(GroupSetting.App_ID, GroupSetting.App_ID);
        sGroupSettingProjectionMap.put(GroupSetting.Setting_Name, GroupSetting.Setting_Name);
        sGroupSettingProjectionMap.put(GroupSetting.Key_Name, GroupSetting.Key_Name);
        sGroupSettingProjectionMap.put(GroupSetting.Key_Value, GroupSetting.Key_Value);
        
        sAuthAppsProjectionMap = new HashMap<String, String>();
        sAuthAppsProjectionMap.put(AuthenticatedApp._ID, AuthenticatedApp._ID);
        sAuthAppsProjectionMap.put(AuthenticatedApp.App_ID, AuthenticatedApp.App_ID);
        sAuthAppsProjectionMap.put(AuthenticatedApp.App_Privilege, AuthenticatedApp.App_Privilege);
        sAuthAppsProjectionMap.put(AuthenticatedApp.App_Restriction, AuthenticatedApp.App_Restriction);
        sAuthAppsProjectionMap.put(AuthenticatedApp.App_Name, AuthenticatedApp.App_Name);
        sAuthAppsProjectionMap.put(AuthenticatedApp.App_Vendor, AuthenticatedApp.App_Vendor);
        sAuthAppsProjectionMap.put(AuthenticatedApp.Is_Enterprise, AuthenticatedApp.Is_Enterprise);
        sAuthAppsProjectionMap.put(AuthenticatedApp.Auth_Date, AuthenticatedApp.Auth_Date);
        sAuthAppsProjectionMap.put(AuthenticatedApp.Expire_Date, AuthenticatedApp.Expire_Date);
        sAuthAppsProjectionMap.put(AuthenticatedApp.Launcher_Path, AuthenticatedApp.Launcher_Path);
        
    }
    

	@Override
	public boolean onCreate() {
		Log.d(TAG, "BackendDBHelper onCreate");
		dBHelper = new BackendDBHelper(this.getContext());
		
		return true;
	}

	@Override
	public String getType(Uri uri) {
        switch (sUriMatcher.match(uri)) {
        case JOINED_GROUP:
            return JoinedGroup.CONTENT_TYPE;
        case JOINED_GROUP_ID:
            return JoinedGroup.CONTENT_ITEM_TYPE;
        case GROUP_SETTING:
            return GroupSetting.CONTENT_TYPE;
        case GROUP_SETTING_ID:
            return GroupSetting.CONTENT_ITEM_TYPE;           
        case AUTH_APPS:
        	return AuthenticatedApp.CONTENT_TYPE;
        case AUTH_APPS_ID:
        	return AuthenticatedApp.CONTENT_ITEM_TYPE;
        default:
        	throw new IllegalArgumentException("Unknown URI " + uri);
        }
	}


    @Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
    	SQLiteDatabase db = dBHelper.getWritableDatabase();
    	int count = 0;
    	String itemId;
    	switch (sUriMatcher.match(uri)) {
    	case JOINED_GROUP:
    		count = db.delete(JoinedGroup.TABLE_NAME, selection, selectionArgs);
    		break;
    	case JOINED_GROUP_ID:
            itemId = uri.getPathSegments().get(1);
            if (!TextUtils.isEmpty(selection)) {
                count = db.delete(JoinedGroup.TABLE_NAME, JoinedGroup._ID + "=" + itemId
                    + " AND (" + selection + ')', selectionArgs);
            } else {
                count = db.delete(JoinedGroup.TABLE_NAME, JoinedGroup._ID + "=" + itemId,
                    selectionArgs); 
            }
            break;
    	case GROUP_SETTING:
    		count = db.delete(GroupSetting.TABLE_NAME, selection, selectionArgs);
    		break;
    	case GROUP_SETTING_ID:
            itemId = uri.getPathSegments().get(1);
            if (!TextUtils.isEmpty(selection)) {
                count = db.delete(GroupSetting.TABLE_NAME, GroupSetting._ID + "=" + itemId
                    + " AND (" + selection + ')', selectionArgs);
            } else {
                count = db.delete(GroupSetting.TABLE_NAME, GroupSetting._ID + "=" + itemId,
                    selectionArgs); 
            }
            break;
    	case AUTH_APPS:
    		count = db.delete(AuthenticatedApp.TABLE_NAME, selection, selectionArgs);
    		break;
    	case AUTH_APPS_ID:
            itemId = uri.getPathSegments().get(1);
            if (!TextUtils.isEmpty(selection)) {
                count = db.delete(AuthenticatedApp.TABLE_NAME, AuthenticatedApp._ID + "=" + itemId
                    + " AND (" + selection + ')', selectionArgs);
            } else {
                count = db.delete(AuthenticatedApp.TABLE_NAME, AuthenticatedApp._ID + "=" + itemId,
                    selectionArgs); 
            }
            break;
    	default:
    		throw new IllegalArgumentException("Unknown URI " + uri);
    	}
    	
    	getContext().getContentResolver().notifyChange(uri, null);
		return count;
	}

	@Override
	public Uri insert(Uri uri, ContentValues initialValues) {
    	SQLiteDatabase db = dBHelper.getWritableDatabase();

    	ContentValues values;
    	long rowId;
    	
        if (initialValues != null) {
            values = new ContentValues(initialValues);
        } else {
            values = new ContentValues();
        }
        
    	switch (sUriMatcher.match(uri)) {
    	case JOINED_GROUP:
	    	//must group id	
	        if (values.containsKey(JoinedGroup.Group_ID) == false) {
	            throw new IllegalArgumentException("group id is empty!" + uri);
	        }
	        rowId = db.insert(JoinedGroup.TABLE_NAME, null, values);
	        if (rowId > 0) {
	            Uri joinedGroupURI = ContentUris.withAppendedId(JoinedGroup.JOINEDGROUP_CONTENT_URI, rowId);
	            getContext().getContentResolver().notifyChange(joinedGroupURI, null);
	            return joinedGroupURI;
	        }
	        break;
    	case GROUP_SETTING:
	        if (values.containsKey(GroupSetting.Group_ID) == false) {
	            throw new IllegalArgumentException("group id is empty!" + uri);
	        }
	        if (values.containsKey(GroupSetting.App_ID) == false) {
	            throw new IllegalArgumentException("application id is empty!" + uri);
	        }
	        if (values.containsKey(GroupSetting.Setting_Name) == false) {
	            throw new IllegalArgumentException("setting name is empty!" + uri);
	        }
	        if (values.containsKey(GroupSetting.Key_Name) == false) {
	            throw new IllegalArgumentException("config item name is empty!" + uri);
	        }
	        rowId = db.insert(GroupSetting.TABLE_NAME, null, values);
	        if (rowId > 0) {
	            Uri groupSettingUri = ContentUris.withAppendedId(GroupSetting.GROUP_SETTING_CONTENT_URI, rowId);
	            getContext().getContentResolver().notifyChange(groupSettingUri, null);
	            return groupSettingUri;
	        }
	        break;
    	case AUTH_APPS:
	        if (values.containsKey(AuthenticatedApp.App_ID) == false) {
	            throw new IllegalArgumentException("application id is empty!" + uri);
	        }
	        if (values.containsKey(AuthenticatedApp.App_Name) == false) {
	            throw new IllegalArgumentException("application name is empty!" + uri);
	        }
	        if (values.containsKey(AuthenticatedApp.App_Privilege) == false) {
	            throw new IllegalArgumentException("application privilege is empty!" + uri);
	        }
	        if (values.containsKey(AuthenticatedApp.Expire_Date) == false) {
	            throw new IllegalArgumentException("expire date is empty!" + uri);
	        }
	        if (values.containsKey(AuthenticatedApp.Auth_Date) == false) {
	            throw new IllegalArgumentException("auth date is empty!" + uri);
	        }
	        rowId = db.insert(AuthenticatedApp.TABLE_NAME, null, values);
	        if (rowId > 0) {
	            Uri authAppUri = ContentUris.withAppendedId(AuthenticatedApp.AUTH_APP_CONTENT_URI, rowId);
	            getContext().getContentResolver().notifyChange(authAppUri, null);
	            return authAppUri;
	        }
	        break;
    	default:
    		throw new IllegalArgumentException("Unknown URI " + uri);
    	}
    	throw new SQLException("Failed to insert row into " + uri);
	}

	@SuppressWarnings("unused")
	@Override
	public Cursor query(Uri uri, String[] projection, String selection,
			String[] selectionArgs, String sortOrder) {
		
		SQLiteQueryBuilder qb = new SQLiteQueryBuilder();
		if (null == qb) {
			return null;
		}
		
    	switch (sUriMatcher.match(uri)) {
    	case JOINED_GROUP:
            qb.setTables(JoinedGroup.TABLE_NAME);
            qb.setProjectionMap(sJoinedGroupProjectionMap);
            break;
    	case JOINED_GROUP_ID:
            qb.setTables(JoinedGroup.TABLE_NAME);
            qb.setProjectionMap(sJoinedGroupProjectionMap);
            qb.appendWhere(JoinedGroup._ID + "=" + uri.getPathSegments().get(1));
            break;
    	case GROUP_SETTING:
            qb.setTables(GroupSetting.TABLE_NAME);
            qb.setProjectionMap(sGroupSettingProjectionMap);
            break;
    	case GROUP_SETTING_ID:
            qb.setTables(GroupSetting.TABLE_NAME);
            qb.setProjectionMap(sGroupSettingProjectionMap);
            qb.appendWhere(GroupSetting._ID + "=" + uri.getPathSegments().get(1));
    		break;
    	case AUTH_APPS:
            qb.setTables(AuthenticatedApp.TABLE_NAME);
            qb.setProjectionMap(sAuthAppsProjectionMap);
            break;
    	case AUTH_APPS_ID:
            qb.setTables(AuthenticatedApp.TABLE_NAME);
            qb.setProjectionMap(sAuthAppsProjectionMap);
            qb.appendWhere(AuthenticatedApp._ID + "=" + uri.getPathSegments().get(1));
            break;
    	default:
    		throw new IllegalArgumentException("Unknown URI " + uri);
    	}
        // Get the database and run the query
        SQLiteDatabase db = dBHelper.getReadableDatabase();
        Cursor c = qb.query(db, projection, selection, selectionArgs, null, null, sortOrder);

        // Tell the cursor what uri to watch, so it knows when its source data changes
        c.setNotificationUri(getContext().getContentResolver(), uri);
        
        return c;
	}

	@Override
	public int update(Uri uri, ContentValues values, String selection,
			String[] selectionArgs) {
    	SQLiteDatabase db = dBHelper.getWritableDatabase();

    	int count = 0;
    	String itemId;
    	switch (sUriMatcher.match(uri)) {
    	case JOINED_GROUP:
            count = db.update(JoinedGroup.TABLE_NAME, values, selection, selectionArgs);
            break;
    	case JOINED_GROUP_ID:
    		itemId = uri.getPathSegments().get(1);
            
            if (!TextUtils.isEmpty(selection)) {
                count = db.update(JoinedGroup.TABLE_NAME, values, JoinedGroup._ID + "=" + itemId
                  + " AND (" + selection + ')' , selectionArgs);
            } else {
                count = db.update(JoinedGroup.TABLE_NAME, values, JoinedGroup._ID + "=" + itemId
                    + "", selectionArgs);
            }
            break;
    	case GROUP_SETTING:
            count = db.update(GroupSetting.TABLE_NAME, values, selection, selectionArgs);
            break;
    	case GROUP_SETTING_ID:
    		itemId = uri.getPathSegments().get(1);
            
            if (!TextUtils.isEmpty(selection)) {
                count = db.update(GroupSetting.TABLE_NAME, values, GroupSetting._ID + "=" + itemId
                  + " AND (" + selection + ')' , selectionArgs);
            } else {
                count = db.update(GroupSetting.TABLE_NAME, values, GroupSetting._ID + "=" + itemId
                    + "", selectionArgs);
            }
    		break;
    	case AUTH_APPS:
            count = db.update(AuthenticatedApp.TABLE_NAME, values, selection, selectionArgs);
            break;
    	case AUTH_APPS_ID:
    		itemId = uri.getPathSegments().get(1);
            
            if (!TextUtils.isEmpty(selection)) {
                count = db.update(AuthenticatedApp.TABLE_NAME, values, AuthenticatedApp._ID + "=" + itemId
                  + " AND (" + selection + ')' , selectionArgs);
            } else {
                count = db.update(AuthenticatedApp.TABLE_NAME, values, AuthenticatedApp._ID + "=" + itemId
                    + "", selectionArgs);
            }
    		break;
    	default:
    		throw new IllegalArgumentException("Unknown URI " + uri);
    	}
    	
    	getContext().getContentResolver().notifyChange(uri, null);
		return count;
	}

	/** Joined group columns:group name, group id, role
	 * @author jianbinxu
	 *
	 */
	public static class JoinedGroup implements BaseColumns {

		public static final String AUTHORITY = "com.gplocation.lbs.backend";
        public static final String TABLE_NAME = "joinedgroups";

        public static final Uri JOINEDGROUP_CONTENT_URI = Uri.parse("content://com.gplocation.lbs.backend/joinedgroup");

        public static final String CONTENT_TYPE = "vnd.android.cursor.dir/com.gplocation.lbs.client.joinedgroup";
        public static final String CONTENT_ITEM_TYPE = "vnd.android.cursor.item/com.gplocation.lbs.client.joinedgroup";

        public static final String User_ID = "userid";
        //group id
        public static final String Group_ID = "groupid";
        //group name
        public static final String Group_Name = "groupname";
        // group description
        public static final String Group_Description = "groupdescription";
        
        //user role in group 
        public static final String Role = "role";

	}   
	
	/** group setting table columns:group id, appid, setting name, key, value, update
	 * @author jianbinxu
	 *
	 */
	public static class GroupSetting implements BaseColumns {
		public static final String AUTHORITY = "com.gplocation.lbs.backend";
        public static final String TABLE_NAME = "groupsettings";
        public static final Uri GROUP_SETTING_CONTENT_URI = Uri
        		.parse("content://com.gplocation.lbs.backend/groupsetting");

        public static final String CONTENT_TYPE = "vnd.android.cursor.dir/com.gplocation.lbs.backend.groupsetting";
        public static final String CONTENT_ITEM_TYPE = "vnd.android.cursor.item/com.gplocation.lbs.backend.groupsetting";

        //group id
        public static final String Group_ID = "groupid";
        public static final String App_ID = "appid";
        public static final String Setting_Name = "settingname";
        public static final String Key_Name = "keyname";
        public static final String Key_Value = "keyvalue";
		public static final String Key_Type = "type";
		public static final String Update = "updatetime";
        
	}	

	/** authenticated app table columns: app id, app privilege, app name, vendor, 
	 * enterprise, authed date, expire data 
	 * @author jianbinxu
	 *
	 */
	public static class AuthenticatedApp implements BaseColumns {
		public static final String AUTHORITY = "com.gplocation.lbs.backend";
        public static final String TABLE_NAME = "authedapps";
        public static final Uri AUTH_APP_CONTENT_URI = Uri.parse("content://com.gplocation.lbs.backend/authentiatedapp");

        public static final String CONTENT_TYPE = "vnd.android.cursor.dir/com.gplocation.lbs.backend.authentiatedapp";
        public static final String CONTENT_ITEM_TYPE = 
        		"vnd.android.cursor.item/com.gplocation.lbs.backend.authentiatedapp";

        //fields
        public static final String App_ID = "appid";
        
        //f:rw;g:rw;ps:ps;loc:0/1; whether has pri table?
        public static final String App_Privilege = "privilege";  
        public static final String App_Restriction = "restriction";  
        public static final String App_Name = "appname";
        public static final String App_Vendor = "vendor";
        public static final String Is_Enterprise = "isenterprise";
        public static final String Auth_Date = "authdate";
        public static final String Expire_Date = "expiredate";
        //start a activity if it is not running while received a massage
        public static final String Launcher_Path = "launcherpath";        
        
	}
	
	
	
	/** DB helper
	 * @author jianbinxu
	 *
	 */
	public static class BackendDBHelper extends SQLiteOpenHelper {

		public BackendDBHelper(Context context) {
			super(context, LBS_DB_NAME, null, LBS_USE_DB_VER);
		}
		
		@Override
        public void onOpen(SQLiteDatabase db) {
            Log.d(TAG, "BackendDBHelper onOpen");
        }

		@Override
		public void onCreate(SQLiteDatabase db) {
			Log.d(TAG, "onCreate to create tables");
            try {
                
            	//joined group
                db.execSQL("CREATE TABLE " + JoinedGroup.TABLE_NAME + " (" + JoinedGroup._ID
                    + " INTEGER PRIMARY KEY AUTOINCREMENT," + JoinedGroup.User_ID + " TEXT," 
                	+ JoinedGroup.Group_ID + " TEXT,"
                    + JoinedGroup.Group_Name + " TEXT," + JoinedGroup.Group_Description + " TEXT,"
                    + JoinedGroup.Role + " TEXT" 
                    + ");"); 
                
                //group setting
                db.execSQL("CREATE TABLE " + GroupSetting.TABLE_NAME + " (" + GroupSetting._ID
                    + " INTEGER PRIMARY KEY AUTOINCREMENT," + GroupSetting.Group_ID + " TEXT,"
                    + GroupSetting.App_ID + " TEXT," + GroupSetting.Setting_Name + " TEXT,"
                    + GroupSetting.Key_Name + " TEXT," + GroupSetting.Key_Value + " TEXT,"
                    + GroupSetting.Key_Type + " Text," + GroupSetting.Update + " DATE"
                    + ");"); 
            
                //authenticated app
                db.execSQL("CREATE TABLE " + AuthenticatedApp.TABLE_NAME + " (" + AuthenticatedApp._ID
                	+ " INTEGER PRIMARY KEY AUTOINCREMENT," + AuthenticatedApp.App_ID + " TEXT,"
                	+ AuthenticatedApp.App_Privilege + " TEXT," 
                	+ AuthenticatedApp.App_Restriction + " TEXT," 
                	+ AuthenticatedApp.App_Name + " TEXT,"
                	+ AuthenticatedApp.App_Vendor + " TEXT,"
                	+ AuthenticatedApp.Is_Enterprise + " BOOL,"
                	+ AuthenticatedApp.Auth_Date + " DATE,"
                	+ AuthenticatedApp.Expire_Date + " DATE,"
                	+ AuthenticatedApp.Launcher_Path + " TEXT"
                	+ ");");
            } catch (SQLException e) {
                e.printStackTrace();
            }
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS " + JoinedGroup.TABLE_NAME);
            db.execSQL("DROP TABLE IF EXISTS " + GroupSetting.TABLE_NAME);
            db.execSQL("DROP TABLE IF EXISTS " + AuthenticatedApp.TABLE_NAME);
            onCreate(db);
		}

	}
}
