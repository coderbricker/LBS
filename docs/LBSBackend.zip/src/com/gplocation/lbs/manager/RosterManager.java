// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved
package com.gplocation.lbs.manager;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.jivesoftware.smack.Roster;
import org.jivesoftware.smack.RosterEntry;
import org.jivesoftware.smack.RosterListener;
import org.jivesoftware.smack.XMPPConnection;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.packet.Presence;
import org.jivesoftware.smackx.packet.VCard;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;

import com.gplocation.lbs.data.Friend;
import com.gplocation.lbs.engine.RosterReceiveEngine;
import com.gplocation.lbs.utils.Constants;

/**
 * a singleton class to manage roster
 */
public class RosterManager {
	private static final String TAG = "RosterManager";
	
	private Roster roster;
	private Handler receiveHandler;
	private XMPPConnection connection;
	
	private static RosterManager rosterManager;
	
	
	private RosterManager() {
		
	}
	
	public static synchronized RosterManager getInstance() { 
		if (rosterManager == null) {
			rosterManager = new RosterManager();
		}
		
		return rosterManager;
	}

	private RosterListener rosterListener = new RosterListener() {
        @Override
        public void entriesAdded(Collection<String> arg0) {
        	Log.d(TAG, "RosterListener roster entriesAdded =" + arg0);
        }

        @Override
        public void entriesDeleted(Collection<String> arg0) {
        	Log.d(TAG, "RosterListener roster entriesDeleted =" + arg0);
        }

        @Override
        public void entriesUpdated(Collection<String> arg0) {
        	Log.d(TAG, "RosterListener roster entriesUpdated =" + arg0);
        	for (String entity : arg0) {
        		RosterEntry rosterEntry = roster.getEntry(entity);
        		if (rosterEntry != null) {
        			String from = entity.split("/")[0];
                    Presence bestPresence = roster.getPresence(from);

                    android.os.Message msg = new android.os.Message();
                    msg.what = RosterReceiveEngine.RETURN_PRESENCE_CHANGE_MSG;
                    Bundle bl = new Bundle();
                    bl.putInt("type", Constants.MESSAGE_FRIEND_TYPE);
                    bl.putString("friendId", from);
                    bl.putString("presence", bestPresence.toString());
                    msg.setData(bl);
                    
                    receiveHandler.sendMessage(msg);
        		}
        	}
        }

        @Override
        public void presenceChanged(Presence arg0) {
            Log.d(TAG, "roster presenceChanged + presence =" + arg0);
            String from = arg0.getFrom();
            from = from.split("/")[0];
            Presence bestPresence = roster.getPresence(from);

            android.os.Message msg = new android.os.Message();
            msg.what = RosterReceiveEngine.RETURN_PRESENCE_CHANGE_MSG;
            Bundle bl = new Bundle();
            bl.putInt("type", Constants.MESSAGE_FRIEND_TYPE);
            bl.putString("friendId", from);
            bl.putString("presence", bestPresence.toString());
            msg.setData(bl);
            
            receiveHandler.sendMessage(msg);
        }
    };

    /**
     * <p>register the observer</P>
     * @note be careful of the register time, must after the receiveManager is set
     * @param receiveManager
     */
    public void registerReceiveHandler(Handler receiveHandler) {
    	this.receiveHandler = receiveHandler;
    }
    
	/**
	 * <p>Should be called when smack connection is established</P>
	 * @param connection
	 */
	public void init(XMPPConnection connection) {
		if (connection.isConnected()) {
			this.connection = connection;
			roster = connection.getRoster();
			roster.addRosterListener(rosterListener);
		} else {
			Log.d(TAG, "connection is not connected");
		}
	}
	
	
	/**
	 * <p>Change user then reload.</P>
	 * @param connection
	 */
	public void reLoad(XMPPConnection connection) {
		if (connection.isConnected()) {
			this.connection = connection;
			if (roster != null) {
				roster.removeRosterListener(rosterListener);
			}
			
			roster = connection.getRoster();
			roster.addRosterListener(rosterListener);
			
			Log.d(TAG, "reLoad end");
		} else {
			Log.d(TAG, "connection is not connected");
		}
	}
	
	
	/**
	 * <p>Add a roster into roster entities</P>
	 * @param account
	 * @param nickName
	 * @return true, success; false, failed
	 */
	public boolean addRoster(String account, String nickName) {
		boolean res = false;
		try {
			if (roster != null) {
				roster.createEntry(account, nickName, null);
				res = true;
			} else {
				Log.d(TAG, "roster is null");
			}
		} catch (XMPPException e) {
			e.printStackTrace();
		}		
		
		return res;
	}
	
	
	/**
	 * <p></P>
	 * @param account
	 * @return true, success; false, failed
	 */
	public boolean removeRoster(String account) {
		boolean res = false;
		try {
			if (roster != null && roster.getEntry(account) != null) {
				roster.removeEntry(roster.getEntry(account));
				res = true;
			} else {
				Log.d(TAG, "roster is null or account is not exist");
			}
		} catch (XMPPException e) {
			e.printStackTrace();
		}		
		
		return res;		
	}
	
		
	/**
	 * <p>get all friends if online is false, get all online friends if online is true</P>
	 * @todo online, means available?
	 * @param online
	 * @return
	 */
	private List<Friend> getFriends(boolean online) {
		Log.d(TAG, "getFriends" + roster);
		if (roster != null) {
	        Iterator<RosterEntry> it = roster.getEntries().iterator();
	        ArrayList<Friend> friendList = new ArrayList<Friend>();
	        while (it.hasNext()) {
	            RosterEntry entry = (RosterEntry) it.next();
	            String user = entry.getUser();
	            String nick = entry.getName();
		        String state = roster.getPresence(user).toString();
		        Log.d(TAG, user + " state = " + String.valueOf(state) + "presence = " + roster.getPresence(user));
		        String email = "";
		        String phone = "";
		        
		        VCard vCard = new VCard();
		        try {
					vCard.load(connection, user);
					String vCardNick = vCard.getNickName();
					if (vCardNick != null) {
						nick = vCardNick;
					}
					email = vCard.getEmailHome();
					phone = vCard.getPhoneHome(Constants.DEFAULT_PHONE_TYPE);
					
				} catch (XMPPException e) {
					e.printStackTrace();
				}
		        
		        if (nick == null || (nick != null && "".equals(nick))) {
		        	nick = user.split("@")[0];
		        }		        
		        
		        if (!online || (online && state.contains("available"))) {
		        	Friend friend = new Friend(user, nick, email, phone, state);
		        	friendList.add(friend);
		        }
	        }
		   
	        return friendList;
		} else {
			Log.d(TAG, "roster is null");
		}
		
		return null;
	}
	
	
	public String getRosterNick(String account) {
		RosterEntry entry = roster.getEntry(account);
		String nick = account.split("@")[0];
		if (entry != null) {
			nick = entry.getName();
		}
		return nick;
	}
	
	public List<Friend> getAllFriend() {
		return getFriends(false);
	}
	
	public List<Friend> getOnlineFriend() {
		return getFriends(true);
	}
	
	
	/**
	 * <p></P>
	 * @param account
	 * @return
	 */
	public boolean contain(String account) {
		if (roster == null) {
			Log.d(TAG, "roster is null");
			return false;
		} else {
			return roster.contains(account);
		}
	}
	
	public Roster getRoster() {
		return roster;
	}

	public void setRoster(Roster roster) {
		this.roster = roster;
	}
	
}
