// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.manager;

import java.util.HashMap;

import android.content.Context;
import android.util.Log;

/**
 * authority cache
 */
public class AuthorityManager {
	
	private static final  String TAG = "AuthorityManager";
	
	/**
	 * authority string: "": no authority, r: read, w: write, rw: read & write
	 * while there is some difference in pubsub,: "": no authority, p:publish, s:subscribe, ps: publish & subscribe
	 */
	public static class Authority {
		public String friendAuthority = "";
		public String groupAuthority = "";
		public String pubsubAuthority = "";
	}
	
	
	private static AuthorityManager authorityManager;

	
	private HashMap<String, Authority> authoritys = new HashMap<String, AuthorityManager.Authority>();
	
	private AuthorityManager() {
		
	}
	
	public static synchronized AuthorityManager getInstance() { 
		Log.d(TAG, "AuthorityManager getInstance");
		if (authorityManager == null) {
			authorityManager = new AuthorityManager();
		}
		
		return authorityManager;
	}
	
	
	/**
	 * <p>Should be called when core service is setup</P>
	 * @todo read db to fill into authoritys
	 * @param connection
	 * @param context
	 */
	public void init(Context context) {
		Log.d(TAG, "init");
		// read db to fill into authoritys
		DBManager dbManager = new DBManager(context);
		dbManager.readAuthenAppsDB(authorityManager);		
	}
	
	public void add(String appId, Authority authority) {
		authoritys.put(appId, authority);
	}
	
	public void addFriendAuthority(String appId, String friendAuthority) {
		if (authoritys.get(appId) != null) {
			authoritys.get(appId).friendAuthority = friendAuthority;
		} else {
			Authority authority = new Authority();
			authority.friendAuthority = friendAuthority;
			authoritys.put(appId, authority);
		}
	}
	
	public void addGroupAuthority(String appId, String groupAuthority) {
		if (authoritys.get(appId) != null) {
			authoritys.get(appId).groupAuthority = groupAuthority;
		} else {
			Authority authority = new Authority();
			authority.groupAuthority = groupAuthority;
			authoritys.put(appId, authority);
		}
	}
	
	public void addPubsubAuthority(String appId, String pubsubAuthority) {
		if (authoritys.get(appId) != null) {
			authoritys.get(appId).pubsubAuthority = pubsubAuthority;
		} else {
			Authority authority = new Authority();
			authority.pubsubAuthority = pubsubAuthority;
			authoritys.put(appId, authority);
		}
	}
	
	
	public void remove(String appId) {
		authoritys.remove(appId);
	}
	
	public void removeFriendAuthority(String appId, String friendAuthority) {
		
	}
	
	public void removeGroupAuthority(String appId, String groupAuthority) {
		
	}
	
	public void removePubsubAuthority(String appId, String pubsubAuthority) {
	
	}
	
	public Authority get(String appId) {
		Log.d(TAG, "get " + authoritys.size());
		return authoritys.get(appId);
	}
	
	public String getFriendAuthority(String appId) {
		String res = "";
		if (authoritys.get(appId) != null) {
			res = authoritys.get(appId).friendAuthority;
		}
		
		return res;
	}
	
	public String getGroupAuthority(String appId) {
		String res = "";
		if (authoritys.get(appId) != null) {
			res = authoritys.get(appId).groupAuthority;
		}
		
		return res;
		
	}
	
	public String getPubsubAuthority(String appId) {
		String res = "";
		if (authoritys.get(appId) != null) {
			res = authoritys.get(appId).pubsubAuthority;
		}
		
		return res;
		
	}

	public HashMap<String, Authority> getAuthoritys() {
		return authoritys;
	}

	public void setAuthoritys(HashMap<String, Authority> authoritys) {
		this.authoritys = authoritys;
	}
}
