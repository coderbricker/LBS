// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.manager;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.util.Log;

import com.gplocation.lbs.contentprovider.BackendContentProvider.AuthenticatedApp;
import com.gplocation.lbs.contentprovider.BackendContentProvider.GroupSetting;
import com.gplocation.lbs.contentprovider.BackendContentProvider.JoinedGroup;
import com.gplocation.lbs.data.GroupInfo;
import com.gplocation.lbs.data.Setting;
import com.gplocation.lbs.manager.AuthorityManager.Authority;

/**
 * manage datab base
 */
public class DBManager {
	
	private static final String TAG = "DBManager";
	private ContentResolver contentResolver;
	
	public DBManager(Context context) {
		contentResolver = context.getContentResolver();
	}
		
	/**
	 * <p>read authority data into authority manager</P>
	 * @param authorityManager
	 */
	public void readAuthenAppsDB(AuthorityManager authorityManager) {
		String [] projection = {
			AuthenticatedApp.App_ID,
			AuthenticatedApp.App_Name,
			AuthenticatedApp.App_Privilege
		};
				
		Cursor cursor = contentResolver.query(AuthenticatedApp.AUTH_APP_CONTENT_URI, projection, null, null, null);
		if (cursor != null) {
			cursor.moveToFirst();
			while (!cursor.isAfterLast()) {
				String appId = cursor.getString(0);
//				String appName = cursor.getString(1);
				String privilege = cursor.getString(2);
				if (privilege != null) {
					String [] values = privilege.split(";");
					Authority authority = new Authority();
					for (int i = 0; i < values.length; ++i) {
						if (values[i].contains("IFriend")) {
							authority.friendAuthority += "r";
						} else if (values[i].contains("IOperateFriend")) {
							authority.friendAuthority += "w";
						} else if (values[i].contains("IGroup")) {
							authority.groupAuthority += "r";
						} else if (values[i].contains("IOperateGroup")) {
							authority.groupAuthority += "w";
						} else if (values[i].contains("IPublish")) {
							authority.pubsubAuthority += "p";
						} else if (values[i].contains("ISubscribe")) {
							authority.pubsubAuthority += "s";
						}
					}
					authorityManager.add(appId, authority);
					Log.d(TAG, appId + authority.friendAuthority  
						  + authority.groupAuthority + authority.pubsubAuthority);
				}
				
				cursor.moveToNext();				
			} 

			cursor.close();
		}
	}
	
	/**
	 * <p>store data into authority db</P>
	 * @param appId
	 * @param appName
	 * @param vendor
	 * @param privilege
	 * @param isEnterprise
	 * @param authDate
	 * @param expirDate
	 */
	public void storeAuthorityDB(String appId, String appName, String vendor, 
			String privilege, String restriction, String isEnterprise, String authDate, String expirDate) {
		String selection = AuthenticatedApp.App_ID + "='" + appId + "'";
		Cursor cursor = contentResolver.query(AuthenticatedApp.AUTH_APP_CONTENT_URI, null, selection, null, null);

		ContentValues values = new ContentValues();
    	values.put(AuthenticatedApp.App_ID, appId);
    	values.put(AuthenticatedApp.App_Name, appName);
    	values.put(AuthenticatedApp.App_Vendor, vendor);
    	values.put(AuthenticatedApp.App_Privilege, privilege);
    	values.put(AuthenticatedApp.App_Restriction, restriction);
    	values.put(AuthenticatedApp.Is_Enterprise, isEnterprise);
    	values.put(AuthenticatedApp.Auth_Date, authDate);
    	values.put(AuthenticatedApp.Expire_Date, expirDate);
    	
    	Log.d(TAG, "prepare to storeAuthorityDB insert");
		if (cursor != null && cursor.getCount() > 0) {
	    	contentResolver.update(AuthenticatedApp.AUTH_APP_CONTENT_URI, values, selection, null);
	    	
		} else {
			Log.d(TAG, "storeAuthorityDB insert");
	    	contentResolver.insert(AuthenticatedApp.AUTH_APP_CONTENT_URI, values);
		}
		
		if (cursor != null) {
			cursor.close();
		}
	}
	
	/**
	 * <p>insert default data</P>
	 */
	public void insertDefaultAuthorityDB() {
		storeAuthorityDB("1234567890", "testApp", "wlcscu",
				"IFriend;IOperateFriend;IGroup;IOperateGroup;IPublish;ISubscribe", 
				"", "true", "2011-12-02", "2015-12-02");
	}

	
	public void remvoeAuthoryDB(String appId) {
		String selection = AuthenticatedApp.App_ID + "='" + appId + "'";
		contentResolver.delete(AuthenticatedApp.AUTH_APP_CONTENT_URI, selection, null);
	}
	
	
	/**
	 * <p>read group setting data</P>
	 * @param appId
	 * @param groupId
	 * @param settinName
	 * @return
	 */
	public List<Setting> readGroupSetting(String appId, String groupId, String settingName) {
		ArrayList<Setting> settingList = new ArrayList<Setting>();
		
		String[] projection = { 
			GroupSetting.Key_Name,
			GroupSetting.Key_Value
//			GroupSetting.Key_Type,
		};

		String selection = GroupSetting.App_ID + "=" + appId + " AND " 
				+ GroupSetting.Group_ID + "='" + groupId + "'";
		if (settingName != null) {
			selection += " AND "
					+ GroupSetting.Setting_Name + "='" + settingName + "'";
		}
		
		Cursor cursor = contentResolver.query(GroupSetting.GROUP_SETTING_CONTENT_URI, projection, selection,
				null, null);
		if (cursor != null) {
			cursor.moveToFirst();
			while (!cursor.isAfterLast()) {
				String key = cursor.getString(cursor.getColumnIndex(GroupSetting.Key_Name));
				String value = cursor.getString(cursor.getColumnIndex(GroupSetting.Key_Value));
//				String type = cursor.getString(2);
				Setting setting = new Setting(key, value, "");
				settingList.add(setting);
				
				cursor.moveToNext();
			}

			cursor.close();
		}
		
		return settingList;
	}
	
	
	/**
	 * <p>store group setting</P>
	 * @param appId
	 * @param groupId
	 * @param settingName
	 * @param setting
	 */
	public void storeGroupSetting(String appId, String groupId, String settingName, ArrayList<Setting> setting) {
	 // store into database
		String selection = GroupSetting.App_ID + "='" + appId
				+ "' AND " + GroupSetting.Group_ID + "='" + groupId 
				+ "' AND " + GroupSetting.Setting_Name + "='" + settingName + "'";
		Cursor cursor = contentResolver.query(GroupSetting.GROUP_SETTING_CONTENT_URI, null, selection, null, null);
		if (cursor != null && cursor.getCount() > 0) {
			contentResolver.delete(GroupSetting.GROUP_SETTING_CONTENT_URI, selection, null);
		} 
		

		if (cursor != null) {
			cursor.close();
		}
		
		insertGroupSetting(appId, groupId, settingName, setting);
	}
	
	/**
	 * <p>Insert all settings into group setting db, one row is a setting</P>
	 * @param appId
	 * @param groupId
	 * @param settingName
	 * @param settings
	 * @return
	 */
	private boolean insertGroupSetting(String appId, String groupId, String settingName, List<Setting> settings) {
		for (Setting setting : settings) {
			ContentValues values = new ContentValues();
			values.put(GroupSetting.App_ID, appId);
			values.put(GroupSetting.Group_ID, groupId);
			values.put(GroupSetting.Setting_Name, settingName);
			
			values.put(GroupSetting.Key_Name, setting.getKey());
//			values.put(GroupSetting.Key_Type, setting.getType());
			values.put(GroupSetting.Key_Value, setting.getValue());
			
			contentResolver.insert(GroupSetting.GROUP_SETTING_CONTENT_URI, values);
		}
		return true;
	}
	
	
	
	/**
	 * <p>delete group setting</P>
	 * @param appId
	 * @param groupId
	 * @param settingName
	 */
	public void deleteGroupSetting(String appId, String groupId, String settingName) {
		 // store into database
		String selection = GroupSetting.App_ID + "='" + appId
					+ "' AND " + GroupSetting.Group_ID + "='" + groupId 
					+ "' AND " + GroupSetting.Setting_Name + "='" + settingName + "'";
			
		contentResolver.delete(GroupSetting.GROUP_SETTING_CONTENT_URI, selection, null);
	}

	/**
	 * <p>Read all joined group</P>
	 * @return
	 */
	public List<GroupInfo> readJoinedGroup(String userId) {
		ArrayList<GroupInfo> groups = new ArrayList<GroupInfo>();
		
		String[] projection = { 
			JoinedGroup.Group_ID,
			JoinedGroup.Group_Name,
			JoinedGroup.Group_Description
		};
		
		String selection = JoinedGroup.User_ID + "='" + userId + "'";

		Cursor cursor = contentResolver.query(JoinedGroup.JOINEDGROUP_CONTENT_URI, projection, selection,
				null, null);
		if (cursor != null) {
			cursor.moveToFirst();
			while (!cursor.isAfterLast()) {
				String groupId = cursor.getString(0);
				String groupName = cursor.getString(1);
				String description = cursor.getString(2);
//				String role = cursor.getString(3);
				GroupInfo groupInfo = new GroupInfo(groupId, groupName, description);
				groups.add(groupInfo);
				
				cursor.moveToNext();
			}

			cursor.close();
		}
		
		return groups;
	}
	
	/**
	 * <p>get role from the joined group database</P>
	 * @param groupId
	 * @return
	 */
	public String readRole(String userId, String groupId) {
		String role = "";
		String[] projection = { 
			JoinedGroup.Group_ID,
			JoinedGroup.Role
		};
		
		String where = JoinedGroup.User_ID + "='" + userId + "' AND "
				+ JoinedGroup.Group_ID + "='" + groupId + "'";

		Cursor cursor = contentResolver.query(JoinedGroup.JOINEDGROUP_CONTENT_URI, projection, where,
				null, null);
		if (cursor != null && cursor.getCount() > 0) {
			cursor.moveToFirst();
			role = cursor.getString(1);
		}
		
		if (cursor != null) {
			cursor.close();
		}
			
		return role;
	}
	
	
	/**
	 * <p>inset a group infomation into joined group</P>
	 * @param groupInfo
	 * @return
	 */
	public boolean insertJoinedGroup(GroupInfo groupInfo, String userId, String role) {
		ContentValues values = new ContentValues();
		values.put(JoinedGroup.User_ID, userId);
		values.put(JoinedGroup.Group_ID, groupInfo.getGroupId());
		values.put(JoinedGroup.Group_Name, groupInfo.getGroupName());
		values.put(JoinedGroup.Group_Description, groupInfo.getGroupDescription());
		values.put(JoinedGroup.Role, role);
		
		contentResolver.insert(JoinedGroup.JOINEDGROUP_CONTENT_URI, values);
		return true;
	}
	
	/**
	 * <p>delete a joined group in the database</P>
	 * @param groupId
	 * @return
	 */
	public boolean deleteJoinedGroup(String groupId) {
		String where = JoinedGroup.Group_ID + "='" + groupId + "'";
		contentResolver.delete(JoinedGroup.JOINEDGROUP_CONTENT_URI, where, null);
		return true;
	}
	
}
