// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.manager;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.jivesoftware.smack.Connection;
import org.jivesoftware.smack.XMPPConnection;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Presence;
import org.jivesoftware.smackx.Form;
import org.jivesoftware.smackx.FormField;
import org.jivesoftware.smackx.ServiceDiscoveryManager;
import org.jivesoftware.smackx.muc.HostedRoom;
import org.jivesoftware.smackx.muc.InvitationListener;
import org.jivesoftware.smackx.muc.MultiUserChat;
import org.jivesoftware.smackx.packet.DiscoverInfo;
import org.jivesoftware.smackx.packet.VCard;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;

import com.gplocation.lbs.application.MainApplication;
import com.gplocation.lbs.data.GroupInfo;
import com.gplocation.lbs.data.Member;
import com.gplocation.lbs.engine.GroupReceiveEngine;
import com.gplocation.lbs.service.LBSCoreService;
import com.gplocation.lbs.utils.Constants;



/**
 * group manager, stored the joined groups
 */
public class GroupManager {
	
	private static final  String TAG = "GroupManager";
	
	private static GroupManager groupManager;
	
	private ArrayList<GroupInfo> groupList = new ArrayList<GroupInfo>();
	
	private XMPPConnection connection;
	private Context context;
	private ServiceDiscoveryManager serviceManager;
	private Handler receiveHandler;
	private GroupMemberManager groupMemberManager;
	private InvitationListener invitationListener;
	
	private GroupManager() {
		
	}
	
	public static synchronized GroupManager getInstance() { 
		if (groupManager == null) {
			groupManager = new GroupManager();
		}
		
		return groupManager;
	}
	
	
	/**
	 * <p>Should be called when smack connection is established</P>
	 * @param connection
	 * @param context
	 */
	public void init(XMPPConnection connection, Context context, ServiceDiscoveryManager serviceManager) {
		if (connection.isConnected()) {
			this.connection = connection; 
			this.context = context;
			this.serviceManager = serviceManager;
			MainApplication mainApplication = ((MainApplication) ((LBSCoreService) context).getApplication());
			this.groupMemberManager =  mainApplication.groupMemberManager;
			
			String userId = mainApplication.userInfo.getUserId();
			
			initGroupList(userId);
			addInvitationListener();
			
			// init groupmembermanager
			groupMemberManager.init(context);
		} else {
			Log.d(TAG, "connection is not connected");
		}
	}
	
	/**
	 * <p>Change user then reload</P>
	 * @param connection
	 * @param context
	 * @param serviceManager
	 */
	public void reLoad(XMPPConnection connection, Context context, ServiceDiscoveryManager serviceManager) {
		if (connection.isConnected()) {
			this.connection = connection; 
			this.context = context;
			this.serviceManager = serviceManager;
			MainApplication mainApplication = ((MainApplication) ((LBSCoreService) context).getApplication());
			this.groupMemberManager =  mainApplication.groupMemberManager;
			
			String userId = mainApplication.userInfo.getUserId();
			
			initGroupList(userId);
			Log.d(TAG, "initGroupList end");
			// add listener doesn't return.
//			addInvitationListener();
//			MultiUserChat.addInvitationListener(connection, invitationListener);
			Log.d(TAG, "addInvitationListener end");
			
			// init groupmembermanager
			groupMemberManager.reLoad(context);

			Log.d(TAG, "reLoad end");
		} else {
			Log.d(TAG, "connection is not connected");
		}
	}
	
	
	
	/**
	 * @brief <p>
	 *        Global invitation listener
	 *        </P>
	 */
	private void addInvitationListener() {
//		if (invitationListener != null) {
//			MultiUserChat.removeInvitationListener(connection, invitationListener);
//		}
		
		invitationListener = new InvitationListener() {
			@Override
			public void invitationReceived(Connection arg0, String room, String inviter, 
					String reason, String password, Message message) {

				Log.d(TAG, "GroupManager addInvitationListener, invitationReceived");
				GroupInfo domain = new GroupInfo(room, room.split("@")[0], null);
				boolean contain = groupList.contains(domain);
				
				VCard vCard = new VCard();
				try {
					vCard.load(connection, inviter);
				} catch (XMPPException e) {
					e.printStackTrace();
				}
				
				String inviterNick = vCard.getNickName();
				if (inviterNick == null || "".equals(inviterNick)) {
					inviterNick = inviter.split("@")[0];
				}
				
				if (!contain) {
					android.os.Message msg = new android.os.Message();
					msg.what = GroupReceiveEngine.RETURN_INVITE_REQUEST_MSG;
					
					Bundle bl = new Bundle();
					bl.putInt("type", Constants.MESSAGE_GROUP_TYPE);
					bl.putString("groupId", room);
					bl.putString("inviter", inviterNick);
					bl.putString("reason", reason);
					msg.setData(bl);
					
					receiveHandler.sendMessage(msg);
				}
			}
		};
		
		MultiUserChat.addInvitationListener(connection, invitationListener);
	}

	
	
	/**
	 * <p>Read grouplist from DB</P>
	 * @param context
	 */
	private void initGroupList(String userId) {		
		DBManager dbManager = new DBManager(context);
		
		if (!groupList.isEmpty()) {
			groupList.clear();
		}
		this.groupList = (ArrayList<GroupInfo>) dbManager.readJoinedGroup(userId);
	}
	
	
	
	/**
	 * <p>Create a new group</P>
	 * @param groupId
	 * @param description
	 * @param creator
	 * @return
	 */
	public boolean createGroup(String groupId, String description, String creator) {
		Log.d(TAG, "createGroup");
		
		String group = groupId;
		if (!groupId.contains("@")) {
			group += "@conference.motolbs.com";
		}
		
		MultiUserChat multiUserChat = new MultiUserChat(connection, group);
		String groupScr = description;

		boolean res = false;
		try {
			multiUserChat.join(creator);
			
			if (groupScr == null) {
				groupScr = "";
			}
			
			Form form = multiUserChat.getConfigurationForm();
			Form ansnswerForm = form.createAnswerForm();
			Iterator<FormField> fields = form.getFields();
			while (fields.hasNext()) {
				FormField field = (FormField) fields.next();

				if (!FormField.TYPE_HIDDEN.equals(field.getType())
						&& field.getVariable() != null) {
					// Sets the default value as the answer
					ansnswerForm.setDefaultAnswer(field.getVariable());
					if (field.getVariable().equals("muc#roomconfig_roomdesc")) {
						ansnswerForm.setAnswer("muc#roomconfig_roomdesc", groupScr);
					}
				}

			}
			multiUserChat.sendConfigurationForm(ansnswerForm);

			res = true;
		} catch (Exception e) {
			Log.d(TAG, e.toString());
		}
		
		Log.d(TAG, "createGroup " + groupId + " end" + res);
		if (res) {
			Log.d(TAG, "createGroup " + groupId + " success");
			GroupInfo groupInfo = new GroupInfo(group, group.split("@")[0], description);
//			this.groupList.add(groupInfo);
			this.add(groupInfo);
			
			
			String userId = connection.getUser().split("/")[0];
			
			// store into database
    		DBManager dbManager = new DBManager(context);
    		dbManager.insertJoinedGroup(groupInfo, userId, "owner");
		}
		
		return res;
	}
	
	/**
	 * <p>Remove a group</P>
	 * @param groupId
	 * @param creator
	 * @return
	 */
	public boolean remvoeGroup(String groupId, String creator) {
		boolean res = true;
		MultiUserChat multiUserChat = new MultiUserChat(connection, groupId.trim());
		try {
			multiUserChat.destroy("destroy", creator);
		} catch (XMPPException e) {
			e.printStackTrace();
			res = false;
		}
		
		if (res) {
			remove(groupId);
			this.groupMemberManager.removeGroup(groupId);
			
			// store into database
    		DBManager dbManager = new DBManager(context);
    		dbManager.deleteJoinedGroup(groupId);
    					
			// setting name is groupId
			String appId = "1234567890";
	 	    dbManager.deleteGroupSetting(appId, groupId, groupId);
		}
		
		return res;
	}
	
	/**
	 * <p>exit a group</P>
	 * @param groupId
	 * @return
	 */
	public boolean exitGroup(String groupId) {
		Presence setReq = new Presence(Presence.Type.unavailable);
		setReq.setTo(groupId.trim());
		connection.sendPacket(setReq);
		
		remove(groupId);
		this.groupMemberManager.removeGroup(groupId);

		// store into database
		DBManager dbManager = new DBManager(context);
		dbManager.deleteJoinedGroup(groupId);
		
		// setting name is groupId
		String appId = "1234567890";
		dbManager.deleteGroupSetting(appId, groupId, groupId);
			 	    
		return true;
	}
	
	/**
	 * <p>invite a user into a group</P>
	 * @param groupId
	 * @param userId
	 * @return
	 */
	public boolean inviteUserIntoGroup(String groupId, String userId) {
		MultiUserChat multiUserChat = new MultiUserChat(connection, groupId);
		multiUserChat.invite(userId, "join me!");
		
		return true;
	}
	
	/**
	 * <p>only join into a group</P>
	 * @param groupId
	 * @param userName
	 * @return
	 */
	public boolean simpleJoinGroup(String groupId, String userName) {
		boolean res = false;
		MultiUserChat multiUserChat = new MultiUserChat(connection, groupId);
		try {
			multiUserChat.join(userName);
			res = true;
		} catch (XMPPException e) {
			e.printStackTrace();
		}
		
		return res;
	}
	
	/**
	 * <p>join a group and store into db if successed</P>
	 * @param groupId
	 * @param userId
	 * @return
	 */
	public boolean joinGroup(String groupId, String userName) {
		boolean res = simpleJoinGroup(groupId, userName);

		Log.d(TAG, "joinGroup res " + res);
		if (res) {
			synchronized (this) {
				if (contain(groupId) > 0) {
					return false;
				}
				
				String description = getGroupDescriptionFromService(groupId);
				Log.d(TAG, "joinGroup add" + description);
				GroupInfo groupInfo = new GroupInfo(groupId, groupId.split("@")[0], description);
				this.add(groupInfo);
//				this.groupList.add(groupInfo);
				Log.d(TAG, "joinGroup add" + groupId);
				
				// store into database
				MainApplication mainApplication = ((MainApplication) ((LBSCoreService) context).getApplication());
				String userId = mainApplication.userInfo.getUserId();
	    		DBManager dbManager = new DBManager(context);
	    		dbManager.insertJoinedGroup(groupInfo, userId, "none");
			}
			
		}
		return res;	
	}
	
	/**
	 * <p>Remove/kick out user</P>
	 * @param groupId
	 * @param userId
	 * @return
	 */
	public boolean removeMember(String groupId, String userId) {
//		boolean res = true;
//		try {
//			this.getListener(groupId).multiUserChat.kickParticipant(userId.split("@")[0], "");
//		} catch (XMPPException e) {
//			res = false;
//			e.printStackTrace();
//		}
		
		MultiUserChat multiUserChat = new MultiUserChat(connection, groupId);
		boolean res = true;
		try {
			ArrayList<Member> members = groupMemberManager.getMembers(groupId).getMembers();
			boolean isOwner = false;
			String account = "";
			for (int i = 0; i < members.size(); ++i) {
				if (members.get(i).nick.equals(userId) || members.get(i).account.equals(userId)) {
					if (members.get(i).role.equals("owner")) {
						isOwner = true;
						account = members.get(i).account;
					}
					break;
				}
			}
			
			if (isOwner) {
				multiUserChat.revokeOwnership(account);
				multiUserChat.revokeAdmin(account);
				multiUserChat.revokeMembership(account);
			}
			
			
			multiUserChat.kickParticipant(userId.split("@")[0], "");
		} catch (XMPPException e) {
			res = false;
			e.printStackTrace();
		}
				
		return res;
	}
	
	/**
	 * <p></P>
	 * @param groupId
	 * @param userId
	 * @return
	 */
	public boolean setUserAsOwner(String groupId, String userId) {
		MultiUserChat muc = new MultiUserChat(connection, groupId);
		boolean success = true;
		try {
			muc.grantOwnership(userId);
		} catch (XMPPException e) {
			success = false;
			e.printStackTrace();
		}
		
		return success;
	}
	
	
	
	/**
	 * cache the search result
	 */
	private HashMap<String, List<HostedRoom>> cachedSearchResult = new HashMap<String, List<HostedRoom>>();
	
	
	private List<HostedRoom> searchGroupFromServerInternal(String key, int count) {
		ArrayList<HostedRoom> result = new ArrayList<HostedRoom>();
		if (cachedSearchResult.containsKey(key)) {
			for (int i = 0; 
				 i < cachedSearchResult.get(key).size(); 
				 ++i) {
				result.add(cachedSearchResult.get(key).get(i));
			}
		} else {
			cachedSearchResult.clear();
			ArrayList<HostedRoom> rooms = new ArrayList<HostedRoom>(); 
			
			try {
				Collection<String> services = MultiUserChat.getServiceNames(connection);
				for (String service : services) {
					Log.d(TAG, "getServiceNames+service=" + service);

					Collection<HostedRoom> hostedRoom = MultiUserChat.getHostedRooms(connection, service);
					if (hostedRoom != null && !hostedRoom.isEmpty()) {
						for (HostedRoom k : hostedRoom) {
							Log.d(TAG, "getHostedRooms jid=" + k.getJid());
												
							if (k.getName().contains(key) || k.getJid().contains(key)) {
								rooms.add(k);
							}
						}
					}
				}
				
				cachedSearchResult.put(key, rooms);
				
				return searchGroupFromServerInternal(key, count);
								
			} catch (XMPPException e1) {
				e1.printStackTrace();
			}
			
		}
				
		return result;
	}
	
	/**
	 * <p>Search Group from key</P>
	 * @param key
	 * @return
	 */
	public List<GroupInfo> searchGroupFromServer(String key, int count) {
		
		ArrayList<GroupInfo> resGroups = new ArrayList<GroupInfo>();
		
		ArrayList<HostedRoom> rooms = (ArrayList<HostedRoom>) searchGroupFromServerInternal(key, count);
		for (int i = 0; i < rooms.size(); ++i) {
			GroupInfo group = new GroupInfo(rooms.get(i).getJid());
			group.setGroupName(rooms.get(i).getName());
			
			DiscoverInfo info = null;
			try {
				info = serviceManager.discoverInfo(rooms.get(i).getJid());
			} catch (XMPPException e) {
				e.printStackTrace();
			}

			Form form = Form.getFormFrom(info);
			if (form != null) {
				FormField descField = form.getField("muc#roominfo_description");
				String description = descField == null ? "": descField.getValues().next();
				group.setGroupDescription(description);
			}
			
			resGroups.add(group);
		}
		
		
		return resGroups;
	}
	
	
	/**
	 * <p>Get group description from ServiceDiscoveryManager</P>
	 * @param serviceManager
	 * @param groupId
	 * @return
	 */
	public String getGroupDescriptionFromService(String groupId) {
		
		String description = null;
		DiscoverInfo info = null;
		try {
			info = serviceManager.discoverInfo(groupId);
		} catch (XMPPException e) {
			e.printStackTrace();
		}
		Form form = Form.getFormFrom(info);
		if (form != null) {
			FormField descField = form.getField("muc#roominfo_description");
			description = descField == null ? "" : descField.getValues().next();

//			FormField subjField = form.getField("muc#roominfo_subject");
//			String subject = subjField == null ? "" : subjField.getValues().next();

			// FormField occCountField =
			// form.getField("muc#roominfo_occupants");
			// int occupantsCount = occCountField == null ? -1 :
			// Integer.parseInt(occCountField.getValues()
			// .next())

			Log.d(TAG, "info getDescription=" + description + "room=" + groupId
					+ "subject=" + "occupant=");
		}
		
		return description;
	}
	
	/**
	 * <p>add a group information, overwrite the description of the older one, if exist</P>
	 * @param groupInfo
	 */
	public void add(GroupInfo groupInfo) {
		int loc = contain(groupInfo.getGroupName());
		if (loc > -1) {
			if (groupInfo.getGroupDescription() != null) {
				this.groupList.get(loc).setGroupDescription(groupInfo.getGroupDescription());
			}
		} else {
			this.groupList.add(groupInfo);
		}
	}
	
	/**
	 * <p>add a group information, overwrite the description of the older one, if exist</P>
	 * @param groupId
	 * @param description
	 */
	public void add(String groupId, String description) {
		int loc = contain(groupId);
		if (loc > -1) {
			if (description != null) {
				this.groupList.get(loc).setGroupDescription(description);
			}
		} else {
			this.groupList.add(new GroupInfo(groupId, groupId.split("@")[0], description));
		}
	}
	
	/**
	 * <p>remove a group if exist</P>
	 * @param groupInfo
	 */
	public void remove(GroupInfo groupInfo) {
		int loc = contain(groupInfo.getGroupId());
		if (loc > -1) {
			this.groupList.remove(loc);
		}
	}
	
	/**
	 * <p>remove a group if exist</P>
	 * @param groupId
	 */
	public void remove(String groupId) {
		int loc = contain(groupId);
		if (loc > -1) {
			this.groupList.remove(loc);	
		}	
	}
	
	
	/**
	 * <p>get group informatin from grouplist</P>
	 * @param groupId
	 * @return
	 */
	public String getGroupDescription(String groupId) {
		int loc = contain(groupId);
		if (loc > -1) {
			return this.groupList.get(loc).getGroupDescription();
		}
		
		return null;
	}
	
	/**
	 * <p>get group information from grouplist</P>
	 * @param groupId
	 * @return
	 */
	public GroupInfo getGroupInfo(String groupId) {
		Log.d(TAG, "getGroupInfo" + groupId);
		int loc = contain(groupId);
		if (loc > -1) {
			return this.groupList.get(loc);
		} else {
			Log.d(TAG, "getGroupInfo null");
			return null;
		}
	}
	
	
	public boolean setGroupInfo(GroupInfo groupInfo) {
		MultiUserChat muc = new MultiUserChat(connection, groupInfo.getGroupId());
		
		boolean res = false;
		Form form;
		try {
			form = muc.getConfigurationForm();
			Form answerForm = form.createAnswerForm();
			answerForm.setAnswer("muc#roomconfig_roomname", groupInfo.getGroupName());
			answerForm.setAnswer("muc#roomconfig_roomdesc", groupInfo.getGroupDescription());
			muc.sendConfigurationForm(answerForm);
			
			res = true;
		} catch (XMPPException e) {
			e.printStackTrace();
		}
		
		return res;
	}
		
	/**
	 * <p>whether the grouplist contain a group</P>
	 * @param groupId
	 * @return, the location in group list, and -1 if not exist
	 */
	public int contain(String groupId) {
		for (int i = 0; i < groupList.size(); ++i) {
			if (groupList.get(i).getGroupId().equals(groupId)) {
				return i;
			}
		}
		
		return -1;
	}
		
	public ArrayList<GroupInfo> getGroupList() {
		return groupList;
	}

	public void setGroupList(ArrayList<GroupInfo> groupList) {
		this.groupList = groupList;
	}
	
	  /**
     * <p>register the observer</P>
     * @note be careful of the register time, must after the receiveManager is set
     * @param receiveManager
     */
    public void registerReceiveHandler(Handler receiveHandler) {
    	this.receiveHandler = receiveHandler;
    }
}
