// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.manager;

import com.gplocation.lbs.client.IGeneralListener;
import com.gplocation.lbs.client.friend.IFriendListener;
import com.gplocation.lbs.client.group.IGroupListener;
import com.gplocation.lbs.client.internal.IInternalListener;
import com.gplocation.lbs.client.pubsub.IPubSubListener;
import com.gplocation.lbs.template.TemplateListeners;

/**
 * @brief manage listeners to return messages to client
 */
public class ReceiveManager {
    
//	private final static String TAG = "ReceiveManager";
	private static ReceiveManager receiveManager;
	
	//
	private TemplateListeners<IGeneralListener> generalListeners = new TemplateListeners<IGeneralListener>();
	private TemplateListeners<IFriendListener> friendListeners = new TemplateListeners<IFriendListener>();
	private TemplateListeners<IGroupListener> groupListeners = new TemplateListeners<IGroupListener>();
	private TemplateListeners<IPubSubListener> pubSubListeners = new TemplateListeners<IPubSubListener>();
	private TemplateListeners<IInternalListener> internalListeners = new TemplateListeners<IInternalListener>();
	

	private ReceiveManager() {
		
	}
	
	public static synchronized ReceiveManager getInstance() { 
		if (receiveManager == null) {
			receiveManager = new ReceiveManager();
		}
		
		return receiveManager;
	}
	
	public void removeAllListener() {
		generalListeners.getListeners().clear();
		friendListeners.getListeners().clear();
		groupListeners.getListeners().clear();
		pubSubListeners.getListeners().clear();
		internalListeners.getListeners().clear();
	}
	
	public void removeListener(String appId) {
		generalListeners.remove(appId);
		friendListeners.remove(appId);
		groupListeners.remove(appId);
		pubSubListeners.remove(appId);
		internalListeners.remove(appId);
	}
    

	public TemplateListeners<IGeneralListener> getGeneralListeners() {
		return generalListeners;
	}

	public void setGeneralListeners(TemplateListeners<IGeneralListener> generalListeners) {
		this.generalListeners = generalListeners;
	}

	public TemplateListeners<IFriendListener> getFriendListeners() {
		return friendListeners;
	}

	public void setFriendListeners(TemplateListeners<IFriendListener> friendListeners) {
		this.friendListeners = friendListeners;
	}

	public TemplateListeners<IGroupListener> getGroupListeners() {
		return groupListeners;
	}

	public void setGroupListeners(TemplateListeners<IGroupListener> groupListeners) {
		this.groupListeners = groupListeners;
	}

	public TemplateListeners<IPubSubListener> getPubSubListeners() {
		return pubSubListeners;
	}

	public void setPubSubListeners(TemplateListeners<IPubSubListener> pubSubListeners) {
		this.pubSubListeners = pubSubListeners;
	}

	public TemplateListeners<IInternalListener> getInternalListeners() {
		return internalListeners;
	}

	public void setInternalListeners(TemplateListeners<IInternalListener> internalListeners) {
		this.internalListeners = internalListeners;
	}

}
