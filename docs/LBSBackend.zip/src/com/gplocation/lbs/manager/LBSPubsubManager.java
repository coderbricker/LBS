package com.gplocation.lbs.manager;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.jivesoftware.smack.XMPPConnection;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.packet.PacketExtension;
import org.jivesoftware.smackx.packet.DiscoverItems;
import org.jivesoftware.smackx.pubsub.Item;
import org.jivesoftware.smackx.pubsub.ItemPublishEvent;
import org.jivesoftware.smackx.pubsub.LeafNode;
import org.jivesoftware.smackx.pubsub.PayloadItem;
import org.jivesoftware.smackx.pubsub.PubSubManager;
import org.jivesoftware.smackx.pubsub.Subscription;
import org.jivesoftware.smackx.pubsub.listener.ItemEventListener;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.gplocation.lbs.application.MainApplication;
import com.gplocation.lbs.data.LBSUserExtend;
import com.gplocation.lbs.engine.PubsubReceiveEngine;
import com.gplocation.lbs.packetprovider.PubsubExtensionProvider;
import com.gplocation.lbs.service.LBSCoreService;
import com.gplocation.lbs.utils.Constants;

/**
 * deal with all Pubsub request
 * Briefly describe what this class does.
 */
public class LBSPubsubManager {
	private static final String TAG = "LBSPubsubManager";
    
    private static LBSPubsubManager lbsPubsubManager;
    private XMPPConnection connection;
    private Context context;
    private PubSubManager pubSubManager;

    private Handler receiveHandler;
    
    private LBSPubsubManager() {
        
    }
    
    public static synchronized LBSPubsubManager getInstance() { 
        if (lbsPubsubManager == null) {
            lbsPubsubManager = new LBSPubsubManager();
        }
        
        return lbsPubsubManager;
    }
    
    /**
     * init LBSPubsubManager
     * Briefly describe what it does.
     * <p>If necessary, describe how it does and how to use it.</P>
     * @param connection XMPPConnection
     * @param context
     */
    public void init(XMPPConnection connection, Context context) {
        if (connection.isConnected()) {
            this.connection = connection; 
            this.context = context;
            pubSubManager = new PubSubManager(this.connection, "pubsub.motolbs.com");

			Log.d(TAG, "reLoad end");
        } else {
            Log.d(TAG, "connection is not connected");
        }
    }
    
    /**
     * AddItemEventListener to node
     * Briefly describe what it does.
     * <p>If necessary, describe how it does and how to use it.</P>
     * @param nodeId
     * @param appId
     * @param isFirstSub
     */
    private void nodeAddItemEventListener(final String nodeId, final String appId, boolean isFirstSub){
        try {
            LeafNode node = (LeafNode) pubSubManager.getNode(nodeId);
            node.addItemEventListener(new ItemEventListener<Item>() {
                @Override
                public void handlePublishedItems(ItemPublishEvent<Item> arg0) {
                    List<Item> items = arg0.getItems();
                    ArrayList<String> itemsData = new ArrayList<String>();
                    for (Item item : items) {
                        @SuppressWarnings("unchecked")
						PayloadItem<PacketExtension> payloadItem = (PayloadItem<PacketExtension>) item;
                        PubsubExtensionProvider.PubsubExtension extension = 
                        		(PubsubExtensionProvider.PubsubExtension) (payloadItem.getPayload());
                        String nodeAppId = extension.getAppId();
                        if (nodeAppId !=null && nodeAppId.equals(appId)) {
                            itemsData.add(extension.getMsg());
                        }
                    }
                    if (itemsData.size() > 0) {
                        Message msg = new Message();
                        msg.what = PubsubReceiveEngine.UPDATEONTOPIC;
                        Bundle bl = new Bundle();
                        bl.putStringArrayList("itemsData", itemsData);
                        bl.putString("topic", nodeId);
                        bl.putString("appId", appId);
                        bl.putInt("type", Constants.MESSAGE_PUBSUB_TYPE);
                        msg.setData(bl);
                        
                        receiveHandler.sendMessage(msg);
                    }
                }
            });
            if (isFirstSub) {
                LBSUserExtend lbsUser = ((MainApplication) (((LBSCoreService) context).getApplication())).userInfo;
                node.subscribe(lbsUser.getUserName() + "@" + lbsUser.getDomain());
            }
        } catch (XMPPException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * add ItemEventListener to the topic Subscribed
     * Briefly describe what it does.
     * <p>If necessary, describe how it does and how to use it.</P>
     * @param appId
     */
    public void initSubscribed(String appId){
//        LocationTrackEngine locationTrackEngine = new LocationTrackEngine(connection, context, 60, 0);
//        locationTrackEngine.uploadLocationRegular();
        try {
            List<Subscription> subscriptions = pubSubManager.getSubscriptions();
            for (Subscription subscription : subscriptions) {
                nodeAddItemEventListener(subscription.getNode(), appId,false);
            }
        } catch (XMPPException e) {
            e.printStackTrace();
        }
    }

    /**
     * subscribe a topic 
     * Briefly describe what it does.
     * <p>If necessary, describe how it does and how to use it.</P>
     * @param topic
     * @param appId
     */
    public void subscribeItem(String topic,String appId){
        try {
            List<Subscription> subscriptions = pubSubManager.getSubscriptions();
            for (Subscription subscription : subscriptions) {
                if(subscription.getNode().equals(topic)){
                    return;
                }
            }
            nodeAddItemEventListener(topic, appId,true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /**
     * unSubscribe a topic 
     * Briefly describe what it does.
     * <p>If necessary, describe how it does and how to use it.</P>
     * @param topic
     * @param appId
     */
    public void unSubscribeItem(String topic,String appId){
        try {
            LeafNode node = (LeafNode) pubSubManager.getNode(topic);
            LBSUserExtend lbsUser = ((MainApplication)(((LBSCoreService) context).getApplication())).userInfo;
            node.unsubscribe(lbsUser.getUserName() + "@" + lbsUser.getDomain());
        } catch (XMPPException e) {
            e.printStackTrace();
        }
    }
    /**
     * publish a item to topic
     * Briefly describe what it does.
     * <p>If necessary, describe how it does and how to use it.</P>
     * @param topic
     * @param content
     * @param withlocation
     * @param appId
     */
    public void publishItem(String topic,String content,boolean withLocation,String appId){
        try {
            LeafNode node = (LeafNode) pubSubManager.getNode(topic);
            
            PubsubExtensionProvider.PubsubExtension payloadExt = new PubsubExtensionProvider.PubsubExtension();
           
            if (withLocation) {
              payloadExt.setLoc(true);
//              Location location = LocationHelper.getLocation(context);
              payloadExt.setAccuracy("11");
              payloadExt.setLatitude("123");
              payloadExt.setLongitude("37"); 
            }else{
                payloadExt.setLoc(false);
            }
            if (content != null && !"".equals(content) && !"null".equals(content)) {
                payloadExt.setMsg(content);
            }

            payloadExt.setAppId(appId);
            
            PayloadItem<PacketExtension> payloadItem = new PayloadItem<PacketExtension>(null, payloadExt);
            node.publish(payloadItem);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void fetchTopics(String parentPath,String patten,String appId){
        
        try {
//            parentPath = "leon001";
            Iterator<DiscoverItems.Item> iterator = pubSubManager.discoverNodes(parentPath).getItems();
            ArrayList<String> leafNodes = new ArrayList<String>();
            while (iterator.hasNext()) {
                DiscoverItems.Item item = iterator.next();
                leafNodes.add(item.getNode());
            }
            
            Message msg = new Message();
            msg.what = PubsubReceiveEngine.FETCHTOPICS;
            Bundle bl = new Bundle();
            bl.putStringArrayList("leafNodes", leafNodes);
            bl.putString("appId", appId);
            bl.putInt("type", Constants.MESSAGE_PUBSUB_TYPE);
            msg.setData(bl);
            
            receiveHandler.sendMessage(msg);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /**
     * 
     * Briefly describe what it does.
     * <p>If necessary, describe how it does and how to use it.</P>
     * @param receiveHandler
     */
    public void registerReceiveHandler(Handler receiveHandler) {
        this.receiveHandler = receiveHandler;
    }
}
