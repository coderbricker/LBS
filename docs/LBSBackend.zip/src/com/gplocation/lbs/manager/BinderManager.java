// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.manager;

import com.gplocation.lbs.client.friend.IFriend;
import com.gplocation.lbs.client.friend.IOperateFriend;
import com.gplocation.lbs.client.group.IGroup;
import com.gplocation.lbs.client.group.IOperateGroup;
import com.gplocation.lbs.client.internal.IInternal;
import com.gplocation.lbs.client.pubsub.IPublish;
import com.gplocation.lbs.client.pubsub.ISubscribe;
import com.gplocation.lbs.template.TemplateIBinders;

/**
 * @brief manage listeners to return messages to client
 */
public class BinderManager {
    
//	private final static String TAG = "ReceiveManager";
	private static BinderManager binderManager;
	
	//
	private TemplateIBinders<IFriend> readFriends = new TemplateIBinders<IFriend>();
	private TemplateIBinders<IOperateFriend> writeFriends = new TemplateIBinders<IOperateFriend>();
	private TemplateIBinders<IGroup> readGroups = new TemplateIBinders<IGroup>();
	private TemplateIBinders<IOperateGroup> writeGroups = new TemplateIBinders<IOperateGroup>();
	private TemplateIBinders<IPublish> publish = new TemplateIBinders<IPublish>();
	private TemplateIBinders<ISubscribe> subscribe = new TemplateIBinders<ISubscribe>();
	private TemplateIBinders<IInternal> internal = new TemplateIBinders<IInternal>();
	
	
	private BinderManager() {
		
	}
	
	public static synchronized BinderManager getInstance() { 
		if (binderManager == null) {
			binderManager = new BinderManager();
		}
		
		return binderManager;
	}

	public void removeAll() {
		readFriends.removeAll();
		writeFriends.removeAll();
		readGroups.removeAll();
		writeGroups.removeAll();
		publish.removeAll();
		subscribe.removeAll();
		internal.removeAll();
	}
	
	public void remove(String appId) {
		readFriends.remove(appId);
		writeFriends.remove(appId);
		readGroups.remove(appId);
		writeGroups.remove(appId);
		publish.remove(appId);
		subscribe.remove(appId);
		internal.remove(appId);
	}
	
	public TemplateIBinders<IFriend> getReadFriends() {
		return readFriends;
	}

	public void setReadFriends(TemplateIBinders<IFriend> readFriends) {
		this.readFriends = readFriends;
	}

	public TemplateIBinders<IOperateFriend> getWriteFriends() {
		return writeFriends;
	}

	public void setWriteFriends(TemplateIBinders<IOperateFriend> writeFriends) {
		this.writeFriends = writeFriends;
	}

	public TemplateIBinders<IGroup> getReadGroups() {
		return readGroups;
	}

	public void setReadGroups(TemplateIBinders<IGroup> readGroups) {
		this.readGroups = readGroups;
	}

	public TemplateIBinders<IOperateGroup> getWriteGroups() {
		return writeGroups;
	}

	public void setWriteGroups(TemplateIBinders<IOperateGroup> writeGroups) {
		this.writeGroups = writeGroups;
	}

	public TemplateIBinders<IPublish> getPublish() {
		return publish;
	}

	public void setPublish(TemplateIBinders<IPublish> publish) {
		this.publish = publish;
	}

	public TemplateIBinders<ISubscribe> getSubscribe() {
		return subscribe;
	}

	public void setSubscribe(TemplateIBinders<ISubscribe> subscribe) {
		this.subscribe = subscribe;
	}

	public TemplateIBinders<IInternal> getInternal() {
		return internal;
	}

	public void setInternal(TemplateIBinders<IInternal> internal) {
		this.internal = internal;
	}
	
}
