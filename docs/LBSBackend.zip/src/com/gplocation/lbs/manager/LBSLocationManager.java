// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.manager;

import junit.framework.Assert;

import org.jivesoftware.smack.XMPPConnection;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smackx.muc.MultiUserChat;

import android.content.Context;
import android.location.Location;
import android.util.Log;

import com.gplocation.lbs.packetprovider.LocationExtensionProvider;
import com.gplocation.lbs.utils.LocationHelper;

/**
 * handle location
 */
public class LBSLocationManager {
	
	private static final  String TAG = "LBSLocationManager";
	
	private static LBSLocationManager lbsLocationManager;
	private XMPPConnection connection;
	private Context context;
	private Location oldLocation;
	
	private LBSLocationManager() {
		
	}
	
	public static synchronized LBSLocationManager getInstance() { 
		if (lbsLocationManager == null) {
			lbsLocationManager = new LBSLocationManager();
		}
		
		return lbsLocationManager;
	}
	
	
	/**
	 * <p>Should be called when smack connection is established</P>
	 * @param connection
	 * @param context
	 */
	public void init(XMPPConnection connection, Context context) {
		if (connection.isConnected()) {
			this.connection = connection; 
			this.context = context;
		} else {
			Log.d(TAG, "connection is not connected");
		}
	}
	
	
	
	/**
	 * <p>internal function of sharing location</P>
	 * @todo language coutry, locality should not be hard coded.
	 * @param appId
	 * @param isGroup
	 * @param groupName
	 */
	private void shareLocationInternal(String appId, String text, boolean isGroup, String who, boolean withLocation) {
		Assert.assertTrue(who != null);
				
		if (!connection.isConnected()) {
			return;
		}
		
		LocationExtensionProvider.LocationExtension locaExtension = new LocationExtensionProvider.LocationExtension("");
		if (withLocation) {
			Location location = LocationHelper.getLocation(context);
			if (location != null) {
				locaExtension.setAccuracy(String.valueOf(location.getAccuracy()));
				locaExtension.setLatitude(String.valueOf(location.getLatitude()));
				locaExtension.setLongitude(String.valueOf(location.getLongitude()));
			} else {
//				locaExtension.setAccuracy(String.valueOf(1.2));
				locaExtension.setLatitude(String.valueOf(39.920100 + 0.0001));
				locaExtension.setLongitude(String.valueOf(116.460000));
//				locaExtension.setLatitude(String.valueOf(35.63732777));
//				locaExtension.setLongitude(String.valueOf(139.758886111));
			}
	
			locaExtension.setLanguage("en");
			locaExtension.setCountry("China");
			locaExtension.setLocality("Beijing");
		}
		
		if (!isGroup) {
			// friend chat
			Message packet = new Message();
			packet.addExtension(locaExtension);
			packet.setTo(who);
			if (text != null) {
				packet.addBody("en", text);
			}
			if (appId != null) {
				packet.setProperty("appId", appId);
			}
			connection.sendPacket(packet);
			Log.d(TAG, "shareLocationIntenral send:" + packet.toXML());
		} else {
			MultiUserChat multiUserChat = new MultiUserChat(connection, who);
			Message message = multiUserChat.createMessage();
			message.addExtension(locaExtension);
			if (text != null) {
				message.addBody("en", text);
			}
			if (appId != null) {
				message.setProperty("appId", appId);
			}
			try {
				multiUserChat.sendMessage(message);
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			Log.d(TAG, "shareLocationIntenral send:" + message.toXML());
		}

	}
	
	/**
	 * <p>share my location to other</P>
	 * @param toWho
	 */
	public void share(String toWho) {
		shareLocationInternal(null, null, false, toWho, true);
	}
	
	/**
	 * <p>share my location to group</P>
	 * @param groupName
	 * @param state
	 */
	public void shareInGroup(String groupName) {
		shareLocationInternal(null, null, true, groupName, true);
	}
	
	/**
	 * <p>share my location to other</P>
	 * @param appId
	 * @param toWho
	 */
	public void share(String appId, String toWho) {
		shareLocationInternal(appId, null, false, toWho, true);
	}
	
	/**
	 * <p>share my location to group</P>
	 * @param appId
	 * @param groupName
	 * @param state
	 */
	public void shareInGroup(String appId, String groupId) {
		shareLocationInternal(appId, null, true, groupId, true);
	}
	
	
	/**
	 * <p></P>
	 * @param appId
	 * @param text
	 * @param toWho
	 */
	public void share(String appId, String text, String toWho) {
		shareLocationInternal(appId, text, false, toWho, true);
	}
	
	
	/**
	 * <p></P>
	 * @param appId
	 * @param text
	 * @param groupName
	 */
	public void shareInGroup(String appId, String text, String groupName) {
		shareLocationInternal(appId, text, true, groupName, true);
	}
	
	
	/**
	 * <p>share my location to other</P>
	 * @param appId
	 * @param toWho
	 */
	public void share(String appId, String text, String toWho, boolean withLocation) {
		shareLocationInternal(appId, text, false, toWho, withLocation);
	}
	
	/**
	 * <p>share my location to group</P>
	 * @param appId
	 * @param groupName
	 * @param state
	 */
	public void shareInGroup(String appId, String text, String groupId, boolean withLocation) {
		shareLocationInternal(appId, text, true, groupId, withLocation);
	}
	
		
	/**
	 * <p></P>
	 * @param toWho
	 * @param distance
	 */
	public void shareByDistance(String toWho, int distance) {
		Location location = LocationHelper.getLocation(context);
//		int distance = locationDomain.getDistance();
		if ( (oldLocation == null && location != null) 
			|| (oldLocation != null && location != null && 
			LocationHelper.getDistance(location, oldLocation) > distance)) {
			oldLocation = location;
			shareLocationInternal(null, null, false, toWho, true);
		}
	}
	
	/**
	 * <p></P>
	 * @param appId
	 * @param toWho
	 * @param distance
	 */
	public void shareByDistance(String appId, String toWho, int distance) {
		Location location = LocationHelper.getLocation(context);
//		int distance = locationDomain.getDistance();
		if ( (oldLocation == null && location != null) 
			|| (oldLocation != null && location != null && 
			LocationHelper.getDistance(location, oldLocation) > distance)) {
			oldLocation = location;
			shareLocationInternal(appId, null, false, toWho, true);
		}
	}
	
	
	/**
	 * <p>request a person's location</P>
	 * @param toFriend
	 */
	public void request(String who) {
		Message presence = new Message();
		LocationExtensionProvider.LocationExtension requestExtension = 
				new LocationExtensionProvider.LocationExtension("request");
		presence.addExtension(requestExtension);
		presence.setTo(who);
		connection.sendPacket(presence);
		Log.d(TAG, "presence send:" + presence.toXML());

	}
	
	
	/**
	 * <p>request a person's location</P>
	 * @param toFriend
	 */
	public void request(String who, String appId) {
		Message presence = new Message();
		LocationExtensionProvider.LocationExtension requestExtension = 
				new LocationExtensionProvider.LocationExtension("request");
		presence.addExtension(requestExtension);
		presence.setTo(who);
		presence.setProperty("appId", appId);
		connection.sendPacket(presence);
		Log.d(TAG, "presence send:" + presence.toXML());

	}
	
	
	/**
	 * <p>request to follow a person's location</P>
	 * @param who
	 */
	public void follow(String who) {
		Message presence = new Message();
		LocationExtensionProvider.LocationExtension requestExtension = 
				new LocationExtensionProvider.LocationExtension("follow");
		presence.addExtension(requestExtension);
		presence.setTo(who);
		connection.sendPacket(presence);
		Log.d(TAG, "presence send:" + presence.toXML());
	}
	
	
	/**
	 * <p>request to follow a person's location</P>
	 * @param who
	 */
	public void follow(String who, String appId) {
		Message presence = new Message();
		LocationExtensionProvider.LocationExtension requestExtension = 
				new LocationExtensionProvider.LocationExtension("follow");
		presence.addExtension(requestExtension);
		presence.setTo(who);
		presence.setProperty("appId", appId);
		connection.sendPacket(presence);
		Log.d(TAG, "presence send:" + presence.toXML());
	}
	
	
	/**
	 * <p>stop share location</P>
	 * @param who
	 */
	public void stopShare(String who) {
		Message presence = new Message();
		LocationExtensionProvider.LocationExtension requestExtension = 
				new LocationExtensionProvider.LocationExtension("stopShare");
		presence.addExtension(requestExtension);
		presence.setTo(who);
		connection.sendPacket(presence);
		Log.d(TAG, "presence send:" + presence.toXML());
	}
	
	/**
	 * <p>stop share location</P>
	 * @param who
	 */
	public void stopShare(String who, String appId) {
		Message presence = new Message();
		LocationExtensionProvider.LocationExtension requestExtension = 
				new LocationExtensionProvider.LocationExtension("stopShare");
		presence.addExtension(requestExtension);
		presence.setTo(who);
		presence.setProperty("appId", appId);
		connection.sendPacket(presence);
		Log.d(TAG, "presence send:" + presence.toXML());
	}
	
	
	/**
	 * <p>stop share location</P>
	 * @param who
	 */
	public void stopShareInGroup(String who, String appId) {
		Message presence = new Message();
		LocationExtensionProvider.LocationExtension requestExtension = 
				new LocationExtensionProvider.LocationExtension("stopShareInGroup");
		presence.addExtension(requestExtension);
		presence.setTo(who);
		presence.setProperty("appId", appId);
		connection.sendPacket(presence);
		Log.d(TAG, "presence send:" + presence.toXML());
	}
	
	/**
	 * <p>stop follow one's location</P>
	 * @param who
	 */
	public void stopFollow(String who) {
		Message presence = new Message();
		LocationExtensionProvider.LocationExtension requestExtension = 
				new LocationExtensionProvider.LocationExtension("stopFollow");
		presence.addExtension(requestExtension);
		presence.setTo(who);
		connection.sendPacket(presence);
		Log.d(TAG, "presence send:" + presence.toXML());
	}
	
	/**
	 * <p>stop follow one's location</P>
	 * @param who
	 */
	public void stopFollow(String who, String appId) {
		Message presence = new Message();
		LocationExtensionProvider.LocationExtension requestExtension = 
				new LocationExtensionProvider.LocationExtension("stopFollow");
		presence.addExtension(requestExtension);
		presence.setTo(who);
		presence.setProperty("appId", appId);
		connection.sendPacket(presence);
		Log.d(TAG, "presence send:" + presence.toXML());
	}
}
