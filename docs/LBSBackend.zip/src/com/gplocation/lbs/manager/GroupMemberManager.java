// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.manager;

import java.util.ArrayList;

import android.content.Context;
import android.util.Log;

import com.gplocation.lbs.application.MainApplication;
import com.gplocation.lbs.data.GroupInfo;
import com.gplocation.lbs.data.GroupMember;
import com.gplocation.lbs.data.Member;
import com.gplocation.lbs.service.LBSCoreService;

/**
 * group manager, stored the joined groups
 */
public class GroupMemberManager {
	
	private static final  String TAG = "GroupMemberManager";
	private static GroupMemberManager groupMemberManager;
	
	private ArrayList<GroupMember> groupMembers = new ArrayList<GroupMember>();
	
	private GroupMemberManager() {
		
	}
	
	public static synchronized GroupMemberManager getInstance() { 
		if (groupMemberManager == null) {
			groupMemberManager = new GroupMemberManager();
		}
		
		return groupMemberManager;
	}
	
	
	
	/**
	 * <p>join into all the groups</P>
	 * @param context
	 */
	public void init(Context context) {
		Log.d(TAG, "backend init");
		MainApplication mainApplication = (MainApplication) ((LBSCoreService) context).getApplication();
		ArrayList<GroupInfo> groups = mainApplication.groupManager.getGroupList();
		String userName = mainApplication.userInfo.getUserNick();
		String userId = mainApplication.userInfo.getUserId();
		for (int i = 0; i < groups.size(); ++i) {
			String groupId = groups.get(i).getGroupId();
			mainApplication.groupManager.simpleJoinGroup(groupId, userName);
			GroupMember groupMember = new GroupMember(groupId);
			//get role from database
			DBManager dbManager = new DBManager(context);
			String role = dbManager.readRole(groupId, userId);
			groupMember.add(userId, userName, role, false);
			
			groupMembers.add(groupMember);
		}
	}
	
	/**
	 * <p>Change user then reload member</P>
	 * @param context
	 */
	public void reLoad(Context context) {
		Log.d(TAG, "reLoad groupmember");
		if (groupMembers != null) {
			groupMembers.clear();
		}
		
		init(context);
		
	}
	
	
	/**
	 * <p>add a member into groupmember list, add a group if the group is not exist.</P>
	 * @param groupId
	 * @param member
	 */
	public void add(String groupId, Member member) {
		int locs[] = contain(groupId, member.account);
		if (locs[0]>-1) {
			groupMembers.get(locs[0]).add(member);			
		} else {
			GroupMember groupMember = new GroupMember(groupId);
			groupMember.add(member);
			groupMembers.add(groupMember);
		}
	}
	
	/**
	 * <p>add a member into groupmember list, add a group if the group is not exist.</P>
	 * @param groupId
	 * @param memberId
	 * @param memberNick
	 * @param memberRole
	 */
	public void add(String groupId, String memberId, String memberNick, String memberRole) {
		int [] locs = contain(groupId, memberId);
		if (locs[0] > -1) {
			groupMembers.get(locs[0]).add(memberId, memberNick, memberRole);			
		} else {
			GroupMember groupMember = new GroupMember(groupId);
			groupMember.add(memberId, memberNick, memberRole);
			groupMembers.add(groupMember);
		}
	}
	
	/**
	 * <p>remove a group</P>
	 * @param groupId
	 */
	public void removeGroup(String groupId) {
		int loc = contain(groupId);
		if (loc > -1) {
			this.groupMembers.remove(loc);
		}
	}
	
	/**
	 * <p>remove a member, remove a group if the group is empty.</P>
	 * @param groupId
	 * @param memberId
	 */
	public void removeMember(String groupId, String memberId) {
		Log.d(TAG, "removeMember");
		int [] locs = contain(groupId, memberId);
		if (locs[0] > -1 && locs[1] > -1) {
			this.groupMembers.get(locs[0]).remove(memberId);
			if (groupMembers.get(locs[0]).getMembers().size() == 0) {
				groupMembers.remove(locs[0]);
			}
		}
	}
	
	/**
	 * <p>whether contain this group</P>
	 * @param groupId
	 * @return
	 */
	public int contain(String groupId) {
		for (int i = 0; i < groupMembers.size(); ++i) {
			if (groupMembers.get(i).getGroupId().equals(groupId)) {
				return i;
			}
		}
		
		return -1;
	}
	
	/**
	 * <p>whether contain this group, this member</P>
	 * @param groupId
	 * @param memberId
	 * @return int[2], int[0], group location, int[1], member location
	 */
	public int[] contain(String groupId, String memberId) {
		int [] locs = new int[2];
		locs[0] = -1;
		locs[1] = -1;
		
		locs[0] = contain(groupId);
		if (locs[0] > -1) {
			locs[1] = this.groupMembers.get(locs[0]).contain(memberId);
		}
		
		return locs;
	}

	
	/**
	 * <p>get a gorup's member</P>
	 * @param groupId
	 * @return
	 */
	public GroupMember getMembers(String groupId) {
		int loc = contain(groupId);
		if (loc > -1) {
			return this.groupMembers.get(loc);
		}
		
		return null;		
	}
	
	public ArrayList<GroupMember> getGroupMembers() {
		return groupMembers;
	}

	public void setGroupMembers(ArrayList<GroupMember> groupMembers1) {
		this.groupMembers = groupMembers1;
	}
	
}
