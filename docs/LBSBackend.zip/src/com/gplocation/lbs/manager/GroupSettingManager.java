// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.manager;

import java.util.List;

import org.jivesoftware.smack.PacketListener;
import org.jivesoftware.smack.XMPPConnection;
import org.jivesoftware.smack.filter.PacketFilter;
import org.jivesoftware.smack.filter.PacketIDFilter;
import org.jivesoftware.smack.packet.IQ;
import org.jivesoftware.smack.packet.IQ.Type;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Packet;

import android.content.Context;
import android.util.Log;

import com.gplocation.lbs.data.Setting;
import com.gplocation.lbs.packetprovider.NotifyExtensionProvider;
import com.gplocation.lbs.utils.Constants;

/**
 * stored the joined group's setting
 */
public class GroupSettingManager {
	
	private static final String TAG = "GroupSettingManager";
	
	private static GroupSettingManager groupSettingManager;
	
	private XMPPConnection connection;
	
	private GroupSettingManager() {
		
	}
	
	public static synchronized GroupSettingManager getInstance() { 
		if (groupSettingManager == null) {
			groupSettingManager = new GroupSettingManager();
		}
		
		return groupSettingManager;
	}
	
	
	/**
	 * <p>Should be called when smack connection is established</P>
	 * @param connection
	 * @param context
	 */
	public void init(XMPPConnection connection, Context context) {
		if (connection.isConnected()) {
			this.connection = connection; 
		} else {
			Log.d(TAG, "connection is not connected");
		}
	}
	    
    /**
     * listen group setting package according to pakcetID
     */
    private class GroupSettingPacketListener implements PacketListener {
		private String groupId;
		private String settingName;
		private String appId;

		public GroupSettingPacketListener(String appId, String groupId, String settingName) {
			this.appId = appId;
			this.groupId = groupId;
			this.settingName = settingName;
		}

		@Override
		public void processPacket(Packet pk) {
			Log.d(TAG, pk.toXML());
			if (((IQ) pk).getType().equals(IQ.Type.RESULT)) {
				// send notify packet to all members in group
//				String appId = (String) pk.getProperty("appId"); //now result message has not property.
				
				org.jivesoftware.smack.packet.Message packet = new org.jivesoftware.smack.packet.Message();
				NotifyExtensionProvider.NotifyExtension notifyExtension = new NotifyExtensionProvider.NotifyExtension(
						Constants.NOTIFY_UPDATE_GROUP_SETTING, groupId + "/" + settingName);
				packet.addExtension(notifyExtension);
				packet.setTo(groupId);
				packet.setType(Message.Type.groupchat);
				packet.setProperty("appId", appId);

				Log.d(TAG, "GroupSettingPacketListener send " + packet.toXML());
				connection.sendPacket(packet);
            }
			
			connection.removePacketListener(this);
		}

	}
    
	
	/**
	 * <p>set group setting into server</P>
	 * @param groupSettings
	 */
	public boolean set(final String appId, final String groupId, 
			final String settingName, final List<Setting> settingList) {			
		IQ setReq = new IQ() {
			@Override
			public String getChildElementXML() {
				StringBuilder sb = new StringBuilder();
				
				// not handle the remove and add/update messages together
				if (settingList.size() > 0) {
					sb.append("<setting xmlns=\"group:setting:data\">");
				} else {
					sb.append("<setting xmlns=\"group:setting:data\" >");
				}

				sb.append("<group id='" + groupId + "' settingname='" + settingName +  "' appid='" + appId + "'>");
				for (Setting setting : settingList) {
					sb.append("<item name='" + setting.getKey() + "'>"
							+ setting.getValue() + "</item>");
				}
				
				sb.append("</group>");
				sb.append("</setting>");
				
				return sb.toString();
			}
		};
		setReq.setType(Type.SET);
		setReq.setTo("setting.motolbs.com");
//		setReq.setProperty("appId", appId);
		
		
		String packageId = setReq.getPacketID();
		PacketFilter idFilter = new PacketIDFilter(packageId);

		connection.addPacketListener(new GroupSettingPacketListener(appId, groupId, settingName), idFilter);

		Log.d(TAG, "setGroupSetting:" + setReq.toXML());
		connection.sendPacket(setReq);

		return true;
		
	}
	
	/**
	 * <p>query group id's setting</P>
	 * @param groupIds
	 */
	public void query(final List<String> groupIds) {
		// first query the local value
		IQ request = new IQ() {
			@Override
			public String getChildElementXML() {
				StringBuilder sb = new StringBuilder();
				sb.append("<setting xmlns=\"group:setting:data\">");
				if (groupIds != null) {
					for (String id : groupIds) {
						sb.append("<group id='").append(id).append("'/>");
					}
				}
				sb.append("</setting>");
				return sb.toString();
			}
		};
		request.setType(Type.GET);
		request.setTo("setting.motolbs.com");
		Log.d(TAG, "queryGroupSetting:" + request.toXML());
		connection.sendPacket(request);
	}
	
	
	/**
	 * <p>query group setting, it is used now, settingName is not used now</P>
	 * @param appId
	 * @param groupIds
	 * @param settingName
	 */
	public void query(final String appId, final String groupIds, final String settingName) {
		// first query the local value
		IQ request = new IQ() {
			@Override
			public String getChildElementXML() {
				StringBuilder sb = new StringBuilder();
				sb.append("<setting xmlns=\"group:setting:data\">");
				sb.append("<group id='").append(groupIds).append("' appid='").append(appId);
				if (settingName != null) {
					sb.append("' settingname='").append(settingName);
				}
				
				sb.append("'/>");
				sb.append("</setting>");
				return sb.toString();
			}
		};
				
//		request.setProperty("appId", appId);
		request.setType(Type.GET);
		request.setTo("setting.motolbs.com");
		Log.d(TAG, "queryGroupSetting:" + request.toXML());
		connection.sendPacket(request);
	}
	

	public XMPPConnection getConnection() {
		return connection;
	}

	public void setConnection(XMPPConnection connection) {
		this.connection = connection;
	}
	
}
