// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.packetprovider;

import org.jivesoftware.smack.packet.PacketExtension;
import org.jivesoftware.smack.provider.PacketExtensionProvider;
import org.xmlpull.v1.XmlPullParser;

import android.util.Log;

/**
 * @brief Location provider for Message Xml
 */
public class LocationExtensionProvider implements PacketExtensionProvider {
	private static final String TAG = "LocationExtensionProvider";

    public LocationExtensionProvider() {
    }

    @Override
    public PacketExtension parseExtension(XmlPullParser parser) throws Exception {

        int event = parser.getEventType();
        LocationExtension location = new LocationExtension("");
        while (event != XmlPullParser.END_DOCUMENT) {
            switch (event) {
            case XmlPullParser.START_DOCUMENT:
                break;
            case XmlPullParser.START_TAG:
                //                if("message".equals(parser.getName())){
                //                    location.setFrom(parser.getAttributeValue(0));
                //                    location.setTo(parser.getAttributeValue(1));
                //                } else
                //                    
                if ("geoloc".equals(parser.getName())) {
                	Log.d(TAG, "" + parser.getAttributeValue("", "action"));
                	
                    location.setLanguage("en");
                    String action = parser.getAttributeValue("", "action");
                    if (action != null) {
                    	location.setAction(action);
                    }
                } else if ("accuracy".equals(parser.getName())) {
                    location.setAccuracy(parser.nextText());
                } else if ("country".equals(parser.getName())) {
                    location.setCountry(parser.nextText());
                } else if ("lat".equals(parser.getName())) {
                    location.setLatitude(parser.nextText());
                } else if ("locality".equals(parser.getName())) {
                    location.setLocality(parser.nextText());
                } else if ("lon".equals(parser.getName())) {
                    location.setLongitude(parser.nextText());
                }
                break;
            case XmlPullParser.END_TAG:
                if ("geoloc".equals(parser.getName())) {
                    return location;
                }
                break;
            default:
                break;
            }
            event = parser.next();
        }

        return null;
    }
    
    
    /**
     * @brief custom define location information
     */
    public static class LocationExtension implements PacketExtension {

        public static final String NAMESPACE = "http://jabber.org/protocol/geoloc";
        public static final String ELEMENT = "geoloc";

        private String accuracy;
        private String country;
        private String latitude;
        private String locality;
        private String longitude;
        private String language;
        
        /**
         * action distinguish request, follow, stopFollow, stopShare 
         */
        private String action = "";
        
        
        public LocationExtension(String action) {
        	this.action = action;
        }

        @Override
        public String getElementName() {
            return ELEMENT;
        }

        @Override
        public String getNamespace() {
            return NAMESPACE;
        }

        @Override
        public String toXML() {
            Log.d("LocationExtension", "LocationExtension toXML()");
            StringBuilder buf = new StringBuilder();

            buf.append("<geoloc xmlns='" + NAMESPACE + "' xml:lang='" + language );
            if(getAction() !=null && !"".equals(getAction())){
                buf.append("' action='" + action);
            }
            buf.append("'>");
            if (getAccuracy() != null) {
                buf.append("<accuracy>").append(accuracy).append("</accuracy>");
            }
            if (getCountry() != null) {
                buf.append("<country>").append(country).append("</country>");
            }
            if (getLatitude() != null) {
                buf.append("<lat>").append(latitude).append("</lat>");
            }
            if (getLocality() != null) {
                buf.append("<locality>").append(locality).append("</locality>");
            }
            if (getLongitude() != null) {
                buf.append("<lon>").append(longitude).append("</lon>");
            }
            buf.append("</geoloc>");
            Log.d("LocationExtension", buf.toString());
            return buf.toString();
        }

        public String getAccuracy() {
            return accuracy;
        }

        public void setAccuracy(String accuracy) {
            this.accuracy = accuracy;
        }

        public String getCountry() {
            return country;
        }

        public void setCountry(String country) {
            this.country = country;
        }

        public String getLatitude() {
            return latitude;
        }

        public void setLatitude(String latitude) {
            this.latitude = latitude;
        }

        public String getLongitude() {
            return longitude;
        }

        public void setLongitude(String longitude) {
            this.longitude = longitude;
        }

        public String getLocality() {
            return locality;
        }

        public void setLocality(String locality) {
            this.locality = locality;
        }

        public String getLanguage() {
            return language;
        }

        public void setLanguage(String language) {
            this.language = language;
        }
        
        public String getAction() {
            return this.action;
        }

        public void setAction(String action) {
            this.action = action;
        }

    }

}
