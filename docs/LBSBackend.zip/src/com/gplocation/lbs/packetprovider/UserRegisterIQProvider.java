/**
 * 
 */
package com.gplocation.lbs.packetprovider;

import org.jivesoftware.smack.packet.IQ;
import org.jivesoftware.smack.provider.IQProvider;
import org.xmlpull.v1.XmlPullParser;

import android.util.Log;

/**
 * Parses the root setting packet extensions of the {@link IQ} packet and
 * returns
 * 
 * @author jianbinxu
 * 
 */
public class UserRegisterIQProvider implements IQProvider {
	private static final String TAG = "UserRegisterIQProvider";

	@Override
	public IQ parseIQ(XmlPullParser parser) throws Exception {
		UserRegisterIQ registerIQ = new UserRegisterIQ();

		// check error
		int eventType = parser.next();
		if ((eventType == XmlPullParser.START_TAG)
				&& "error".equals(parser.getName())) {
			registerIQ.setError(true);
			registerIQ.setErrorMsg(parser.nextText());
			
			Log.d(TAG, registerIQ.toXML());
			Log.d(TAG, registerIQ.getErrorMsg());
			return registerIQ;
		}

		while (true) {
			switch (eventType) {
			case XmlPullParser.TEXT:
				break;
			case XmlPullParser.START_TAG:
				if (parser.getName().equals("userid")) {
					String userId = parser.nextText();
					registerIQ.setUserId(userId);

				} else if (parser.getName().equals("email")) {
					String email = parser.nextText();
					registerIQ.setEmail(email);
				} else if (parser.getName().equals("phone")) {
					String phone = parser.nextText();
					registerIQ.setPhone(phone);
				} else if ("error".equals(parser.getName())) {
					registerIQ.setError(true);
					registerIQ.setErrorMsg(parser.nextText());

					Log.d(TAG, registerIQ.getErrorMsg());
				}

				break;
			case XmlPullParser.END_TAG:
				if (UserRegisterIQ.ELEMENT.equals(parser.getName())) {
					return registerIQ;
				}
			default:
				System.err.println("can not parser tag:" + parser.getText());
			}
			eventType = parser.next();
		}
	}

}
