/**
 * 
 */
package com.gplocation.lbs.packetprovider;

import org.jivesoftware.smack.packet.IQ;
import org.jivesoftware.smack.packet.PacketExtension;
import org.jivesoftware.smack.provider.IQProvider;
import org.jivesoftware.smack.util.PacketParserUtils;
import org.xmlpull.v1.XmlPullParser;

/**
 * Parses the root setting packet extensions of the {@link IQ} packet and
 * returns
 * 
 * @author jianbinxu
 * 
 */
public class GroupSettingIQProvider implements IQProvider {

	@Override
	public IQ parseIQ(XmlPullParser parser) throws Exception {
		GroupSettingIQ gSettingIQ = new GroupSettingIQ();
		String namespace = parser.getNamespace();

		// check error
		int eventType = parser.next();
		if ((eventType == XmlPullParser.START_TAG)
				&& "error".equals(parser.getName())) {
			gSettingIQ.setError(true);
			gSettingIQ.setErrorMsg(parser.nextText());
			// skip to end tag?
			parser.next();
			return gSettingIQ;
		}

		while (true) {

			if (eventType == XmlPullParser.START_TAG) {
				PacketExtension ext = PacketParserUtils.parsePacketExtension(
						parser.getName(), namespace, parser);

				if (ext != null) {
					gSettingIQ.addExtension(ext);
				}
			} else if (eventType == XmlPullParser.END_TAG) {
				if (GroupSettingIQ.ELEMENT.equals(parser.getName())) {
					break;
				}
			}
			eventType = parser.next();
		}
		return gSettingIQ;
	}

}
