// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.packetprovider;

import java.util.ArrayList;

import org.jivesoftware.smack.packet.IQ;
import org.jivesoftware.smack.provider.IQProvider;
import org.xmlpull.v1.XmlPullParser;

import com.gplocation.lbs.data.ThirdApp;

public class ThirdAppsExtensionProvider implements IQProvider {

	@Override
	public IQ parseIQ(XmlPullParser parser) throws Exception {
		int event = parser.getEventType();
		ThirdAppsExtension thirdApps = new ThirdAppsExtension();
		ArrayList<ThirdApp> apps = new ArrayList<ThirdApp>();
		ThirdApp tmpApp = null;
		while (event != XmlPullParser.END_DOCUMENT) {
			switch (event) {
			case XmlPullParser.START_DOCUMENT:
				break;
			case XmlPullParser.START_TAG:
				if (ThirdAppsExtension.ITEM_APP.equals(parser.getName())) {
					ThirdApp app = new ThirdApp();
					app.setAppId(parser.getAttributeValue(null, ThirdAppsExtension.ATTR_APP_ID));
					app.setAppName(parser.getAttributeValue(null, ThirdAppsExtension.ATTR_APP_NAME));
					app.setPackageName(parser.getAttributeValue(null, ThirdAppsExtension.ATTR_APP_PACKAGE_NAME));
					app.setAuthor(parser.getAttributeValue(null, ThirdAppsExtension.ATTR_APP_AUTHOR));
					app.setVersion(parser.getAttributeValue(null, ThirdAppsExtension.ATTR_APP_VERSION));		
					tmpApp = app;
				} else if (ThirdAppsExtension.ITEM_ITEM.equals(parser.getName())) {
					String name = parser.getAttributeValue(null, ThirdAppsExtension.ITEM_NAME);
					String value = parser.nextText();
					
					if (name.equals(ThirdAppsExtension.ATTR_APP_DESCRIPTION)) {
						tmpApp.setDescription(value);
					} else if (name.equals(ThirdAppsExtension.ATTR_APP_ICON)) {
						tmpApp.setIconLink(value);
					} else if (name.equals(ThirdAppsExtension.ATTR_APP_DOWNLOADLINK)) {
						tmpApp.setDownloadLink(value);
					}
				} 
				break;
			case XmlPullParser.END_TAG:
				if (ThirdAppsExtension.ELEMENT.equals(parser.getName())) {
					if (apps.size() > 0) {
						thirdApps.setApps(apps);
					}
					return thirdApps;
				} else if (ThirdAppsExtension.ITEM_APP.equals(parser.getName())) {
					apps.add(tmpApp);
				}
				
				break;
			default:
				break;
			}
			event = parser.next();
		}
		
		return null;
	}
	

	
	public static class ThirdAppsExtension extends IQ {
		public static final String NAMESPACE = "application:motolbs:disc";
		public static final String ELEMENT = "application";
		
		public static final String ITEM_APP = "app";
		public static final String ITEM_ITEM = "item";
		public static final String ITEM_NAME = "name";
		public static final String ATTR_APP_ID = "id";
		public static final String ATTR_APP_NAME = "name";
		public static final String ATTR_APP_PACKAGE_NAME = "packagename";
		public static final String ATTR_APP_AUTHOR = "author";
		public static final String ATTR_APP_VERSION = "version";
		public static final String ATTR_APP_DESCRIPTION = "description";
		public static final String ATTR_APP_ICON = "icon";
		public static final String ATTR_APP_DOWNLOADLINK = "downloadlink";
		
		
		private ArrayList<ThirdApp> apps;

		public ThirdAppsExtension() {
			
		}

		public ArrayList<ThirdApp> getApps() {
			return apps;
		}


		public void setApps(ArrayList<ThirdApp> apps) {
			this.apps = apps;
		}
		
		
		public String getElementName() {
			return ELEMENT;
		}

		public String getNamespace() {
			return NAMESPACE;
		}
		
		@Override
		public String getChildElementXML() {
			StringBuilder buf = new StringBuilder();

			buf.append("<" + ELEMENT + " xmlns='" + NAMESPACE + "'>");
			if (apps != null) {
				for (int i = 0; i < apps.size(); ++i) {
					buf.append("<" + ITEM_APP + " " 
								   + ATTR_APP_ID + "=" + apps.get(i).getAppId() + " "
								   + ATTR_APP_NAME + "=" + apps.get(i).getAppName() + " "
								   + ATTR_APP_PACKAGE_NAME + "=" + apps.get(i).getPackageName() + " "
								   + ATTR_APP_AUTHOR + "=" + apps.get(i).getAuthor() + " "
								   + ATTR_APP_VERSION + "=" + apps.get(i).getVersion() + ">");
					
					if (apps.get(i).getDescription() != null && !"".equals(apps.get(i).getDescription())) {
						buf.append("<" + ITEM_ITEM + " " + ITEM_NAME + "=" + ATTR_APP_DESCRIPTION + ">");
						buf.append(apps.get(i).getDescription() + "</" + ITEM_ITEM + ">");
					}
					
					if (apps.get(i).getIconLink() != null && !"".equals(apps.get(i).getIconLink())) {
						buf.append("<" + ITEM_ITEM + " " + ITEM_NAME + "=" + ATTR_APP_ICON + ">");
						buf.append(apps.get(i).getIconLink() + "</" + ITEM_ITEM + ">");
					}
					
					if (apps.get(i).getDownloadLink() != null && !"".equals(apps.get(i).getDownloadLink())) {
						buf.append("<" + ITEM_ITEM + " " + ITEM_NAME + "=" + ATTR_APP_DOWNLOADLINK + ">");
						buf.append(apps.get(i).getDownloadLink() + "</" + ITEM_ITEM + ">");
					}
					
					
					buf.append("</" + ITEM_APP + ">");
				}
				
			}

			buf.append("</" + ELEMENT + ">");
			
			return buf.toString();
		}
		
	}
	
}
