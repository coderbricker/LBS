/**
 * 
 */
package com.gplocation.lbs.packetprovider;

import org.jivesoftware.smack.packet.IQ;

/**
 * Setting tag for group settings
 * 
 * @author jianbinxu
 * 
 */
public class GroupSettingIQ extends IQ {
	public static final String ELEMENT = "setting";
	public static final String NAMESPACE = "group:setting:data";

	private boolean error = false;
	private String errorMsg;

	public boolean isError() {
		return error;
	}

	public void setError(boolean error) {
		this.error = error;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	/**
	 * Returns the XML element name of the extension sub-packet root element.
	 * 
	 * @return return the XML element name of the packet extension.
	 */
	public String getElementName() {
		return ELEMENT;
	}

	/**
	 * Returns the XML namespace of the extension sub-packet root element.
	 * 
	 * @return the XML namespace of the packet extension.
	 */
	public String getNamespace() {
		return NAMESPACE;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.jivesoftware.smack.packet.IQ#getChildElementXML()
	 */
	@Override
	public String getChildElementXML() {
        StringBuilder sb = new StringBuilder();
		sb.append("<" + ELEMENT + " xmlns=\"" + NAMESPACE + "\">");
//        sb.append("<").append(ELEMENT).append(" xmlns=\"").append(NAMESPACE).append("\">");
        sb.append(getExtensionsXML());
        sb.append("</" + ELEMENT + ">");
//        sb.append("</").append(ELEMENT).append(">");
        return sb.toString();
	}
}
