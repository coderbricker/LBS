package com.gplocation.lbs.packetprovider;

import org.jivesoftware.smack.packet.IQ;


public class AuthenticateIQ extends IQ {
	public static final String ELEMENT = "authenticate";
	public static final String NAMESPACE = "lbs:authenticate:disc";
	

	public static final String ITEM_APP = "app";
	public static final String ITEM_PRIVILEGE = "api";
	public static final String ITEM_RESTRICTION= "restriction";
	public static final String ATTR_APP_ID = "appid";
	public static final String ATTR_APP_NAME = "appname";
	public static final String ATTR_VENDOR = "vendor";
	public static final String ATTR_CERTIFICATION = "certification";
	
	
	private String appId;
	private String appName;
	private String vendor;
	private String certification;
	private String privilege;
	private String restriction;
	
	private boolean error = false;
	private String errorMsg;

	public boolean isError() {
		return error;
	}

	public void setError(boolean error) {
		this.error = error;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	
	/**
	 * Returns the XML element name of the extension sub-packet root element.
	 * 
	 * @return return the XML element name of the packet extension.
	 */
	public String getElementName() {
		return ELEMENT;
	}

	/**
	 * Returns the XML namespace of the extension sub-packet root element.
	 * 
	 * @return the XML namespace of the packet extension.
	 */
	public String getNamespace() {
		return NAMESPACE;
	}

	
	@Override
	public String getChildElementXML() {
        StringBuilder builder = new StringBuilder();
        builder.append("<" + ELEMENT + " xmlns=\"" + NAMESPACE + "\">");
//        sb.append("<").append(ELEMENT).append(" xmlns=\"").append(NAMESPACE).append("\">");
        builder.append("<" + ITEM_APP);
		if (appId != null && !"".equals(appId)) {
			//id
			builder.append(" id='" + appId + "'");
		}
		if (appName != null && !"".equals(appName)) {
			//id
			builder.append(" name='" + appName + "'");
		}
		if (vendor != null && !"".equals(vendor)) {
			//id
			builder.append(" vendor='" + vendor + "'");
		}
		if (certification != null && !"".equals(certification)) {
			//id
			builder.append(" secret='" + certification + "'");
		}
		builder.append(">");
		
		if (privilege != null && !"".equals(privilege)) {
			builder.append("<" + ITEM_PRIVILEGE + ">" + privilege + "</>");
		}
		
		if (restriction != null && !"".equals(restriction)) {
			builder.append("<" + ITEM_RESTRICTION + ">" + restriction + "</>");
		}
			
		builder.append("</app>");
		builder.append("</" + ELEMENT + ">");
//        sb.append("</").append(ELEMENT).append(">");
        return builder.toString();
	}

	

	public String getCertification() {
		return certification;
	}

	public void setCertification(String certification) {
		this.certification = certification;
	}

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public String getPrivilege() {
		return privilege;
	}

	public void setPrivilege(String privilege) {
		this.privilege = privilege;
	}

	public String getRestriction() {
		return restriction;
	}

	public void setRestriction(String restriction) {
		this.restriction = restriction;
	}
	
}
