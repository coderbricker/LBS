/**
 * 
 */
package com.gplocation.lbs.packetprovider;

import org.jivesoftware.smack.packet.PacketExtension;
import org.jivesoftware.smack.provider.PacketExtensionProvider;
import org.xmlpull.v1.XmlPullParser;

import com.gplocation.lbs.data.Setting;

/**
 * Parses the <b>group</b> element out of the setting IQ message from
 * 
 * @author jianbinxu
 * 
 */
public class GroupSettingExtProvider implements PacketExtensionProvider {

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.jivesoftware.smack.provider.PacketExtensionProvider#parseExtension
	 * (org.xmlpull.v1.XmlPullParser)
	 */
	@Override
	public PacketExtension parseExtension(XmlPullParser parser)
			throws Exception {
		// Fetch all the attributes
		GroupSettingExtension gSettingExt = new GroupSettingExtension();
		String groupID = parser.getAttributeValue("",
				GroupSettingExtension.ATTR_GROUP_ID);
		String appID = parser.getAttributeValue("",
				GroupSettingExtension.ATTR_APP_ID);
		String settingName = parser.getAttributeValue("",
				GroupSettingExtension.ATTR_SETTING_NAME);
		String updatetime = parser.getAttributeValue("",
				GroupSettingExtension.ATTR_UPDATE_TIME);

		gSettingExt.setAppID(appID);
		gSettingExt.setGroupID(groupID);
		gSettingExt.setSettingName(settingName);
		gSettingExt.setUpdatetime(updatetime);

		// parse item
		Setting s = null;
		while (true) {

			int tag = parser.next();
			if (!Setting.ELEMENT.equals(parser.getName())) {
				break;
			}

			if (tag == XmlPullParser.START_TAG) {
				String key = parser.getAttributeValue("", Setting.ATTR_NAME);
				String type = parser.getAttributeValue("", Setting.ATTR_TYPE);
				String value = parser.nextText();

				s = new Setting(key, value, type);
				gSettingExt.getSettings().add(s);
			}
		}

		return gSettingExt;
	}

}
