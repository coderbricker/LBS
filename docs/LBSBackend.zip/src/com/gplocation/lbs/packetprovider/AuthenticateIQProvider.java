package com.gplocation.lbs.packetprovider;

import org.jivesoftware.smack.packet.IQ;
import org.jivesoftware.smack.provider.IQProvider;
import org.xmlpull.v1.XmlPullParser;

import android.util.Log;


public class AuthenticateIQProvider implements IQProvider {
	private static final String TAG = "AuthenticateIQProvider";

	@Override
	public IQ parseIQ(XmlPullParser parser) throws Exception {
		AuthenticateIQ authenticateIQ = new AuthenticateIQ();

		// check error
		int eventType = parser.next();
		if ((eventType == XmlPullParser.START_TAG)
				&& "error".equals(parser.getName())) {
			authenticateIQ.setError(true);
			authenticateIQ.setErrorMsg(parser.nextText());
			
			Log.d(TAG, authenticateIQ.toXML());
			Log.d(TAG, authenticateIQ.getErrorMsg());
			return authenticateIQ;
		}

		while (true) {
			switch (eventType) {
			case XmlPullParser.TEXT:
				break;
			case XmlPullParser.START_TAG:
				if (parser.getName().equals(AuthenticateIQ.ITEM_APP)) {
					String appId = parser.getAttributeValue("", AuthenticateIQ.ATTR_APP_ID);
					String appName = parser.getAttributeValue("", AuthenticateIQ.ATTR_APP_NAME);
					String vendor = parser.getAttributeValue("", AuthenticateIQ.ATTR_VENDOR);
					String cert = parser.getAttributeValue("", AuthenticateIQ.ATTR_CERTIFICATION);
					
					authenticateIQ.setAppId(appId);
					authenticateIQ.setAppName(appName);
					authenticateIQ.setVendor(vendor);
					authenticateIQ.setCertification(cert);

				} else if (parser.getName().equals(AuthenticateIQ.ITEM_PRIVILEGE)) {
					String privilege = parser.nextText();
					authenticateIQ.setPrivilege(privilege);
				} else if (parser.getName().equals(AuthenticateIQ.ITEM_RESTRICTION)) {
					String restriction = parser.nextText();
					authenticateIQ.setRestriction(restriction);
				}

				break;
			case XmlPullParser.END_TAG:
				if (AuthenticateIQ.ELEMENT.equals(parser.getName())) {
					return authenticateIQ;
				}
			default:
				System.err.println("can not parser tag:" + parser.getText());
			}
			eventType = parser.next();
		}
	}

	
}
