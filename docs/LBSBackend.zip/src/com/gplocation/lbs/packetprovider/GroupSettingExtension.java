/**
 * 
 */
package com.gplocation.lbs.packetprovider;

import java.util.ArrayList;
import java.util.List;

import org.jivesoftware.smack.packet.PacketExtension;

import com.gplocation.lbs.data.Setting;

/** group setting extension
 * @author jianbinxu
 *
 */
public class GroupSettingExtension implements PacketExtension {
	public static final String ELEMENT = "group";
	public static final String NAMESPACE = "group:setting:data";
	public static final String ATTR_GROUP_ID = "id";
	public static final String ATTR_APP_ID = "appid";
	public static final String ATTR_SETTING_NAME = "settingname";
	public static final String ATTR_UPDATE_TIME = "updatetime";
	
	private String groupID;
	private String appID;
	private String settingName;
	private String updatetime;
	
	private List<Setting> settings = new ArrayList<Setting>();
	
	public String getGroupID() {
		return groupID;
	}

	public void setGroupID(String groupID) {
		this.groupID = groupID;
	}

	public String getAppID() {
		return appID;
	}

	public void setAppID(String appID) {
		this.appID = appID;
	}

	public String getSettingName() {
		return settingName;
	}

	public void setSettingName(String settingName) {
		this.settingName = settingName;
	}

	public String getUpdatetime() {
		return updatetime;
	}

	public void setUpdatetime(String updatetime) {
		this.updatetime = updatetime;
	}

	public List<Setting> getSettings() {
		return settings;
	}

	public void setSettings(List<Setting> settings) {
		this.settings = settings;
	}


	/* (non-Javadoc)
	 * @see org.jivesoftware.smack.packet.PacketExtension#getElementName()
	 */
	@Override
	public String getElementName() {
		return ELEMENT;
	}

	/* (non-Javadoc)
	 * @see org.jivesoftware.smack.packet.PacketExtension#getNamespace()
	 */
	@Override
	public String getNamespace() {
		return NAMESPACE;
	}

	/* (non-Javadoc)
	 * @see org.jivesoftware.smack.packet.PacketExtension#toXML()
	 */
	@Override
	public String toXML() {
		StringBuilder builder = new StringBuilder("<group");
		
		//id
		builder.append("id='" + groupID + "'");
		//appID
		builder.append(" appid='" + appID + "'");
		//settingName
		builder.append(" settingname='" + settingName + "'");
		//udatetime
		builder.append(" updatetime='" + updatetime + "'");
		
		//no items 
		if (settings.size() <= 0) {
			builder.append(" />");
			return builder.toString();
		}
		
		for (Setting s : settings) {
			builder.append("<item");
			builder.append(" name='" + s.getKey() + "'>");
			builder.append(s.getValue() + "</item>");
//			builder.append(" type='" + s.getType() + "'");			
		}
		return builder.toString();
	}

}
