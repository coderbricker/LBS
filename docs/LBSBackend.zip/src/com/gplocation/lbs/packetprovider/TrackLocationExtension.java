// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.packetprovider;

import org.jivesoftware.smack.packet.PacketExtension;

import com.gplocation.lbs.packetprovider.LocationExtensionProvider.LocationExtension;

    /**
     * @brief custom define location information
     */
    public class TrackLocationExtension implements PacketExtension {

        public static final String NAMESPACE = "http://jabber.org/protocol/geoloctrack";
        public static final String ELEMENT = "geoloctrack";

        private LocationExtension newLocation;
        private LocationExtension oldLocation;
        
        public TrackLocationExtension(LocationExtension newLocation,LocationExtension oldLocation) {
            this.newLocation = newLocation;
            this.oldLocation = oldLocation;
        }
        @Override
        public String getElementName() {
            return ELEMENT;
        }

        @Override
        public String getNamespace() {
            return NAMESPACE;
        }

        @Override
        public String toXML() {
            StringBuilder buf = new StringBuilder();

            buf.append("<geoloctrack xmlns='" + NAMESPACE + "'>");
            if(newLocation!=null){
                buf.append("<newlocation>");
                buf.append(newLocation.toXML());
                buf.append("</newlocation>");
            }

            if(oldLocation!=null){
                buf.append("<oldlocation>");
                buf.append(oldLocation.toXML());
                buf.append("</oldlocation>");
            }
            buf.append("</geoloctrack>");
            return buf.toString();
        }

}
