// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.packetprovider;

import org.jivesoftware.smack.packet.PacketExtension;
import org.jivesoftware.smack.provider.PacketExtensionProvider;
import org.xmlpull.v1.XmlPullParser;

public class NotifyExtensionProvider implements PacketExtensionProvider {

//	private static final String TAG = "NotifyExtensionProvider";
	
	public NotifyExtensionProvider() {

	}

	@Override
	public PacketExtension parseExtension(XmlPullParser parser) throws Exception {
		int event = parser.getEventType();
		NotifyExtension notify = new NotifyExtension();
		while (event != XmlPullParser.END_DOCUMENT) {
			switch (event) {
			case XmlPullParser.START_DOCUMENT:
				break;
			case XmlPullParser.START_TAG:
//				if ("action".equals(parser.getName())) {
//				} else
				if ("command".equals(parser.getName())) {
					notify.setCommand(parser.getAttributeValue(null, "do"));
					notify.setParam(parser.getAttributeValue(null, "param"));
				} 
				break;
			case XmlPullParser.END_TAG:
				if ("action".equals(parser.getName())) {
					return notify;
				}
				break;
			default:
				break;
			}
			event = parser.next();
		}

		return null;
	}
	
	public static class NotifyExtension implements PacketExtension {

		public static final String NAMESPACE = "notify:motolbs:service";
		public static final String ELEMENT = "action";

		private String command;
		private String param;

		public NotifyExtension() {
		}
		
		public NotifyExtension(String command, String note) {
			this.command = command;
			this.param = note;
		}

		public String getCommand() {
			return command;
		}

		public void setCommand(String command) {
			this.command = command;
		}

		public String getParam() {
			return param;
		}

		public void setParam(String note) {
			this.param = note;
		}

		@Override
		public String getElementName() {
			return ELEMENT;
		}

		@Override
		public String getNamespace() {
			return NAMESPACE;
		}
		
		@Override
		public String toXML() {
			StringBuilder buf = new StringBuilder();

			buf.append("<action xmlns='" + NAMESPACE + "'>");
			buf.append("<command");
			if (command != null) {
				buf.append(" do='").append(command + "'");
			}

			if (param != null) {
				buf.append(" param='").append(param + "'");
			}
			buf.append("></command>");
			buf.append("</action>");
			
			return buf.toString();
		}

	}
}
