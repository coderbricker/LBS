// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.packetprovider;

import java.io.UnsupportedEncodingException;

import org.jivesoftware.smack.packet.PacketExtension;
import org.jivesoftware.smack.provider.PacketExtensionProvider;
import org.jivesoftware.smack.util.Base64;
import org.xmlpull.v1.XmlPullParser;

/**
 * @brief Pubsub provider for Message Xml
 */
public class PubsubExtensionProvider implements PacketExtensionProvider {

	StringBuffer buffer = new StringBuffer();

	public PubsubExtensionProvider() {
	}

	/**
	 * parser the received package (non-Javadoc)
	 * 
	 * @see org.jivesoftware.smack.provider.PacketExtensionProvider#parseExtension(org.xmlpull.v1.XmlPullParser)
	 */
	@Override
	public PacketExtension parseExtension(XmlPullParser parser)
			throws Exception {
		int event = parser.getEventType();
		PubsubExtension extension = new PubsubExtension();
		while (event != XmlPullParser.END_DOCUMENT) {
			switch (event) {
			case XmlPullParser.START_DOCUMENT:
				break;
			case XmlPullParser.START_TAG:
				System.out.println("test-----");
				if ("lbsItem".equals(parser.getName())) {
					extension.setAppId(parser.getAttributeValue(0));
					extension.setLanguage("en");
				} else if ("geoloc".equals(parser.getName())) {
					extension.setDistense(500);
					extension.setLoc(true);
				} else if ("accuracy".equals(parser.getName())) {
					extension.setAccuracy(parser.nextText());
				} else if ("country".equals(parser.getName())) {
					extension.setCountry(parser.nextText());
				} else if ("lat".equals(parser.getName())) {
					extension.setLatitude(parser.nextText());
				} else if ("locality".equals(parser.getName())) {
					extension.setLocality(parser.nextText());
				} else if ("lon".equals(parser.getName())) {
					extension.setLongitude(parser.nextText());
				} else if ("data".equals(parser.getName())) {
					extension.setBase64Msg(parser.nextText());
					// extension.setMsg(parser.nextText());
				}
				break;
			case XmlPullParser.END_TAG:
				if ("lbsItem".equals(parser.getName())) {
					System.out.println(extension.toXML());
					return extension;
				}
				break;
			default:
				break;
			}
			event = parser.next();
		}

		return null;
	}

	/**
	 * a Extension to Pubsub Briefly describe what this class does.
	 */
	public static class PubsubExtension implements PacketExtension {

		public static final String NAMESPACE = "http://jabber.org/protocol/geoloc";
		public static final String ELEMENT = "geoloc";

		private String accuracy;
		private String country;
		private String latitude;
		private String locality;
		private String longitude;
		private String language;
		private boolean loc;
		private String msg;
		private String appId;
		private long distense = 500;

		@Override
		public String getElementName() {
			return ELEMENT;
		}

		@Override
		public String getNamespace() {
			return NAMESPACE;
		}

		@Override
		public String toXML() {
			StringBuilder buf = new StringBuilder();

			buf.append("<lbsItem appId = '" + appId + "'" + ">");

			if (loc) {
				buf.append("<geoloc xmlns='" + NAMESPACE + "' xml:lang='"
						+ language + "' distense='" + distense + "'>");
				if (getAccuracy() != null) {
					buf.append("<accuracy>").append(accuracy)
							.append("</accuracy>");
				}
				if (getCountry() != null) {
					buf.append("<country>").append(country)
							.append("</country>");
				}
				if (getLatitude() != null) {
					buf.append("<lat>").append(latitude).append("</lat>");
				}
				if (getLocality() != null) {
					buf.append("<locality>").append(locality)
							.append("</locality>");
				}
				if (getLongitude() != null) {
					buf.append("<lon>").append(longitude).append("</lon>");
				}
				buf.append("</geoloc>");
			}
			buf.append("<data>").append(msg).append("</data>");
			buf.append("</lbsItem>");
			return buf.toString();
		}

		public String getAccuracy() {
			return accuracy;
		}

		public void setAccuracy(String accuracy) {
			this.accuracy = accuracy;
		}

		public String getCountry() {
			return country;
		}

		public void setCountry(String country) {
			this.country = country;
		}

		public String getLatitude() {
			return latitude;
		}

		public void setLatitude(String latitude) {
			this.latitude = latitude;
		}

		public String getLongitude() {
			return longitude;
		}

		public void setLongitude(String longitude) {
			this.longitude = longitude;
		}

		public String getLocality() {
			return locality;
		}

		public void setLocality(String locality) {
			this.locality = locality;
		}

		public String getLanguage() {
			return language;
		}

		public void setLanguage(String language) {
			this.language = language;
		}

		public boolean isLoc() {
			return loc;
		}

		public void setLoc(boolean loc) {
			this.loc = loc;
		}

		/**
		 * Base64 decode the string msg Briefly describe what it does.
		 * <p>
		 * If necessary, describe how it does and how to use it.
		 * </P>
		 * 
		 * @return
		 */
		public String getMsg() {
			String returnStr = "";
			try {
				returnStr = new String(Base64.decode(msg), "UTF-8");
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
			;
			return returnStr;
		}

		/**
		 * Base64 encode the string msg Briefly describe what it does.
		 * <p>
		 * If necessary, describe how it does and how to use it.
		 * </P>
		 * 
		 * @param msg
		 */
		public void setMsg(String msg) {
			try {
				this.msg = Base64.encodeBytes(msg.getBytes("UTF-8"));
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
		}

		public void setBase64Msg(String msg) {
			this.msg = msg;
		}

		public String getAppId() {
			return appId;
		}

		public void setAppId(String appId) {
			this.appId = appId;
		}

		public long getDistense() {
			return distense;
		}

		public void setDistense(long distense) {
			this.distense = distense;
		}

	}

}
