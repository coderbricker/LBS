// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.service;

import java.lang.reflect.InvocationTargetException;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.gplocation.lbs.engine.GeneralReceiveEngine;
import com.gplocation.lbs.engine.GroupReceiveEngine;
import com.gplocation.lbs.engine.InternalReceiveEngine;
import com.gplocation.lbs.engine.PubsubReceiveEngine;
import com.gplocation.lbs.engine.RosterReceiveEngine;
import com.gplocation.lbs.utils.Constants;

/**
 * return data to client, and write data into our own database
 */
public class ReceiveRunnable implements Runnable {

	private static final String TAG = "ReceiveRunnable";
	
	/**
	 * all other modules want to get this handler could get from MainApplication
	 */
	private Handler receiveHandler;
	private Context context;

    private GeneralReceiveEngine generalReceiveEngine;
    private GroupReceiveEngine groupReceiveEngine;
    private PubsubReceiveEngine pubsubReceiveEngine;
    private RosterReceiveEngine rosterReceiveEngine;
    private InternalReceiveEngine internalReceiveEngine;
	
	public ReceiveRunnable(Context context) {
		this.context = context;
	}
	
	
	@Override
	public void run() {
		Looper.prepare();
	      
		generalReceiveEngine = new GeneralReceiveEngine(context);
		groupReceiveEngine = new GroupReceiveEngine(context);
		pubsubReceiveEngine = new PubsubReceiveEngine(context);
		rosterReceiveEngine = new RosterReceiveEngine(context);
		internalReceiveEngine = new InternalReceiveEngine(context);
	        
		receiveHandler = new Handler() {
	        @Override
	        public void handleMessage(android.os.Message msg) {	
	        	int type = msg.getData().getInt("type");
				try {
					switch (type) {
					case Constants.MESSAGE_GENERAL_TYPE:
						if (msg.what > -1 && msg.what < GeneralReceiveEngine.generalReceiveCommands.length) {
							generalReceiveEngine.dynaCall(
									GeneralReceiveEngine.generalReceiveCommands[msg.what].getFun(), msg);
						} else {
							Log.d(TAG, "the message is out of GeneralReceiveEngine handle region");
						}
						break;
					case Constants.MESSAGE_FRIEND_TYPE:
						if (msg.what > -1 && msg.what < RosterReceiveEngine.rosterReceiveCommands.length) {
							rosterReceiveEngine.dynaCall(
									RosterReceiveEngine.rosterReceiveCommands[msg.what].getFun(), msg);
						} else {
							Log.d(TAG, "the message is out of RosterReceiveEngine handle region");
						}
						break;
					case Constants.MESSAGE_GROUP_TYPE:
						if (msg.what > -1 && msg.what < GroupReceiveEngine.groupReceiveCommands.length) {
							groupReceiveEngine.dynaCall(
									GroupReceiveEngine.groupReceiveCommands[msg.what].getFun(), msg);
						} else {
							Log.d(TAG, "the message is out of GroupReceiveEngine handle region");
						}
						break;
					case Constants.MESSAGE_PUBSUB_TYPE:
					    if (msg.what > -1 && msg.what < PubsubReceiveEngine.pubsubReceiveCommands.length) {
					        pubsubReceiveEngine.dynaCall(
					        		PubsubReceiveEngine.pubsubReceiveCommands[msg.what].getFun(), msg);
                        } else {
                            Log.d(TAG, "the message is out of PubsubReceiveEngine handle region");
                        }
						break;
					case Constants.MESSAGE_INTERAL_TYPE:
					    if (msg.what > -1 && msg.what < InternalReceiveEngine.InternalReceiveCommands.length) {
					    	internalReceiveEngine.dynaCall(
					    			InternalReceiveEngine.InternalReceiveCommands[msg.what].getFun(), msg);
                        } else {
                            Log.d(TAG, "the message is out of InternalReceiveEngine handle region");
                        }
						break;
					default:
						super.handleMessage(msg);
						break;
					}
				} catch (NoSuchMethodException e) {
					e.printStackTrace();
				} catch (InvocationTargetException e) {
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				}
					           
	        }
	    };
	    
	    
	    //note the store handler to this application\
	    ((LBSCoreService) context).xmppRunnable.registerReceiveHandler(receiveHandler);
	    
	    synchronized (((LBSCoreService) context).xmppRunnable) {
       	 	((LBSCoreService) context).xmppRunnable.notify();
		}
	    

        Log.d(TAG, "after notify");
        
	    Looper.loop();		
	}
	

}
