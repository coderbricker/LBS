// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.

package com.gplocation.lbs.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.filter.PacketFilter;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Packet;
import org.jivesoftware.smack.packet.PacketExtension;
import org.jivesoftware.smack.packet.Presence;
import org.jivesoftware.smackx.packet.MUCUser;
import org.jivesoftware.smackx.packet.MUCUser.Status;
import org.jivesoftware.smackx.packet.VCard;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.util.Log;

import com.gplocation.lbs.application.MainApplication;
import com.gplocation.lbs.data.GeoLocation;
import com.gplocation.lbs.data.Setting;
import com.gplocation.lbs.engine.GroupReceiveEngine;
import com.gplocation.lbs.engine.GroupXmppEngine;
import com.gplocation.lbs.engine.RosterReceiveEngine;
import com.gplocation.lbs.engine.RosterXmppEngine;
import com.gplocation.lbs.manager.RosterManager;
import com.gplocation.lbs.packetprovider.GroupSettingExtension;
import com.gplocation.lbs.packetprovider.GroupSettingIQ;
import com.gplocation.lbs.packetprovider.LocationExtensionProvider;
import com.gplocation.lbs.packetprovider.NotifyExtensionProvider;
import com.gplocation.lbs.utils.Constants;

/**
 * @brief parse the Xml message send by openfire
 */
public class XmppPacketParser {

	private static final String TAG = "XmppPacketParser";

	private Handler receiveHandler;
	private Handler xmppClientHandler;
	private Context context;
	private SmackWrapper xmppClient;
	private RosterXmppEngine rosterXmppEngine;
	private GroupXmppEngine groupXmppEngine;
	

	public static class GroupMemberStatusFilter implements PacketFilter {
		public GroupMemberStatusFilter() {

		}

		@Override
		public boolean accept(Packet pk) {
			if (pk.getClass().equals(Presence.class)) {
				if (((Presence) pk).getStatus() != null) {
					Log.d(TAG, "GroupMemberStatusFilter" + pk.toXML());
					return true;
				}
			}
			return false;
		}
	}

	public static class RosterChangeFilter implements PacketFilter {
		public RosterChangeFilter() {

		}

		@Override
		public boolean accept(Packet pk) {
			if (pk.getClass().equals(Presence.class)) {
				if (((Presence) pk).getType().equals(Presence.Type.subscribe)
						|| ((Presence) pk).getType().equals(
								Presence.Type.unsubscribe)) {
					return true;
				}
			}
			return false;
		}

	}

	public XmppPacketParser(Handler receiveHandler, Handler xmppClientHandler,
			Context context, SmackWrapper xmppClient) {
		this.receiveHandler = receiveHandler;
		this.xmppClientHandler = xmppClientHandler;
		this.context = context;
		this.xmppClient = xmppClient;
	}

	/**
	 * @brief <p>
	 *        erase the source string if necessary
	 *        </P>
	 * @param account
	 * @return
	 */
	public static String ignoreAccountSource(final String account) {
		int index = account.indexOf('/');
		if (index != -1) {
			return account.substring(0, index);
		}

		return account;
	}

	/**
	 * @brief <p>
	 *        get the account source string
	 *        </P>
	 * @param account
	 * @return
	 */
	public static String getAccountSource(final String account) {
		int index = account.indexOf('/');
		if (index != -1) {
			return account.substring(index + 1);
		}

		return account;
	}

	/**
	 * @brief <p>
	 *        parse the location message, or single location, and
	 *        request/follow, stop sharing, stop follow location
	 *        </P>
	 * @param pk
	 */
	public void locationParser(Packet pk) {
		PacketExtension pe = pk.getExtension(
				LocationExtensionProvider.LocationExtension.ELEMENT,
				LocationExtensionProvider.LocationExtension.NAMESPACE);

		String appId = (String) pk.getProperty("appId");
		String text = ((Message) pk).getBody();
		if (text == null) {
			text = ((Message) pk).getBody("en");
		}
		
		String action = "";
		Log.d(TAG,
				"text =" + text + 
				"locationParser="
						+ pk.toXML()
						+ ((LocationExtensionProvider.LocationExtension) pe)
								.getAction());
		if (pe instanceof LocationExtensionProvider.LocationExtension) {
			String from = pk.getFrom().split("/")[0];

			Log.d(TAG, 
					"locationParser, LocationExtensionProvider.LocationExtension");
			LocationExtensionProvider.LocationExtension le = (LocationExtensionProvider.LocationExtension) pe;
			action = le.getAction();
			if ("".equals(action)) {
				GeoLocation locationDomain = new GeoLocation();
				locationDomain.setFrom(from);
				locationDomain.setAccuracy(le.getAccuracy());
				locationDomain.setLatitude(le.getLatitude());
				locationDomain.setLongitude(le.getLongitude());
				locationDomain.setCountry(le.getCountry());
				locationDomain.setLanguage(le.getLanguage());
				locationDomain.setLatitude(le.getLatitude());

				Log.d(TAG,
						"(Message) pk).getType()=" + ((Message) pk).getType());

				android.os.Message msg = new android.os.Message();

				Bundle bl = new Bundle();
				if (text != null) {
					bl.putString("text", text);
				}
				bl.putString("appId", appId);
				if (locationDomain.getLatitude() != null) {
					bl.putParcelable("location", locationDomain);
				}

				if (Message.Type.groupchat.equals(((Message) pk).getType())) {
					if (text != null && !"".equals(text)) {
						msg.what = GroupReceiveEngine.RETURN_MESSAGE_MSG;
					} else {
						msg.what = GroupReceiveEngine.RETURN_LOCATION_MSG;
					}
					// send message
					bl.putInt("type", Constants.MESSAGE_GROUP_TYPE);
					bl.putString("fromId", pk.getFrom());
					msg.setData(bl);

					receiveHandler.sendMessage(msg);

				} else if (Message.Type.normal.equals(((Message) pk).getType())) {

					if (text != null && !"".equals(text)) {
						msg.what = RosterReceiveEngine.RETURN_MESSAGE_MSG;
					} else {
						msg.what = RosterReceiveEngine.RETURN_LOCATION_MSG;
					}
					bl.putInt("type", Constants.MESSAGE_FRIEND_TYPE);
					bl.putString("friendId", pk.getFrom().split("/")[0]);

					msg.setData(bl);

					receiveHandler.sendMessage(msg);
				} else {
					Log.d(TAG, "Do not know packet!");
				}
			} else {
				// request/follow/stop share/stop follow
				android.os.Message msg = new android.os.Message();

				Bundle bl = new Bundle();
				bl.putInt("type", Constants.MESSAGE_FRIEND_TYPE);
				bl.putString("friendId", pk.getFrom().split("/")[0]);
				bl.putString("appId", appId);
				msg.setData(bl);

				if (action.equals("request")) {
					msg.what = RosterReceiveEngine.RETURN_REQUEST_LOCATION_MSG;
					receiveHandler.sendMessage(msg);
				} else if (action.equals("follow")) {
					msg.what = RosterReceiveEngine.RETURN_FOLLOW_LOCATION_MSG;
					receiveHandler.sendMessage(msg);
				} else if (action.equals("stopShare")) {
					msg.what = RosterReceiveEngine.RETURN_STOP_SHARE_LOCATION_MSG;
					receiveHandler.sendMessage(msg);

					// send client stop follow msg?
				} else if (action.equals("stopFollow")) {
					msg.what = RosterReceiveEngine.RETURN_STOP_FOLLOW_LOCATION_MSG;
					receiveHandler.sendMessage(msg);

					// stop sharing to
					android.os.Message msgSharing = new android.os.Message();
					msgSharing.what = RosterXmppEngine.STOP_SHARE_LOCATION_MSG;
					Bundle blSharing = new Bundle();
					blSharing.putInt("type", Constants.MESSAGE_FRIEND_TYPE);
					blSharing.putString("friendId", pk.getFrom().split("/")[0]);
					blSharing.putString("appId", appId);
					msgSharing.setData(blSharing);
					xmppClientHandler.sendMessage(msgSharing);

				} else if (action.equals("stopShareInGroup")) {

					android.os.Message msgGroup = new android.os.Message();

					Bundle b = new Bundle();
					b.putInt("type", Constants.MESSAGE_GROUP_TYPE);
					b.putString("fromId", pk.getFrom());
					b.putString("appId", appId);
					msgGroup.setData(b);

					msgGroup.what = GroupReceiveEngine.RETURN_STOP_SHARING_MSG;
					receiveHandler.sendMessage(msgGroup);
				}
			}
		}
	}

	/**
	 * @brief <p>
	 *        parse the add/remove friend messages
	 *        </P>
	 * @todo bi-add friend, not know the friend's nickname
	 * @param pk
	 */
	public void rosterChangeParser(Packet pk) {
		Log.d(TAG, "rosterChangeParser, received:" + pk.toXML());

		RosterManager rosterManager = ((MainApplication) ((LBSCoreService) context)
				.getApplication()).rosterManager;

		Presence presence = (Presence) pk;
		String from = ignoreAccountSource(pk.getFrom());
		Presence.Type type = presence.getType();

		if (type.equals(Presence.Type.subscribe)) {
			// if from is not in roster then add
			Log.d(TAG, "Presence.Type.subscribe");
			if (!rosterManager.contain(from)) {
				Log.d(TAG, "bi-add friend");
				String nickName = from.substring(0, from.indexOf('@'));

				// send message to client
				android.os.Message msg = new android.os.Message();
				msg.what = RosterReceiveEngine.RETURN_ADD_BY_SOMEBODY_MSG;
				Bundle bl = new Bundle();
				bl.putInt("type", Constants.MESSAGE_FRIEND_TYPE);
				bl.putString("friendId", from);
				
				VCard vCard = new VCard();
				try {
					vCard.load(xmppClient.xmppConn, from);
					String nick = vCard.getNickName();
					if (nick != null && !"".equals(nick)) {
						nickName = nick;
					}
					bl.putString("nick", nickName);
					String email = vCard.getEmailHome();
					bl.putString("email", email);
					
					String phone = vCard.getPhoneHome(Constants.DEFAULT_PHONE_TYPE);
					bl.putString("phone", phone);
					
				} catch (XMPPException e) {
					e.printStackTrace();
				}
				
				rosterManager.addRoster(from, nickName);
				
				msg.setData(bl);
				receiveHandler.sendMessage(msg);
			}
		} else if (type.equals(Presence.Type.unsubscribe)) {
			// if from is in roster then remove
			if (rosterManager.contain(from)) {
				Log.d(TAG, "bi-remove friend");

				String nick = rosterManager.getRosterNick(from);
				// send message to client
				android.os.Message msg = new android.os.Message();
				msg.what = RosterReceiveEngine.RETURN_REMOVE_BY_SOMEBODY_MSG;
				Bundle bl = new Bundle();
				bl.putInt("type", Constants.MESSAGE_FRIEND_TYPE);
				bl.putString("friendId", from);
				bl.putString("nick", nick);
				msg.setData(bl);
				receiveHandler.sendMessage(msg);

				rosterManager.removeRoster(from);
				if (rosterXmppEngine != null) {
					rosterXmppEngine.removeRosterTimer(from);
				}
			}
		}
	}

	/**
	 * <p>
	 * notify parser
	 * </P>
	 * 
	 * @param pk
	 */
	public void notifyParser(Packet pk) {
		PacketExtension pe = pk.getExtension(
				NotifyExtensionProvider.NotifyExtension.ELEMENT,
				NotifyExtensionProvider.NotifyExtension.NAMESPACE);

		String groupId = pk.getTo().split("/")[0];
		String appId = (String) pk.getProperty("appId");

		Log.d(TAG, "notifyParser, PacketExtension---" + groupId + pk.toXML());

		android.os.Message msg = new android.os.Message();
		Bundle bl = new Bundle();
		bl.putInt("type", Constants.MESSAGE_GROUP_TYPE);
		bl.putString("groupId", groupId);
		bl.putString("appId", appId);

		if (pe instanceof NotifyExtensionProvider.NotifyExtension) {
			NotifyExtensionProvider.NotifyExtension le = (NotifyExtensionProvider.NotifyExtension) pe;

			String command = le.getCommand();
			if (command.equals(Constants.NOTIFY_UPDATE_GROUP_SETTING)) {
				// query group setting
				msg.what = GroupXmppEngine.REQUEST_SETTING_MSG;
				groupId = le.getParam().split("/")[0];
				String settinName = le.getParam().split("/")[1];
				bl.putString("groupId", groupId);
				bl.putString("settingName", settinName);
				msg.setData(bl);

				xmppClientHandler.sendMessage(msg);

				// coreServiceHandler.obtainMessage(Command.QUERY_GROUP_SETTING_MSG,
				// groupIds).sendToTarget();
			} else if (command.equals(Constants.NOTIFY_START_SHARING_IN_GROUP)) {
				Log.d(TAG, "beginShareInGroup");
				// xmppClientHandler.obtainMessage(Command.INTERNAL_BEGIN_SHARELOCATION,
				// from).sendToTarget();
			} else if (command.equals(Constants.NOTIFY_START_SHARING_IN_GROUP)) {
				Log.d(TAG, "endShareInGroup");
				// xmppClientHandler.obtainMessage(Command.INTERNAL_STOP_SHARELOCATION,
				// from).sendToTarget();
			} else if (command
					.equals(Constants.NOTIFY_START_EXCUTE_GROUP_SETTING)) {

				msg.what = GroupReceiveEngine.RETURN_NOTIFY_SETTING_ACTION_MSG;
				groupId = le.getParam().split("/")[0];
				String settinName1 = le.getParam().split("/")[1];
				bl.putString("groupId", groupId);
				bl.putString("settingName", settinName1);
				bl.putString("action", "start");
				msg.setData(bl);

				receiveHandler.sendMessage(msg);

			} else if (command
					.equals(Constants.NOTIFY_STOP_EXCUTE_GROUP_SETTING)) {
				msg.what = GroupReceiveEngine.RETURN_NOTIFY_SETTING_ACTION_MSG;
				groupId = le.getParam().split("/")[0];
				String settinName1 = le.getParam().split("/")[1];
				bl.putString("groupId", groupId);
				bl.putString("settingName", settinName1);
				bl.putString("action", "end");
				msg.setData(bl);

				receiveHandler.sendMessage(msg);
			}

		}

	}
	
	/**
	 * @brief <p>
	 *        parse the group message
	 *        </P>
	 * @param pk
	 * @param context
	 */
	public void groupParser(Packet pk, Context context) {
		Log.d(TAG, "groupParser," + pk.toXML());
		PacketExtension pe = pk.getExtension("x",
				"http://jabber.org/protocol/muc#user");

		String from = pk.getFrom();
		Log.d(TAG, "from=" + from + " " + ((Presence) pk).getType());
		Status st = ((MUCUser) pe).getStatus();

		// remove group
		org.jivesoftware.smackx.packet.MUCUser.Destroy destroy = ((MUCUser) pe)
				.getDestroy();
		if (destroy != null) {
			String destroyString = destroy.getReason();
			if ("destroy".equals(destroyString)) {
				android.os.Message msg = new android.os.Message();
				msg.what = GroupReceiveEngine.RETURN_GROUP_LIST_CHANGED_MSG;

				Bundle bl = new Bundle();
				bl.putInt("type", Constants.MESSAGE_GROUP_TYPE);
				bl.putString("groupId", from.split("/")[0]);
				bl.putString("reason", destroyString);
				bl.putString("action", "remove");
				msg.setData(bl);

				// there is no appId
				receiveHandler.sendMessage(msg);
				
				if (groupXmppEngine != null) {
					groupXmppEngine.removeGroupTimer(from.split("/")[0]);
				}
			}
		}

		// kick-out a user could has status code
		// member list or role changed
		if (destroy == null) {
			String affi = "";
			String role = "";
			String memberId = "";
			for (PacketExtension pack : pk.getExtensions()) {
				String[] args = pack.toXML().split(" ");
				for (String ss : args) {
					if (ss.contains("affiliation")) {
						affi = ss.substring(ss.indexOf("\"") + 1,
								ss.lastIndexOf("\""));
					} else if (ss.contains("role")) {
						role = ss.substring(ss.indexOf("\"") + 1,
								ss.lastIndexOf("\""));
					} else if (ss.contains("jid") && memberId.equals("")) {
						int start = ss.indexOf("\"");
						int end = ss.lastIndexOf("\"");
						if (start < end) {
							String id = ss.substring(ss.indexOf("\"") + 1,
									ss.lastIndexOf("\""));
							if (!id.equals("")) {
								memberId = id.split("/")[0];
							}
						} else {
							String id = ss.substring(start + 1, ss.length());
							if (!id.equals("")) {
								memberId = id.split("/")[0];
							}
						}
					}
				}
			}

			if (affi.equals("")) {
				affi = "none";
			}
			if (role.equals("")) {
				role = "participant";
			}

			if (((Presence) pk).getType().equals(Presence.Type.available)) {
				// add a member
				android.os.Message msg = new android.os.Message();
				msg.what = GroupReceiveEngine.RETURN_MEMBER_LIST_CHANGED_MSG;

				Bundle bl = new Bundle();
				bl.putInt("type", Constants.MESSAGE_GROUP_TYPE);
				bl.putString("groupId", from.split("/")[0]);
				bl.putString("memberId", memberId);
				bl.putString("nick", from.split("/")[1]);
				bl.putString("affiliation", role);
				bl.putString("role", affi); // role we define is actually
											// affiliate
				bl.putString("action", "add");
				msg.setData(bl);

				// there is no appId
				receiveHandler.sendMessage(msg);

			} else if (((Presence) pk).getType().equals(
					Presence.Type.unavailable)) {
				// kicked-out by other
//				String user = ((MainApplication) ((LBSCoreService) context)
//						.getApplication()).userInfo.getUserName();
				String userId =  ((MainApplication) ((LBSCoreService) context)
						.getApplication()).userInfo.getUserId();
				if (st != null && memberId.equals(userId)) {
					// delete the group
					android.os.Message msg = new android.os.Message();
					msg.what = GroupReceiveEngine.RETURN_GROUP_LIST_CHANGED_MSG;

					Bundle bl = new Bundle();
					bl.putInt("type", Constants.MESSAGE_GROUP_TYPE);
					bl.putString("groupId", from.split("/")[0]);
					bl.putString("action", "remove");
					msg.setData(bl);

					// there is no appId
					receiveHandler.sendMessage(msg);

					groupXmppEngine.removeGroupTimer(from.split("/")[0]);
				}

				// delete the member
				android.os.Message msg = new android.os.Message();
				msg.what = GroupReceiveEngine.RETURN_MEMBER_LIST_CHANGED_MSG;

				Bundle bl = new Bundle();
				bl.putInt("type", Constants.MESSAGE_GROUP_TYPE);
				bl.putString("groupId", from.split("/")[0]);
				bl.putString("memberId", memberId);
				bl.putString("action", "remove");
				msg.setData(bl);

				// there is no appId
				receiveHandler.sendMessage(msg);
			}
		}

	}

	/**
	 * parse groupsetting message if get group setting, the message contain
	 * GroupSettingIQ
	 * 
	 * @param pkt
	 */
	public void groupSettingParser(Packet pkt) {
		Log.d(TAG, "groupSettingParser," + pkt.toXML());
		// String key = pk.getPacketID();
		if (!(pkt instanceof GroupSettingIQ)) {
			return;
		}
		GroupSettingIQ groupSettingIQ = (GroupSettingIQ) pkt;
		Collection<PacketExtension> extList = groupSettingIQ.getExtensions();
		for (PacketExtension pktExt : extList) {
			if (!(pktExt instanceof GroupSettingExtension)) {
				continue;
			}
			GroupSettingExtension groupSettingExt = (GroupSettingExtension) pktExt;

			String appId = groupSettingExt.getAppID();
			String groupId = groupSettingExt.getGroupID();
			String settingName = groupSettingExt.getSettingName();
			List<Setting> settingList = groupSettingExt.getSettings();

			// send message to client
			android.os.Message msg = new android.os.Message();
			msg.what = GroupReceiveEngine.RETURN_SETTING_CHANGED_MSG;
			Bundle bl = new Bundle();
			bl.putInt("type", Constants.MESSAGE_GROUP_TYPE);

			bl.putString("groupId", groupId);
			bl.putString("appId", appId);
			bl.putString("settingName", settingName);
			bl.putParcelableArrayList("setting",
					(ArrayList<? extends Parcelable>) settingList);
			msg.setData(bl);
			receiveHandler.sendMessage(msg);
		}
	}
	
	
	/**
	 * <p>
	 * register the receive handler, if not call this function, the handler is
	 * null forever
	 * </P>
	 * 
	 * @param handler
	 */
	public void registerReceiveHandler(Handler handler) {
		this.receiveHandler = handler;
	}

	public RosterXmppEngine getRosterXmppEngine() {
		return rosterXmppEngine;
	}

	public void setRosterXmppEngine(RosterXmppEngine rosterXmppEngine1) {
		this.rosterXmppEngine = rosterXmppEngine1;
	}

	public GroupXmppEngine getGroupXmppEngine() {
		return groupXmppEngine;
	}

	public void setGroupXmppEngine(GroupXmppEngine groupXmppEngine1) {
		this.groupXmppEngine = groupXmppEngine1;
	}

}
