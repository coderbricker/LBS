// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.

package com.gplocation.lbs.service;

import java.util.HashMap;

import android.content.Context;
import android.os.RemoteException;
import android.util.Log;

import com.gplocation.lbs.application.MainApplication;
import com.gplocation.lbs.client.IGeneralListener;
import com.gplocation.lbs.manager.BinderManager;
import com.gplocation.lbs.manager.ReceiveManager;
import com.gplocation.lbs.template.TemplateListeners.TemplateSubListener;

/**
 * detect whether client is running.
 */
public class LBSDetectThread extends Thread {
	private static final String TAG = "LBSDetectThread";
	
	private boolean running = true;
	private Context context;
	
	public LBSDetectThread(Context context) {
		this.context = context;
	}
	
	@Override
	public void run () {
		MainApplication mainApplication = ((MainApplication) ((LBSCoreService) context).getApplication());
		ReceiveManager receiveManager = mainApplication.receiveManager;
        BinderManager binderManager = mainApplication.binderManager;
		
		while (running) {
			Log.d(TAG, "LBSDetectThread running");
			HashMap<String, TemplateSubListener<IGeneralListener>> listeners = 
					receiveManager.getGeneralListeners().getListeners();
			String appId = null;
			for (String key : listeners.keySet()) {
				try {
					listeners.get(key).listener.receiveUnusefulInfo();
				} catch (RemoteException e) {
					e.printStackTrace();
					appId = key;
					break;
				}
			}
			
			synchronized (this) {	        
		        if (appId != null) {
		        	if (((LBSCoreService) context).xmppRunnable.rosterXmppEngine != null 
		        		&& ((LBSCoreService) context).xmppRunnable.groupXmppEngine != null) {
		        		((LBSCoreService) context).xmppRunnable.rosterXmppEngine.removeTimer(appId);
		        		((LBSCoreService) context).xmppRunnable.groupXmppEngine.removeTimer(appId);
		        	}
					
		        	receiveManager.getGeneralListeners().remove(appId);
		        	receiveManager.getFriendListeners().remove(appId);
		        	receiveManager.getGroupListeners().remove(appId);
		        	receiveManager.getPubSubListeners().remove(appId);
			        	
		        	binderManager.remove(appId);
		        }
			}
			
			try {
				Thread.sleep(5000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}


	public boolean isRunning() {
		return running;
	}

	public void setRunning(boolean running) {
		this.running = running;
	}
	

}
