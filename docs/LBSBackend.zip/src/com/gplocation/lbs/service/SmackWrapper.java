// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.service;

import org.jivesoftware.smack.ConnectionConfiguration;
import org.jivesoftware.smack.ConnectionListener;
import org.jivesoftware.smack.XMPPConnection;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smackx.packet.VCard;

import android.content.Context;
import android.util.Log;

import com.gplocation.lbs.application.MainApplication;
import com.gplocation.lbs.utils.Constants;
import com.gplocation.lbs.utils.UserPreference;

/**
 * Wrap smack and keep xmpp connection, user/pass, connection configuration, run in the thread
 * @author jianbinxu
 * 
 */
public class SmackWrapper {
    private static final String TAG = "SmackWrapper";

    private String user;
    private String pass;
    private String xmppDomain;
    private String xmppServerHost;
    private int xmppPort;

    private ConnectionConfiguration connConf;
    public XMPPConnection xmppConn;
    public int connectionState = Constants.CONNECTION_UNKNOWN;

    public XMPPConnection getXmppConn() {
        return xmppConn;
    }

    //    not use
    //    private ProxyInfo proxy;

    public SmackWrapper(String user, String pass, String domain) {
        this.user = user;
        this.pass = pass;
        this.xmppDomain = domain;
    }

    public void setHostAndPort(String serverHost, int port) {
        this.xmppServerHost = serverHost;
        this.xmppPort = port;
        connConf = new ConnectionConfiguration(xmppServerHost, xmppPort, xmppDomain);
        xmppConn = new XMPPConnection(connConf);
    }

    private class XmppConnectionListener implements ConnectionListener {
    	private Context context;
    	
    	public XmppConnectionListener(Context context) {
    		this.context = context;
    	}
    	
    	@Override
        public void connectionClosed() {
            Log.d(TAG, "connectionClosed normally or that the reconnection process has been aborted.");
            connectionState = Constants.CONNECTION_DISCONNECTED;
            ((MainApplication) ((LBSCoreService) context).getApplication()).xmppConnectionState = connectionState;
        }

        @Override
        public void connectionClosedOnError(Exception arg0) {
            Log.d(TAG, "connectionClosedOnError connection was closed due to an exception" + arg0.toString());
//            connectionState = Constants.CONNECTION_DISCONNECTED;
//            ((MainApplication)((LBSCoreService) context).getApplication()).xmppConnectionState = connectionState;
        }

        @Override
        public void reconnectingIn(int arg0) {
            Log.d(TAG, "reconnectingIn The connection will retry to reconnect in the specified number of seconds");
        }

        @Override
        public void reconnectionFailed(Exception arg0) {
            Log.d(TAG, "reconnectionFailed");
            connectionState = Constants.CONNECTION_FAILED;
            ((MainApplication) ((LBSCoreService) context).getApplication()).xmppConnectionState = connectionState;
        }

        @Override
        public void reconnectionSuccessful() {
            Log.d(TAG, "reconnectionSuccessful");
            connectionState = Constants.CONNECTION_CONNECTED;
            ((MainApplication) ((LBSCoreService) context).getApplication()).xmppConnectionState = connectionState;
        }
    	
    }
    
    @SuppressWarnings("finally")
    public int loginXMPPServer(Context context) {
        try {
        	Log.d(TAG, "try xmppConn.connect");
            xmppConn.connect();
            Log.d(TAG, "try xmppConn.login " + user + ":" + pass);
            xmppConn.login(user, pass);
            
//            xmppConn.disconnect();
//            xmppConn.connect();
//            Log.d(TAG, "try xmppConn.login + a3321118 ");
//            xmppConn.login("a3321118", "123");
//            Log.d(TAG, "try xmppConn.login end" + xmppConn.getUser());
            
        } catch (XMPPException e) {
            Log.d(TAG, "loginXMPPServerInternal XMPPException");
            e.printStackTrace();
        } finally {
            Log.d(TAG, "try xmppConn.login end" + user + ":" + pass);
            if (xmppConn.isAuthenticated()) {
                xmppConn.addConnectionListener(new XmppConnectionListener(context));
                connectionState = Constants.CONNECTION_CONNECTED;
                ((MainApplication) ((LBSCoreService) context).getApplication()).xmppConnectionState = connectionState;
                            
                Log.d(TAG, "connection=" + ((MainApplication) ((LBSCoreService) context)
                		.getApplication()).xmppConnectionState);
//                TestTmp.addPresencePacketListener(xmppConn);
               
                // save userId
                String user = xmppConn.getUser().split("/")[0];
                Log.d(TAG, "userId = " + user);
                if (((MainApplication) ((LBSCoreService) context).getApplication()).userInfo.getUserId().equals("") 
                		&& user != null) {
                	((MainApplication) ((LBSCoreService) context).getApplication()).userInfo.setUserId(user);
                	UserPreference.saveUserId(user, context);
                	
					Log.d(TAG, "saveUserId user=" + user);
                	VCard vCard = new VCard();
                	try {
						vCard.load(xmppConn);
						String phone = vCard.getPhoneHome("VOICE");
						String email = vCard.getEmailHome();
						String nick = vCard.getNickName();
						((MainApplication) ((LBSCoreService) context).getApplication()).userInfo.setvCardPhone(phone);
						UserPreference.savevCardPhone(phone, context);
						((MainApplication) ((LBSCoreService) context).getApplication()).userInfo.setvCardEmail(email);
						UserPreference.savevCardEmail(email, context);
						
						if (nick == null || (nick != null && "".equals(nick))) {
							nick = user.split("@")[0];
						}
						Log.d(TAG, "nick=" + nick);
						
						((MainApplication) ((LBSCoreService) context).getApplication()).userInfo.setUserNick(nick);
						UserPreference.saveUserNick(nick, context);
						
					} catch (XMPPException e) {
						e.printStackTrace();
					}
                	
                }
                return Constants.CONNECTION_CONNECTED;
            } else {
                connectionState = Constants.CONNECTION_FAILED;
                return Constants.CONNECTION_FAILED;
            }
        }
    }
    
    
    @SuppressWarnings("finally")
	public int reLoginXMPPServer(Context context, String userName, String pass) {
    	    	
		xmppConn.disconnect();
		try {
			xmppConn.connect();
			Log.d(TAG, "try xmppConn.login" + userName);
			xmppConn.login(userName, pass);
			Log.d(TAG, "try xmppConn.login end" + xmppConn.getUser());
		} catch (XMPPException e) {
			e.printStackTrace();
		}  finally {
            if (xmppConn.isAuthenticated()) {
//                xmppConn.addConnectionListener(new XmppConnectionListener(context));
                connectionState = Constants.CONNECTION_CONNECTED;
                ((MainApplication) ((LBSCoreService) context).getApplication()).xmppConnectionState = connectionState;
                            
                Log.d(TAG, "connection=" + ((MainApplication) ((LBSCoreService) context)
                		.getApplication()).xmppConnectionState);
//                TestTmp.addPresencePacketListener(xmppConn);
               
                // save userId
                String user = xmppConn.getUser().split("/")[0];
                Log.d(TAG, "userId = " + user);
               
               
            	((MainApplication) ((LBSCoreService) context).getApplication()).userInfo.setUserId(user);
            	((MainApplication) ((LBSCoreService) context).getApplication()).userInfo.setUserPassword(pass);
            	((MainApplication) ((LBSCoreService) context).getApplication()).userInfo.setUserName(userName);
            	
            	UserPreference.saveUserId(user, context);
            	UserPreference.saveUserPassword(pass, context);
            	UserPreference.saveUser(userName, context);
            	
				Log.d(TAG, "saveUserId user=" + user);
            	VCard vCard = new VCard();
            	
            	try {
					vCard.load(xmppConn);
					String phone = vCard.getPhoneHome("VOICE");
					String email = vCard.getEmailHome();
					String nick = vCard.getNickName();
					((MainApplication) ((LBSCoreService) context).getApplication()).userInfo.setvCardPhone(phone);
					UserPreference.savevCardPhone(phone, context);
					((MainApplication) ((LBSCoreService) context).getApplication()).userInfo.setvCardEmail(email);
					UserPreference.savevCardEmail(email, context);
					
					if (nick == null || (nick != null && "".equals(nick))) {
						nick = user.split("@")[0];
					}
					Log.d(TAG, "nick=" + nick);
					
					((MainApplication) ((LBSCoreService) context).getApplication()).userInfo.setUserNick(nick);
					UserPreference.saveUserNick(nick, context);
					
				} catch (XMPPException e) {
					e.printStackTrace();
				}
                return Constants.CONNECTION_CONNECTED;
                
        	} else {
                connectionState = Constants.CONNECTION_FAILED;
                return Constants.CONNECTION_FAILED;
            }  
    	}
		
    }
}
