// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.

package com.gplocation.lbs.service;

import java.lang.reflect.InvocationTargetException;

import org.jivesoftware.smack.PacketListener;
import org.jivesoftware.smack.filter.AndFilter;
import org.jivesoftware.smack.filter.NotFilter;
import org.jivesoftware.smack.filter.PacketExtensionFilter;
import org.jivesoftware.smack.filter.PacketFilter;
import org.jivesoftware.smack.filter.PacketTypeFilter;
import org.jivesoftware.smack.packet.IQ;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Packet;
import org.jivesoftware.smack.packet.Presence;
import org.jivesoftware.smack.provider.ProviderManager;
import org.jivesoftware.smackx.ServiceDiscoveryManager;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.gplocation.lbs.application.MainApplication;
import com.gplocation.lbs.data.LBSUserExtend;
import com.gplocation.lbs.engine.GeneralXmppEngine;
import com.gplocation.lbs.engine.GroupXmppEngine;
import com.gplocation.lbs.engine.InternalXmppEngine;
import com.gplocation.lbs.engine.PubsubXmppEngine;
import com.gplocation.lbs.engine.RosterXmppEngine;
import com.gplocation.lbs.packetprovider.GroupSettingExtension;
import com.gplocation.lbs.packetprovider.LocationExtensionProvider;
import com.gplocation.lbs.packetprovider.NotifyExtensionProvider;
import com.gplocation.lbs.packetprovider.RegisterSmackProvider;
import com.gplocation.lbs.utils.Constants;

/**
 * @author jianbinxu
 * 
 */
public class XMPPRunnable implements Runnable {

    private static final String TAG = "XMPPRunnable";

    private SmackWrapper xmppClient;
    private Handler xmppClientHandler;
    public Handler receiveHandler;
    private XmppPacketParser packtParser;
    
    private Context context;
    private Thread receiveThread = null;
    public GeneralXmppEngine generalXmppEngine;
    public GroupXmppEngine groupXmppEngine;
    public PubsubXmppEngine pubsubXmppEngine;
    public RosterXmppEngine rosterXmppEngine;
    public InternalXmppEngine internalXmppEngine;
    
    public XMPPRunnable(Handler coreServiceHandler, Context context) {
        this.context = context;
    }

    
    /**
     * <p>Change user then reload data.</P>
     */
    public void reLoadData() {
    	android.os.Process.killProcess(android.os.Process.myPid());
//    	addXmppListener();
//    	addGroupInviteListener();
    	
//    	MainApplication mainApplication = ((MainApplication) ((LBSCoreService)context).getApplication());
//    	mainApplication.rosterManager.reLoad(xmppClient.xmppConn);
//    	mainApplication.groupManager.reLoad(xmppClient.xmppConn, context, mainApplication.serviceDiscoveryManager);
//    	mainApplication.groupSettingManager.init(xmppClient.xmppConn, context);
//    	mainApplication.lbsLocationManager.init(xmppClient.xmppConn, context);
//    	mainApplication.lbsPubsubManager.init(xmppClient.xmppConn, context);
    }
    
    
    /**
     * (non-Javadoc)
     * @see java.lang.Runnable#run()
     */
    @Override
    public void run() {
        Looper.prepare();
        
        receiveThread = new Thread(new ReceiveRunnable(context), "ReceiveRunnable");
        receiveThread.start();
        
        Log.d(TAG, "before wait");
        // wait for receive handler 
        try {
        	synchronized (this) {
        		this.wait();
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
        Log.d(TAG, "after wait");

        LBSUserExtend userInfo = ((MainApplication) ((LBSCoreService)context).getApplication()).userInfo;
        xmppClient = new SmackWrapper(userInfo.getUserName(), userInfo.getUserPassword(),
            userInfo.getDomain());
        xmppClient.setHostAndPort(userInfo.getHost(), userInfo.getPort());
        Log.d(TAG, userInfo.getDomain() + " " + userInfo.getHost() + " " + userInfo.getPort());
        
        
        RegisterSmackProvider.configure(ProviderManager.getInstance());
        int connectRes = xmppClient.loginXMPPServer(context);
        Log.d(TAG, "Connection result = " + String.valueOf(connectRes));
        
    	MainApplication mainApplication = ((MainApplication) ((LBSCoreService)context).getApplication());
        if (connectRes == Constants.CONNECTION_CONNECTED) {
        	initXmppHandler();
            addXmppListener();
            
        	mainApplication.serviceDiscoveryManager = new ServiceDiscoveryManager(xmppClient.xmppConn);
        	mainApplication.authorityManager.init(context);
        	mainApplication.rosterManager.init(xmppClient.xmppConn);
        	mainApplication.groupManager.init(xmppClient.xmppConn, context, mainApplication.serviceDiscoveryManager);
        	mainApplication.groupSettingManager.init(xmppClient.xmppConn, context);
        	mainApplication.lbsLocationManager.init(xmppClient.xmppConn, context);
        	mainApplication.lbsPubsubManager.init(xmppClient.xmppConn, context);
        }
	        
	//        if (connectRes != SmackWrapper.CONNECTION_CONNECTED) 
//        engine = new XmppEngine(coreServiceHandler, xmppClient, context);

        generalXmppEngine = new GeneralXmppEngine(context, xmppClient);
        groupXmppEngine = new GroupXmppEngine(context, xmppClient);
        pubsubXmppEngine = new PubsubXmppEngine(context, xmppClient);
        rosterXmppEngine = new RosterXmppEngine(context, xmppClient);
        internalXmppEngine = new InternalXmppEngine(context, xmppClient);
        
        generalXmppEngine.registerReceiveHandler(receiveHandler);
        groupXmppEngine.registerReceiveHandler(receiveHandler);
        pubsubXmppEngine.registerReceiveHandler(receiveHandler);
        rosterXmppEngine.registerReceiveHandler(receiveHandler);
        internalXmppEngine.registerReceiveHandler(receiveHandler);
              
        if (packtParser != null) {
        	packtParser.setGroupXmppEngine(groupXmppEngine);
        	packtParser.setRosterXmppEngine(rosterXmppEngine);
        }
        
        // set the client handler to receive the client request
//        coreServiceHandler.obtainMessage(Command.INTERNAL_SET_HANDLER_MSG, xmppClientHandler).sendToTarget();
        ((LBSCoreService) context).registerXmppHandler(xmppClientHandler);
                
    
//        synchronized (((LBSCoreService)context)) {
//       	 	((LBSCoreService)context).notify();
//		}
//        registerReceiveHandler(receiveHandler);
        
        Looper.loop();
    }

	private void initXmppHandler() {
		xmppClientHandler = new Handler() {
			@Override
			public void handleMessage(android.os.Message msg) {
				if (msg.getData() != null) {
					int type = msg.getData().getInt("type");
					try {
						switch (type) {
						case Constants.MESSAGE_GENERAL_TYPE:
							if (msg.what > -1 && msg.what < GeneralXmppEngine.generalXmppCommands.length) {
								generalXmppEngine.dynaCall(GeneralXmppEngine
										.generalXmppCommands[msg.what].getFun(), msg);
							} else {
								Log.d(TAG, "the message is out of GeneralXmppEngine handle region");
							}
							break;
						case Constants.MESSAGE_FRIEND_TYPE:
							if (msg.what > -1 && msg.what < RosterXmppEngine.rosterXmppCommands.length) {
								rosterXmppEngine.dynaCall(RosterXmppEngine.rosterXmppCommands[msg.what].getFun(), msg);
							} else {
								Log.d(TAG, "the message is out of RosterCoreEngine's handle region");
							}
							break;
						case Constants.MESSAGE_GROUP_TYPE:
							if (msg.what > -1 && msg.what < GroupXmppEngine.groupXmppCommands.length) {
								groupXmppEngine.dynaCall(GroupXmppEngine.groupXmppCommands[msg.what].getFun(), msg);
							} else {
								Log.d(TAG, "the message is out of GroupXmppEngine's handle region");
							}
							
							break;
						case Constants.MESSAGE_PUBSUB_TYPE:
						    if (msg.what > -1 && msg.what < PubsubXmppEngine.pubsubXmppCommands.length) {
                                pubsubXmppEngine.dynaCall(PubsubXmppEngine.pubsubXmppCommands[msg.what].getFun(), msg);
                            } else {
                                Log.d(TAG, "the message is out of PubsubXmppEngine's handle region");
                            }
							break;
							
						case Constants.MESSAGE_INTERAL_TYPE:
							// special handle destory.
							if (msg.what == Constants.MESSAGE_INTERAL_DESTORY) {
								Log.d(TAG, "MESSAGE_INTERAL_DESTORY");
								
								
								xmppClient.xmppConn.disconnect();
								this.getLooper().quit();
								receiveHandler.getLooper().quit();
							}

						    if (msg.what > -1 && msg.what < InternalXmppEngine.internalXmppCommands.length) {
                                internalXmppEngine.dynaCall(InternalXmppEngine
                                		.internalXmppCommands[msg.what].getFun(), msg);
                            } else {
                                Log.d(TAG, "the message is out of PubsubXmppEngine's handle region");
                            }
							
							break;
							
						default:
							super.handleMessage(msg);
							break;
						}
					} catch (NoSuchMethodException e) {
						e.printStackTrace();
					} catch (InvocationTargetException e) {
						e.printStackTrace();
					} catch (IllegalAccessException e) {
						e.printStackTrace();
					}
				}
				
				super.handleMessage(msg);
             }
         };

    }
    
    /**
     * @brief <p>add listener to receive xmpp packet from openfire</P>
     */
    private void addXmppListener() {
        //set the packet filter

    	// location
        PacketFilter subLocationFilter = new PacketExtensionFilter(LocationExtensionProvider.LocationExtension.ELEMENT,
            LocationExtensionProvider.LocationExtension.NAMESPACE);
        PacketFilter locationFilter = new AndFilter(subLocationFilter, new PacketTypeFilter(Message.class));
        
//        PacketFilter subThirdAppFilter = new PacketExtensionFilter(
//        ThirdAppsExtensionProvider.ThirdAppsExtension.ELEMENT,
//        		ThirdAppsExtensionProvider.ThirdAppsExtension.NAMESPACE);
//        PacketFilter thirdAppFilter = new AndFilter(subThirdAppFilter, new PacketTypeFilter(Message.class));
            
       
        // group
        PacketFilter groupSubFilter = new AndFilter(new PacketTypeFilter(Presence.class), 
        		new PacketExtensionFilter("x", "http://jabber.org/protocol/muc#user"));
        PacketFilter groupFilter = groupSubFilter;
        
        // roster
        PacketFilter notGroupFilter = new NotFilter(groupSubFilter);
        PacketFilter rosterChangeFilter = new AndFilter(new AndFilter(new XmppPacketParser.RosterChangeFilter(), 
        		new PacketTypeFilter(Presence.class)), notGroupFilter); // for bi-add/remove friend
        
        // group setting
        PacketFilter groupSettingFilter = new AndFilter(new PacketTypeFilter(IQ.class), 
        		new PacketExtensionFilter(GroupSettingExtension.ELEMENT, GroupSettingExtension.NAMESPACE));
//        PacketFilter groupSettingFilter = new AndFilter(
//        new FromMatchesFilter("setting.motolbs.com"), new PacketTypeFilter(IQ.class));
        
        // notify
        PacketFilter notifyFilter = new AndFilter(new PacketExtensionFilter(
        		NotifyExtensionProvider.NotifyExtension.ELEMENT, 
        		NotifyExtensionProvider.NotifyExtension.NAMESPACE), new PacketTypeFilter(Message.class));
        
        
        packtParser = new XmppPacketParser(receiveHandler, xmppClientHandler, context, xmppClient);
        
        PacketListener groupListener = new PacketListener() {
            @Override
            public void processPacket(Packet pk) {
                packtParser.groupParser(pk, context);
            }

        };

        //PacketFilter iqFilter = new IQTypeFilter(IQ.Type.GET);
        PacketListener locationListener = new PacketListener() {
            @Override
            public void processPacket(Packet pk) {
                packtParser.locationParser(pk);
            }
        };
        
        PacketListener rosterChangeListener = new PacketListener() {
            @Override
            public void processPacket(Packet pk) {
                packtParser.rosterChangeParser(pk);
            }
        };
        
        

        PacketListener groupSettingListener = new PacketListener() {
            @Override
            public void processPacket(Packet pk) {
                packtParser.groupSettingParser(pk);
            }
        };
        
        PacketListener notifyListener = new PacketListener() {
            @Override
            public void processPacket(Packet pk) {
                packtParser.notifyParser(pk);
            }
        };
        
        
        xmppClient.getXmppConn().addPacketListener(locationListener, locationFilter);
        xmppClient.getXmppConn().addPacketListener(rosterChangeListener, rosterChangeFilter);
        xmppClient.getXmppConn().addPacketListener(groupListener, groupFilter);
        xmppClient.getXmppConn().addPacketListener(groupSettingListener, groupSettingFilter);
        xmppClient.getXmppConn().addPacketListener(notifyListener, notifyFilter);
    }
       
    /**
     * <p>register receive handler</P>
     * @param handler
     */
    public void registerReceiveHandler(Handler handler) {
    	this.receiveHandler = handler;
//    	packtParser.registerReceiveHandler(handler);
    	
        MainApplication mainApplication = ((MainApplication) ((LBSCoreService) context).getApplication());
        mainApplication.rosterManager.registerReceiveHandler(handler);
        mainApplication.groupManager.registerReceiveHandler(handler);
        mainApplication.lbsPubsubManager.registerReceiveHandler(handler);
    }

}
