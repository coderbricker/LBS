// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.

package com.gplocation.lbs.service;

import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.util.Log;

import com.gplocation.lbs.application.MainApplication;
import com.gplocation.lbs.client.General;
import com.gplocation.lbs.data.LBSUserExtend;
import com.gplocation.lbs.manager.DBManager;
import com.gplocation.lbs.utils.Constants;
import com.gplocation.lbs.utils.LocationHelper;
import com.gplocation.lbs.utils.UserPreference;


/**
 * @brief them main service, main thread
 * @author jianbinxu
 */
public class LBSCoreService extends Service {
    static final String TAG = "LBSCoreService";

    private Handler coreServiceHandler = null;
    private Handler xmppHandler = null;
    private Thread xmppThread = null;
    public XMPPRunnable xmppRunnable;
    private LBSDetectThread detectThread = null;
    
    
    @Override
    public void onCreate() {
        super.onCreate();

        // insert default data for test
        Log.d(TAG, "onCreate");
        DBManager dbManager = new DBManager(this);
        dbManager.insertDefaultAuthorityDB();
        
        LocationHelper.addListener(LBSCoreService.this);
        getAnonymousId();
               
//        notifyManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        initCoreServiceHandler();
        
        //create xmpp thread
        xmppRunnable = new XMPPRunnable(coreServiceHandler, LBSCoreService.this);
        xmppThread = new Thread(xmppRunnable, "XMPPRunnable");
        xmppThread.start(); 
        
        detectThread = new LBSDetectThread(this);
        detectThread.start();
        
        Log.d(TAG, "onCreate end");
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "Start by Application");
        return super.onStartCommand(intent, flags, startId);
    }

  

    /**
     * @see android.app.Service#onBind(android.content.Intent)
     */
    @Override
    public IBinder onBind(Intent comIntent) {
        Log.d(TAG, "Start by Component");
        String serviceName = comIntent.getAction();
        
        while (xmppHandler == null) {
        	Log.d(TAG, "xmppHandler is not initilize finish");        	
        	try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
        }
                	
        if (serviceName.equals(Constants.GERNERAL_SERVICE_ACTION)) {
            LBSUserExtend userInfo = ((MainApplication) getApplication()).userInfo;
        	return new General(LBSCoreService.this, xmppHandler, userInfo);
        } 
        
        Log.d(TAG, "onBind return null");
        return null;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Log.d(TAG, "Component exit " + intent.getAction());
        detectThread.setRunning(false);
        
//        String serviceName = intent.getAction();
//        String appId = intent.getStringExtra("appId");
//        Log.d(TAG, "appId = " + appId);
//      
        
//        try {
        	//remove listener
//            xmppHandler.obtainMessage(Command.INTERNAL_DISCONNECT_MSG).sendToTarget();
//            receiveHandler.obtainMessage(Command.INTERNAL_DISCONNECT_MSG).sendToTarget();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }

        //        coreServiceHandler.getLooper().quit();

        return super.onUnbind(intent);
    }
    
    @Override
    public void onDestroy() {
        super.onDestroy();
        
        Log.d(TAG, "onDestroy");
        
        LocationHelper.removeListener(LBSCoreService.this);
        ((MainApplication) LBSCoreService.this.getApplication()).binderManager.removeAll();
        ((MainApplication) LBSCoreService.this.getApplication()).receiveManager.removeAllListener();
        
        try {
        	Message msg = new Message();
    		msg.what = Constants.MESSAGE_INTERAL_DESTORY;
    		Bundle bl = new Bundle();
    		bl.putInt("type", Constants.MESSAGE_INTERAL_TYPE);
    		msg.setData(bl);
    		
    		xmppHandler.sendMessage(msg);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * <p>get anonymous information from shared_preferce file or Http server</P>
     */
    private void getAnonymousId() {
    	LBSUserExtend userInfo = UserPreference.getUserInfo(this);
        if (UserPreference.NA.equals(userInfo.getUserName())) {
        	// just for test
        	Log.d(TAG, "get user");
        	LBSUserExtend anony =  new LBSUserExtend("test", "", "", "", "", "192.168.1.101", "1", "motolbs.com", 5222);
        	 UserPreference.saveUserInfo(anony, LBSCoreService.this);
        	 userInfo = UserPreference.getUserInfo(this);
        	 
//            String xmlStr = HttpHelper.httpGet(UserPreference.GETUSERINFOURL);
//            Log.d(TAG, xmlStr);
//            try {
//                UserPreference.saveUserInfo(LBSUserExtend.getLBSUser(xmlStr), LBSCoreService.this);
//                userInfo = UserPreference.getUserInfo(this);
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
        }
        
        Log.d(TAG, "user =" + userInfo.toString());
        ((MainApplication) getApplication()).userInfo = userInfo;
    }
    
    private void initCoreServiceHandler() {
    	coreServiceHandler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
            	int type = msg.getData().getInt("type");
    			
            	switch (type) {
            	case Constants.MESSAGE_GENERAL_TYPE:
            		break;
            	case Constants.MESSAGE_FRIEND_TYPE:
            		break;
            	case Constants.MESSAGE_GROUP_TYPE:
            		break;
            	case Constants.MESSAGE_PUBSUB_TYPE:
            		break;
            	default:
            		super.handleMessage(msg);
            		break;
            	}
            }
        };
    }
    
    public Handler getCoreServiceHandler() {
        return coreServiceHandler;
    }
    
    public void setXmppClientHandler(Handler xmppClientHandler1) {
        this.xmppHandler = xmppClientHandler1;
    }

    public Handler getXmppClientHandler() {
        return xmppHandler;
    }


	public Handler getXmppHandler() {
		return xmppHandler;
	}


	public void registerXmppHandler(Handler xmppHandler) {
		this.xmppHandler = xmppHandler;
	}
	
}
