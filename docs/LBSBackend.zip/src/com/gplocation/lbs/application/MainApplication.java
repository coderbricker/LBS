// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.application;

import org.jivesoftware.smackx.ServiceDiscoveryManager;

import android.app.Application;
import android.util.Log;

import com.gplocation.lbs.data.LBSUserExtend;
import com.gplocation.lbs.manager.AuthorityManager;
import com.gplocation.lbs.manager.BinderManager;
import com.gplocation.lbs.manager.GroupManager;
import com.gplocation.lbs.manager.GroupMemberManager;
import com.gplocation.lbs.manager.GroupSettingManager;
import com.gplocation.lbs.manager.LBSLocationManager;
import com.gplocation.lbs.manager.LBSPubsubManager;
import com.gplocation.lbs.manager.ReceiveManager;
import com.gplocation.lbs.manager.RosterManager;
import com.gplocation.lbs.utils.Constants;

/**
 * to store some data with replace the application 
 */
public class MainApplication extends Application {
    
    private static final String TAG = "MainApplication";
    
    public LBSUserExtend userInfo;
    public int xmppConnectionState = Constants.CONNECTION_UNKNOWN;
    
    public BinderManager binderManager = BinderManager.getInstance();
    public AuthorityManager authorityManager = AuthorityManager.getInstance();
    public ReceiveManager receiveManager = ReceiveManager.getInstance();
    public RosterManager rosterManager = RosterManager.getInstance();
    public GroupManager groupManager = GroupManager.getInstance();
    public GroupMemberManager groupMemberManager = GroupMemberManager.getInstance();
    public GroupSettingManager groupSettingManager = GroupSettingManager.getInstance();
    public LBSLocationManager lbsLocationManager = LBSLocationManager.getInstance();
    public LBSPubsubManager lbsPubsubManager = LBSPubsubManager.getInstance();
    
    public ServiceDiscoveryManager serviceDiscoveryManager;

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "backed MainApplication onCreate");
    }
}
