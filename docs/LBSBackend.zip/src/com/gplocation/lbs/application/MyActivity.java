package com.gplocation.lbs.application;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class MyActivity extends Activity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		TextView tv = new TextView(this);
		
		tv.setText("test");
		this.setContentView(tv);
		super.onCreate(savedInstanceState);
	};

}
