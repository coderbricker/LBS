// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.

package com.gplocation.lbs.test;

import java.util.Collection;
import java.util.Iterator;

import org.jivesoftware.smack.PacketListener;
import org.jivesoftware.smack.XMPPConnection;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.filter.PacketFilter;
import org.jivesoftware.smack.filter.PacketTypeFilter;
import org.jivesoftware.smack.packet.IQ;
import org.jivesoftware.smack.packet.Packet;
import org.jivesoftware.smack.packet.Presence;
import org.jivesoftware.smackx.Form;
import org.jivesoftware.smackx.FormField;
import org.jivesoftware.smackx.ReportedData;
import org.jivesoftware.smackx.ReportedData.Column;
import org.jivesoftware.smackx.ReportedData.Row;
import org.jivesoftware.smackx.ServiceDiscoveryManager;
import org.jivesoftware.smackx.muc.HostedRoom;
import org.jivesoftware.smackx.muc.MultiUserChat;
import org.jivesoftware.smackx.packet.DiscoverInfo;
import org.jivesoftware.smackx.search.UserSearchManager;

import android.content.Context;
import android.util.Log;

import com.gplocation.lbs.utils.LocationHelper;
import com.gplocation.lbs.utils.UserPreference;

/**
 * Briefly describe what this class does.
 */
public class TestTmp {

    private static final String TAG = "TestTmp";

    public static void testDistance() {
        double longti1 = 116.29768610001;
        double lati1 = 40.008469775516;
        double longti2 = 116.3336169719696;
        double lati2 = 39.93762073721488;

        double distance = LocationHelper.getDistance(lati1, longti1, lati2, longti2);
        Log.d(TAG, "the distance between yuanmingyuan and zoo is" + distance + " distance=" + String.valueOf(distance));
    }

    public static void addIqPacketListener(XMPPConnection conn1) {
        PacketListener iqListener = new PacketListener() {
            @Override
            public void processPacket(Packet pk) {
                Log.d(TAG, "presence Send:" + pk.toXML());
            }
        };

        PacketListener iqListenerReceive = new PacketListener() {
            @Override
            public void processPacket(Packet pk) {
                Log.d(TAG, "presence receive:" + pk.toXML());
            }
        };

        PacketFilter presenceFilter = new PacketTypeFilter(IQ.class);
        conn1.addPacketSendingListener(iqListener, presenceFilter);
        conn1.addPacketListener(iqListenerReceive, presenceFilter);
    }

    public static void addPresencePacketListener(XMPPConnection conn1) {
        PacketListener iqListener = new PacketListener() {
            @Override
            public void processPacket(Packet pk) {
                Presence presence = (Presence) pk;
                Log.d(TAG, "presence Send:" + presence.toXML());
                Log.d(TAG, "presence Send type:" + presence.getType());
            }
        };

        PacketListener iqListenerReceive = new PacketListener() {
            @Override
            public void processPacket(Packet pk) {
                Presence presence = (Presence) pk;
                Log.d(TAG, "presence receive:" + presence.toXML());
                Log.d(TAG, "presence receive type:" + presence.getType());
            }
        };

        PacketFilter presenceFilter = new PacketTypeFilter(Presence.class);
        conn1.addPacketSendingListener(iqListener, presenceFilter);
        conn1.addPacketListener(iqListenerReceive, presenceFilter);
    }

    public static void getAllConferenceRoom(XMPPConnection conn) throws XMPPException {

        Collection<HostedRoom> hostedRoom = MultiUserChat.getHostedRooms(conn, "conference.motolbs.com");
        ServiceDiscoveryManager serviceDiscoveryManager = new ServiceDiscoveryManager(conn);
        if (hostedRoom != null && !hostedRoom.isEmpty()) {
            Log.d(TAG, "getHostedRooms.size=" + hostedRoom.size());
            for (HostedRoom k : hostedRoom) {
                Log.d(TAG, "getHostedRooms jid=" + k.getJid());

                DiscoverInfo info = serviceDiscoveryManager.discoverInfo(k.getJid());

                Form form = Form.getFormFrom(info);
                if (form != null) {
                    FormField descField = form.getField("muc#roominfo_description");
                    String description = descField == null ? "" : descField.getValues().next();

                    FormField subjField = form.getField("muc#roominfo_subject");
                    String subject = subjField == null ? "" : subjField.getValues().next();

                    //                    FormField occCountField = form.getField("muc#roominfo_occupants");
 // int occupantsCount = occCountField == null ? -1 : Integer.parseInt(occCountField.getValues()
                    //                            .next());

                    Log.d(TAG, "info getDescription=" + description + "room=" + k.getJid() + "subject=" + subject
                        + "occupant=");
                }

            }
        } else {
            Log.d(TAG, "getHostedRooms=null or empty");
        }
    }

    public static void getJoinedConferenceRoom(XMPPConnection conn, String user) throws XMPPException {

        Collection<String> services = MultiUserChat.getServiceNames(conn);
        for (String service : services) {
            Log.d(TAG, "getServiceNames+service=" + service);
        }

        boolean supports = MultiUserChat.isServiceEnabled(conn, user);
        Log.d(TAG, "MultiUserChat.isServiceEnabled = " + supports);

        if (supports) {
            Iterator<String> rooms = MultiUserChat.getJoinedRooms(conn, user);
            while (rooms.hasNext()) {
                Log.d(TAG, "getJoinedConferenceRoom+rooms=" + rooms.next());
            }

            Log.d(TAG, "getJoinedConferenceRoom end");
        }
    }

    public static void createGroup(XMPPConnection conn1, Context context) {

        MultiUserChat muc = new MultiUserChat(conn1, "wlc02@conference.motolbs.com");
        try {
            Log.d(TAG, "before muc.join(testbot);+muc.room=" + muc.getRoom());

            //            muc.create("testbot");
            //            muc.sendConfigurationForm(new Form(Form.TYPE_SUBMIT));
            muc.join("testbot");

            Log.d(TAG, "Create chat room");
            //            Form form = muc.getConfigurationForm();
            //            Form ansnswerForm = form.createAnswerForm();
            //            for (@SuppressWarnings("rawtypes")
            //            Iterator fields = form.getFields(); fields.hasNext();) {
            //                FormField field = (FormField) fields.next();
            //                Log.d(TAG, "field=" + field.getVariable() + " value = " + field.getValues());
            //
            //                if (!FormField.TYPE_HIDDEN.equals(field.getType()) && field.getVariable() != null) {
            //                    // Sets the default value as the answer
            //                    ansnswerForm.setDefaultAnswer(field.getVariable());
            //                    if (field.getVariable().equals("muc#roomconfig_roomdesc")) {
            //                        ansnswerForm.setAnswer("muc#roomconfig_roomdesc", 
            //                "hello, this is carlswang create1");
            //                    }
            //                }
            //
            //            }
            //
            //            muc.sendConfigurationForm(ansnswerForm);

            Log.d(TAG, "after muc.join(testbot);");

            // add wlcscu as owner
            //            muc.grantMembership(PARAM.getUserInfo(context).getUserName()+"@motolbs.com");
            //            muc.grantMembership("wlcscu@motolbs.com");

            //            Collection<Affiliate> owners = muc.getOwners();
            //            if (owners != null) {
            //                Log.d(TAG, "getOwners size = " + owners.size());
            //            }
            //            
            //            Collection<Affiliate> members = muc.getMembers();
            //            if (members != null) {
            //                Log.d(TAG, "getMembers size = " + members.size());
            //            }

            getJoinedConferenceRoom(conn1, UserPreference.getUserInfo(context).getUserName() + "@motolbs.com");

        } catch (XMPPException e) {
            e.printStackTrace();
        }
    }

    public static void searchUser(XMPPConnection conn1, Context context) {
        UserSearchManager search = new UserSearchManager(conn1);
        Form form;
        try {
            //            form = search.getSearchForm("conference.motolbs.com");
            form = search.getSearchForm("search.motolbs.com");
            Form ansnswerForm = form.createAnswerForm();

            for (@SuppressWarnings("rawtypes")
            Iterator fields = form.getFields(); fields.hasNext();) {
                FormField field = (FormField) fields.next();
                Log.d(TAG, "field=" + field.getVariable() + " value = " + field.getValues());

                if (!FormField.TYPE_HIDDEN.equals(field.getType()) && field.getVariable() != null) {
                    // Sets the default value as the answer
                    ansnswerForm.setDefaultAnswer(field.getVariable());
                    //                    if (field.getVariable().equals("search")) {
                    //                        ansnswerForm.setAnswer("search", "wlcscu@motolbs.com");
                    //                    } else if (field.getVariable().equals("name_is_exact_match")) {
                    //                        ansnswerForm.setAnswer("name_is_exact_match", false);
                    //                    }
                }
            }

            ansnswerForm.setAnswer("Username", true);
            ansnswerForm.setAnswer("search", "wlc");

            ReportedData data = search.getSearchResults(ansnswerForm, "search.motolbs.com");
            if (data != null) {
                Iterator<ReportedData.Column> columns = data.getColumns();
                if (columns != null) {
                    while (columns.hasNext()) {
                        Column column = columns.next();
                        Log.d(TAG, "columns getLabel=" + column.getLabel() + " getType=" + column.getType()
                            + " getVariable = " + column.getVariable());
                    }
                }

                Iterator<ReportedData.Row> rows = data.getRows();

                if (rows != null) {
                    Log.d(TAG, "rows != null");
                    int count = 0;
                    while (rows.hasNext()) {
                        count++;
                        Row row = rows.next();
                        @SuppressWarnings("rawtypes")
                        Iterator it = row.getValues("jid");
                        while (it.hasNext()) {
                            Log.d(TAG, "row getValues=" + it.next().toString());
                        }
                    }

                    Log.d(TAG, "rows count = " + count);
                }
            }

        } catch (XMPPException e) {
            e.printStackTrace();
        }

        //        Form answerForm = searchForm.createAnswerForm();
        //        answerForm.setAnswer("last", "DeMoro");

    }

    public static void searchGroup(XMPPConnection conn1, Context context) {
        UserSearchManager search = new UserSearchManager(conn1);
        Form form;
        try {
            form = search.getSearchForm("conference.motolbs.com");
            Form ansnswerForm = form.createAnswerForm();

            for (@SuppressWarnings("rawtypes")
            Iterator fields = form.getFields(); fields.hasNext();) {
                FormField field = (FormField) fields.next();
                Log.d(TAG, "field=" + field.getVariable() + " value = " + field.getValues());
            }

            //            ansnswerForm.setAnswer("name", "wlc");
            //            ansnswerForm.setAnswer("name_is_exact_match", false);
            ansnswerForm.setAnswer("num_max_users", 30);

            ReportedData data = search.getSearchResults(ansnswerForm, "conference.motolbs.com");
            if (data != null) {
                Iterator<ReportedData.Column> columns = data.getColumns();
                if (columns != null) {
                    while (columns.hasNext()) {
                        Column column = columns.next();
                        Log.d(TAG, "columns getLabel=" + column.getLabel() + " getType=" + column.getType()
                            + " getVariable = " + column.getVariable());
                    }
                }

                Iterator<ReportedData.Row> rows = data.getRows();

                if (rows != null) {
                    Log.d(TAG, "rows != null");
                    int count = 0;
                    while (rows.hasNext()) {
                        count++;
                        Row row = rows.next();
                        @SuppressWarnings("rawtypes")
                        Iterator it = row.getValues("jid");
                        while (it.hasNext()) {
                            Log.d(TAG, "row getValues=" + it.next().toString());
                        }
                    }

                    Log.d(TAG, "rows count = " + count);
                }
            }
        } catch (XMPPException e) {
            e.printStackTrace();
        }

    }

}
