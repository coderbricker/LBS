// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.engine;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.gplocation.lbs.application.MainApplication;
import com.gplocation.lbs.manager.LBSPubsubManager;
import com.gplocation.lbs.service.LBSCoreService;
import com.gplocation.lbs.service.SmackWrapper;
import com.gplocation.lbs.utils.Constants;

/**
 * deal with all pubsub request
 * Briefly describe what this class does.
 */
public class PubsubXmppEngine {
	
	private static final String TAG = "PubsubXmppEngine";
	
	public static final int PUBLISH = 0;
	public static final int SUBSCRIBE = 1;
	public static final int FETCHTOPICS = 2;
	public static final int UNSUBSCRIBE = 3;
	private SmackWrapper xmppClient;
	private Context context;
	private LBSPubsubManager lbsPubsubManager;
	 /**
     * will handled in xmpp runnable
     */
    public static Command [] pubsubXmppCommands = {
    	new Command(PUBLISH, "publishItem"),
    	new Command(SUBSCRIBE, "subscribeItem"),
    	new Command(FETCHTOPICS, "fetchTopics"),
    	new Command(UNSUBSCRIBE, "unSubscribe")
    };
    

    private Handler receiveHandler;
//    private ReceiveManager receiveManager;
    
    public PubsubXmppEngine(Context context,SmackWrapper xmppClient) {
        this.context = context;
        this.xmppClient = xmppClient;
        lbsPubsubManager = ((MainApplication)(((LBSCoreService) this.context).getApplication())).lbsPubsubManager;
    }
    
    /**
	 * <p>dynamically decide which function should be called</P>
	 * @param funName method name
	 * @param message, method param is message
	 * @return
	 * @throws NoSuchMethodException
	 * @throws InvocationTargetException
	 * @throws IllegalAccessException
	 */
	public Object dynaCall(String funName, Message message) throws NoSuchMethodException,
			InvocationTargetException, IllegalAccessException {
		Method meth = this.getClass().getMethod(funName, message.getClass());
		return (meth.invoke(this, message));
	}
	
	    
    /**
     * <p>register the receive handler, if not call this function, the handler is null forever</P>
     * @param handler
     */
    public void registerReceiveHandler(Handler handler) {
    	this.receiveHandler = handler;
    }
    
    /**
     * subscribe a topic
     * Briefly describe what it does.
     * <p>If necessary, describe how it does and how to use it.</P>
     * @param msg
     * @return
     */
    public int subscribeItem(Message msg) {
        Log.d(TAG, "subscribeItem");
        if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
            returnToClientConnectedFailed();
            return -1;
        }
        
        Bundle bl = msg.getData();
        String topic = bl.getString("topic");
        String appId = bl.getString("appId");
        
        lbsPubsubManager.subscribeItem(topic,appId);
                        
        return 0;
    }
    
    /**
     * unSubscribe a topic
     * Briefly describe what it does.
     * <p>If necessary, describe how it does and how to use it.</P>
     * @param msg
     * @return
     */
    public int unSubscribe(Message msg) {
        Log.d(TAG, "unSubscribe");
        if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
            returnToClientConnectedFailed();
            return -1;
        }
        
        Bundle bl = msg.getData();
        String topic = bl.getString("topic");
        String appId = bl.getString("appId");
        
        lbsPubsubManager.unSubscribeItem(topic,appId);
        
        return 0;
    }
    
    /**
     * publish an item to topic
     * Briefly describe what it does.
     * <p>If necessary, describe how it does and how to use it.</P>
     * @param msg
     * @return
     */
    public int publishItem(Message msg) {
        Log.d(TAG, "publishItem");
        if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
            returnToClientConnectedFailed();
            return -1;
        }
        
        Bundle bl = msg.getData();
        String topic = bl.getString("topic");
        String appId = bl.getString("appId");
        String content = bl.getString("content");
        boolean withLocation = bl.getBoolean("withLocation");
        
        lbsPubsubManager.publishItem(topic,content, withLocation, appId);
        
        return 0;
    }
    public int fetchTopics(Message msg) {
        Log.d(TAG, "fetchTopics");
        if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
            returnToClientConnectedFailed();
            return -1;
        }
        
        Bundle bl = msg.getData();
        String parentPath = bl.getString("parentPath");
        String appId = bl.getString("appId");
        String patten = bl.getString("patten");
        
        lbsPubsubManager.fetchTopics(parentPath,patten, appId);
        
        return 0;
    }
    
    /**
     * tell client ConnectedFailed 
     * Briefly describe what it does.
     * <p>If necessary, describe how it does and how to use it.</P>
     */
    private void returnToClientConnectedFailed() {
        if (receiveHandler != null) {
            Message msg = new Message();
            msg.what = GeneralReceiveEngine.RETURN_CONNECTED_STATE_MSG;
            Bundle bl = new Bundle();
            bl.putInt("connect", xmppClient.connectionState);
            bl.putInt("type", Constants.MESSAGE_GENERAL_TYPE);
            msg.setData(bl);
            
            receiveHandler.sendMessage(msg);
        }
    }
}
