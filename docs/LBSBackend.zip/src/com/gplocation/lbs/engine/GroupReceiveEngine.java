// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.engine;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;

import android.content.Context;
import android.os.Bundle;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;

import com.gplocation.lbs.application.MainApplication;
import com.gplocation.lbs.client.group.IGroupListener;
import com.gplocation.lbs.data.GeoLocation;
import com.gplocation.lbs.data.GroupInfo;
import com.gplocation.lbs.data.Setting;
import com.gplocation.lbs.manager.DBManager;
import com.gplocation.lbs.manager.ReceiveManager;
import com.gplocation.lbs.service.LBSCoreService;
import com.gplocation.lbs.template.TemplateListeners.TemplateSubListener;

/**
 * handle Group received messages
 */
public class GroupReceiveEngine {

	private static final String TAG = "GroupReceiveEngine";
	
    public static final int RETURN_CREATE_MSG = 0;
    public static final int RETURN_REMOVE_MSG = 1;
    public static final int RETURN_EXIT_MSG = 2;
    public static final int RETURN_INVITE_USER_MSG = 3;
    public static final int RETURN_INVITE_REQUEST_MSG = 4;
    public static final int RETURN_JOIN_MSG = 5;
    public static final int RETURN_REMOVE_MEMBER_MSG = 6;
    public static final int RETURN_SET_MEMBER_OWNER_MSG = 7;
    public static final int RETURN_MEMBER_LIST_CHANGED_MSG = 8;
    public static final int RETURN_MESSAGE_MSG = 9;
    public static final int RETURN_NOTIFY_SETTING_ACTION_MSG = 10;
    public static final int RETURN_SETTING_CHANGED_MSG = 11;
    public static final int RETURN_SEARCH_MSG = 12;
    public static final int RETURN_LOCATION_MSG = 13;
    public static final int RETURN_STOP_SHARING_MSG = 14;
    public static final int RETURN_GROUP_LIST_CHANGED_MSG = 15;
    public static final int RETURN_SET_GROUP_INFORMATION_MSG = 16;
    
	 /**
     * will handled in xmpp runnable
     */
    public static Command [] groupReceiveCommands = {   
    	new Command(RETURN_CREATE_MSG, "receiveCreate"),   
    	new Command(RETURN_REMOVE_MSG, "receiveRemove"),   
    	new Command(RETURN_EXIT_MSG, "receiveExit"),  
    	new Command(RETURN_INVITE_USER_MSG, "receiveInviteUser"), 
    	new Command(RETURN_INVITE_REQUEST_MSG, "receiveInviteRequest"), 
    	new Command(RETURN_JOIN_MSG, "receiveJoin"),    
    	new Command(RETURN_REMOVE_MEMBER_MSG, "receiveRemoveMember"),  
    	new Command(RETURN_SET_MEMBER_OWNER_MSG, "receiveSetMemberOwner"), 
    	new Command(RETURN_MEMBER_LIST_CHANGED_MSG, "receiveMemberListChanged"),
    	new Command(RETURN_MESSAGE_MSG, "receiveMessage"),
    	new Command(RETURN_NOTIFY_SETTING_ACTION_MSG, "receiveNotifySettingAction"),
    	new Command(RETURN_SETTING_CHANGED_MSG, "receiveSettingChanged"),
    	new Command(RETURN_SEARCH_MSG, "receiveSearch"),
    	new Command(RETURN_LOCATION_MSG, "receiveLocation"),
    	new Command(RETURN_STOP_SHARING_MSG, "receiveStopShareLocation"),
    	new Command(RETURN_GROUP_LIST_CHANGED_MSG, "receiveGroupListChanged"),
    	new Command(RETURN_SET_GROUP_INFORMATION_MSG, "receiveSetGroupInformation"),
    	
    	
    };
    

    private Context context;
    private ReceiveManager receiveManager;
    
    public GroupReceiveEngine(Context context) {
    	this.context = context;

    	MainApplication mainApplication = ((MainApplication) ((LBSCoreService) context).getApplication());
		receiveManager = mainApplication.receiveManager;
    }
    
    /**
	 * <p>dynamically decide which function should be called</P>
	 * @param funName method name
	 * @param message, method param is message
	 * @return
	 * @throws NoSuchMethodException
	 * @throws InvocationTargetException
	 * @throws IllegalAccessException
	 */
	public Object dynaCall(String funName, Message message) throws NoSuchMethodException,
			InvocationTargetException, IllegalAccessException {
		Method meth = this.getClass().getMethod(funName, message.getClass());
		return (meth.invoke(this, message));
	}
	
	/**
	 * <p>Return to client the create a group result</P>
	 * @param msg
	 * @note a group is follow with appId, so no need to note other application a new group is created?
	 * @return
	 */
	public int receiveCreate(Message msg) {
		Log.d(TAG, "receiveCreate");
		Bundle bl = msg.getData();
			
		String groupId = bl.getString("groupId");
		String reason = bl.getString("reason");
		String appId = bl.getString("appId"); 
		String groupName = bl.getString("groupName");
		boolean res = bl.getBoolean("result");
		
		try {
			receiveManager.getGroupListeners().get(appId).receiveCreateGroupResult(groupName, groupId, res, reason);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		
		
		return 0;
	}

	/**
	 * <p>return to client remove a group</P>
	 * @param msg
	 * @return
	 */
	public int receiveRemove(Message msg) {
		Log.d(TAG, "receiveRemove");
		Bundle bl = msg.getData();
			
		String groupId = bl.getString("groupId");
		String appId = bl.getString("appId"); 
		boolean res = bl.getBoolean("result");
			
		try {
			receiveManager.getGroupListeners().get(appId).receiveRemoveGroupResult(groupId, res, "");
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		
		return 0;
	}
	
	/**
	 * <p>exit a group</P>
	 * @param msg
	 * @return
	 */
	public int receiveExit(Message msg) {
		Log.d(TAG, "receiveExit");
		Bundle bl = msg.getData();
			
		String groupId = bl.getString("groupId");
		String appId = bl.getString("appId"); 
		boolean res = bl.getBoolean("result");
			
		try {
			receiveManager.getGroupListeners().get(appId).receiveExitGroupResult(groupId, res, "");
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		
		return 0;
	}
	
	/**
	 * <p>invite somebody result, not the one's response</P>
	 * @param msg
	 * @return
	 */
	public int receiveInviteUser(Message msg) {
		Log.d(TAG, "receiveInviteUser");
		Bundle bl = msg.getData();
			
		String groupId = bl.getString("groupId");
		String appId = bl.getString("appId"); 
		String memberId = bl.getString("memberId");
		boolean res = bl.getBoolean("result");
			
		try {
			receiveManager.getGroupListeners().get(appId).receiveInviteUserResult(groupId, memberId, res, "");
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		
		return 0;
	}
	
	
	/**
	 * <p>in group manager's listener, somebody invite you to join into a group</P>
	 * @param msg
	 * @return
	 */
	public int receiveInviteRequest(Message msg) {
		Log.d(TAG, "receiveInviteRequest");
		Bundle bl = msg.getData();
			
		String groupId = bl.getString("groupId");
		String inviter = bl.getString("inviter");
		String reason = bl.getString("reason");
		
		HashMap<String, TemplateSubListener<IGroupListener>> listeners = 
				receiveManager.getGroupListeners().getListeners();
		for (TemplateSubListener<IGroupListener> listener : listeners.values()) {
			try {
				listener.listener.receiveInviteRequest(groupId, inviter, reason);
			} catch (RemoteException e) {
				e.printStackTrace();
			}
		}
		
//		receiveManager.getGeneralListeners().get
		return 0;
	}
	
	
	/**
	 * <p>join a group, and if success, notify group list changed</P>
	 * @param msg
	 * @return
	 */
	public int receiveJoin(Message msg) {
		Log.d(TAG, "receiveJoin");
		Bundle bl = msg.getData();
			
		String groupId = bl.getString("groupId");
		String appId = bl.getString("appId"); 
		boolean res = bl.getBoolean("result");
			
		try {
			receiveManager.getGroupListeners().get(appId).receiveJoinResult(groupId, res, "");
		} catch (RemoteException e) {
			e.printStackTrace();
		}		
			
		
		return 0;
	}
	
	/**
	 * <p>remove a member from group</P>
	 * @param msg
	 * @return
	 */
	public int receiveRemoveMember(Message msg) {
		Log.d(TAG, "receiveRemoveMember");
		Bundle bl = msg.getData();
			
		String groupId = bl.getString("groupId");
		String appId = bl.getString("appId"); 
		String memberId = bl.getString("memberId");
		boolean res = bl.getBoolean("result");
			
		try {
			receiveManager.getGroupListeners().get(appId).receiveRemoveMemberResult(groupId, memberId, res, "");
		} catch (RemoteException e) {
			e.printStackTrace();
		}	
		
				
		return 0;
	}
	
	
	/**
	 * <p>return to client set member as owner</P>
	 * @param msg
	 * @return
	 */
	public int receiveSetMemberOwner(Message msg) {
		Log.d(TAG, "receiveExit");
		Bundle bl = msg.getData();
			
		String groupId = bl.getString("groupId");
		String appId = bl.getString("appId"); 
		String memberId = bl.getString("memberId");
		boolean res = bl.getBoolean("result");
			
		try {
			receiveManager.getGroupListeners().get(appId).receiveSetMemberAsOwnerResult(groupId, memberId, res, "");
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		return 0;	
	}
	
		
	/**
	 * <p>receive member list changed</P>
	 * @param msg
	 * @return
	 */
	public int receiveMemberListChanged(Message msg) {
		Log.d(TAG, "receiveMemberListChanged");
		
		Bundle bl = msg.getData();
		String groupId = bl.getString("groupId");
		String memberId = bl.getString("memberId");
		String nick = bl.getString("nick");
//		String role = bl.getString("affiliation");
		String role = bl.getString("role");
		String action = bl.getString("action");
//		String appId = bl.getString("appId");
		
		Log.d(TAG, "groupId=" + groupId + " memberId=" + memberId + " nick=" + nick + " role=" + role);
		
		HashMap<String, TemplateSubListener<IGroupListener>> listeners = 
				receiveManager.getGroupListeners().getListeners();
		for (TemplateSubListener<IGroupListener> listener : listeners.values()) {
			try {
				Log.d(TAG, "receiveMemberListChanged listener=" + listener.listener);
				
				listener.listener.receiveMemberListChanged(groupId, memberId, nick, role, action);
			} catch (RemoteException e) {
				e.printStackTrace();
			}
		}
		
		MainApplication mainApplication = ((MainApplication) ((LBSCoreService) context).getApplication());
		if (action.equals("add")) {
			mainApplication.groupMemberManager.add(groupId, memberId, nick, role);
		} else if (action.equals("remove")) {
			mainApplication.groupMemberManager.removeMember(groupId, memberId);
		}
		
		return 0;
	}
	
	/**
	 * <p></P>
	 * @param msg
	 * @return
	 */
	public int receiveMessage(Message msg) {
		Log.d(TAG, "receiveMessage");
		
		Bundle bl = msg.getData();
		String groupId = bl.getString("groupId");
		String text = bl.getString("text");
		String appId = bl.getString("appId");
		GeoLocation location = bl.getParcelable("location");
		try {
			receiveManager.getGroupListeners().get(appId).receiveMessage(groupId, text, location);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		
		return 0;
	}
	
	/**
	 * <p></P>
	 * @param msg
	 * @return
	 */
	public int receiveNotifySettingAction(Message msg) {
		Log.d(TAG, "receiveNotifySettingAction");
		Bundle bl = msg.getData();
		String groupId = bl.getString("groupId");
		String appId = bl.getString("appId");
		String settingName = bl.getString("settingName");
		String action = bl.getString("action");
		try {
			receiveManager.getGroupListeners().get(appId)
						  .receiveNotifyExecuteGroupSetting(groupId, settingName, action);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		
		return 0;
	}
	
	/**
	 * <p>store the group setting, and return setting change to client</P>
	 * @param msg
	 * @return
	 */
	public int receiveSettingChanged(Message msg) {
		Log.d(TAG, "receiveSettingChanged");
		
        Bundle bl = msg.getData();
 		String groupId = bl.getString("groupId");
 		String settingName = bl.getString("settingName");
 	    String appId = bl.getString("appId"); // there is no appId when return now
 	    if (appId == null) {
 	    	appId = "1234567890";
 	    }
 		
 	    Log.d(TAG, "settingName=" + settingName);
		ArrayList<Setting> settings = bl.getParcelableArrayList("setting");
 	     
 	    DBManager dbManager = new DBManager(context);
 	    dbManager.storeGroupSetting(appId, groupId, settingName, settings);
 	    
 	   try {
			receiveManager.getGroupListeners().get(appId).receiveNotifyGroupSettingChanged(groupId, groupId);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
 	    
		return 0;
	}
	
	/**
	 * <p>return search result</P>
	 * @param msg
	 * @return
	 */
	public int receiveSearch(Message msg) {
		Log.d(TAG, "receiveSearch");
		Bundle b = msg.getData();
		String appId = b.getString("appId");
		String pattern = b.getString("pattern");
		int count = b.getInt("count");
		
		ArrayList<GroupInfo> groups = b.getParcelableArrayList("groupInfo");
		
		try {
			receiveManager.getGroupListeners().get(appId).receiveSearchedGroupsResult(pattern, groups, count);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		
		return 0;
	}
	
	
	
	/**
	 * <p>receive location from group member</P>
	 * @note fromId is the format of groupId/userNickName
	 * @param msg
	 * @return
	 */
	public int receiveLocation(Message msg) {
		Log.d(TAG, "receiveLocation");
		
		Bundle bl = msg.getData();
		String fromId = bl.getString("fromId");
		String appId = bl.getString("appId");
		GeoLocation location = bl.getParcelable("location");
		try {
			receiveManager.getGroupListeners().get(appId).receiveLocation(fromId, location);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		return 0;
	}
	
	
	/**
	 * <p>somebody stop share location in group</P>
	 * @note fromId is the format of groupId/userNickName
	 * @param msg
	 * @return
	 */
	public int receiveStopShareLocation(Message msg) {
		Log.d(TAG, "receiveStopShareLocation");
		
		Bundle bl = msg.getData();
		String fromId = bl.getString("fromId");
		String appId = bl.getString("appId");
		try {
			receiveManager.getGroupListeners().get(appId).receiveStopShareLocation(fromId);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		
		
		return 0;
	}
	
	
	
	/**
	 * <p>Group list changed, will change database</P>
	 * @param msg
	 * @return
	 */
	public int receiveGroupListChanged(Message msg) {
		Log.d(TAG, "receiveGroupListChanged");
		Bundle bl = msg.getData();
		String groupId = bl.getString("groupId");
		String action = bl.getString("action");
		
		HashMap<String, TemplateSubListener<IGroupListener>> listeners = 
				receiveManager.getGroupListeners().getListeners();
		for (TemplateSubListener<IGroupListener> listener : listeners.values()) {
			try {
				Log.d(TAG, "listener=" + listener.listener);
				
				listener.listener.receiveGroupListChanged(groupId, action);
			} catch (RemoteException e) {
				e.printStackTrace();
			}
		}
			
		if (action.equals("remove")) {
			MainApplication mainApplication = ((MainApplication) ((LBSCoreService) context).getApplication());
			mainApplication.groupMemberManager.removeGroup(groupId);

			// store into database
			DBManager dbManager = new DBManager(context);
			dbManager.deleteJoinedGroup(groupId);
			
			// setting name is groupId
			String appId = "1234567890";
			dbManager.deleteGroupSetting(appId, groupId, groupId);
		}
		
		
		return 0;
	}
	
	
	
	/**
	 * <p>Set group information return</P>
	 * @param msg
	 * @return
	 */
	public int receiveSetGroupInformation(Message msg) {
		Log.d(TAG, "receiveSetGroupInformation");
		Bundle bl = msg.getData();
		String groupId = bl.getString("groupId");
//		String appId = bl.getString("appId");
		GroupInfo groupInfo = bl.getParcelable("groupInfo");
		boolean res = bl.getBoolean("result");
			
		HashMap<String, TemplateSubListener<IGroupListener>> listeners = 
				receiveManager.getGroupListeners().getListeners();
		for (TemplateSubListener<IGroupListener> listener : listeners.values()) {
			try {
				Log.d(TAG, "listener=" + listener.listener);
				
				listener.listener.receiveChangeGroupInfoResult(groupId, groupInfo, res);
			} catch (RemoteException e) {
				e.printStackTrace();
			}
		}
		
		
		return 0;
	}
}
