// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.engine;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import android.content.Context;
import android.os.Bundle;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;

import com.gplocation.lbs.application.MainApplication;
import com.gplocation.lbs.client.friend.IFriendListener;
import com.gplocation.lbs.data.GeoLocation;
import com.gplocation.lbs.manager.ReceiveManager;
import com.gplocation.lbs.service.LBSCoreService;
import com.gplocation.lbs.template.TemplateListeners.TemplateSubListener;

/**
 * handle Roster received messages
 */
public class RosterReceiveEngine {

	private static final String TAG = "RosterReceiveEngine";
	
    public static final int RETURN_MESSAGE_MSG = 0;
    public static final int RETURN_BINARY_MESSAGE_MSG = 1;
    public static final int RETURN_ADD_BY_SOMEBODY_MSG = 2;
    public static final int RETURN_ADD_RESULT_MSG = 3;
    public static final int RETURN_REMOVE_BY_SOMEBODY_MSG = 4;
    public static final int RETURN_REMOVE_RESULT_MSG = 5;
    public static final int RETURN_PRESENCE_CHANGE_MSG = 6;
    public static final int RETURN_LOCATION_MSG = 7;
    public static final int RETURN_STOP_SHARE_LOCATION_MSG = 8;
    public static final int RETURN_REQUEST_LOCATION_MSG = 9;
    public static final int RETURN_FOLLOW_LOCATION_MSG = 10;
    public static final int RETURN_STOP_FOLLOW_LOCATION_MSG = 11;
    
	 /**
     * will handled in xmpp runnable
     */
    public static Command [] rosterReceiveCommands = {
    	new Command(RETURN_MESSAGE_MSG, "receiveMessage"),
    	new Command(RETURN_BINARY_MESSAGE_MSG, "receiveBinaryMessage"),
    	new Command(RETURN_ADD_BY_SOMEBODY_MSG, "receiveAddBySomebody"),
    	new Command(RETURN_ADD_RESULT_MSG, "receiveAddResult"),
    	new Command(RETURN_REMOVE_BY_SOMEBODY_MSG, "receiveRemoveBySomebody"),
    	new Command(RETURN_REMOVE_RESULT_MSG, "receiveRemoveResult"),
    	new Command(RETURN_PRESENCE_CHANGE_MSG, "receivePresenceChange"),
    	new Command(RETURN_LOCATION_MSG, "receiveLocation"),
    	new Command(RETURN_STOP_SHARE_LOCATION_MSG, "receiveStopShareLocation"),
    	new Command(RETURN_REQUEST_LOCATION_MSG, "receiveRequestLocation"),
    	new Command(RETURN_FOLLOW_LOCATION_MSG, "receiveFollowLocation"),
    	new Command(RETURN_STOP_FOLLOW_LOCATION_MSG, "receiveStopFollowLocation"),
    	
    };
    

    private ReceiveManager receiveManager;
    
    public RosterReceiveEngine(Context context) {

    	MainApplication mainApplication = ((MainApplication) ((LBSCoreService) context).getApplication());
		receiveManager = mainApplication.receiveManager;
    }
    
    /**
	 * <p>dynamically decide which function should be called</P>
	 * @param funName method name
	 * @param message, method param is message
	 * @return
	 * @throws NoSuchMethodException
	 * @throws InvocationTargetException
	 * @throws IllegalAccessException
	 */
	public Object dynaCall(String funName, Message message) throws NoSuchMethodException,
			InvocationTargetException, IllegalAccessException {
		Method meth = this.getClass().getMethod(funName, message.getClass());
		return (meth.invoke(this, message));
	}
	
		
		
	/**
	 * <p></P>
	 * @param msg
	 * @return
	 */
	public int receiveMessage(Message msg) {
		Log.d(TAG, "receiveMessage");
		
		Bundle bl = msg.getData();
		String friendId = bl.getString("friendId");
		String text = bl.getString("text");
		String appId = bl.getString("appId");
		GeoLocation location = bl.getParcelable("location");
		try {
			receiveManager.getFriendListeners().get(appId).receivedMessage(friendId, text, location);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		
		return 0;
	}
	
	/**
	 * <p></P>
	 * @param msg
	 * @return
	 */
	public int receiveBinaryMessage(Message msg) {
		
		return 0;
	}
	
	
	
	
	/**
	 * <p></P>
	 * @param msg
	 * @return
	 */
	public int receiveAddBySomebody(Message msg) {
		Log.d(TAG, "receiveAddBySomebody");
		
		Bundle bl = msg.getData();
        String friendId = bl.getString("friendId");   
        String nick = bl.getString("nick");
        String email = bl.getString("email");
        String phone = bl.getString("phone");
        
        try {
        	for (TemplateSubListener<IFriendListener> listenerTemplate 
        		 : receiveManager.getFriendListeners().getListeners().values()) {
        		listenerTemplate.listener.receivedAddByFriend(friendId, nick, "");
        		listenerTemplate.listener.receiveFriendListChanged(friendId, nick, email, phone, "add");
        	}
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		return 0;
	}
	
	
	/**
	 * <p></P>
	 * @param msg
	 * @return
	 */
	public int receiveAddResult(Message msg) {
		Log.d(TAG, "receiveAddResult");
		Bundle bl = (Bundle) msg.getData();
		
		String account = bl.getString("friendId");
		String nickName = bl.getString("nick");
		String appId = bl.getString("appId");
        String email = bl.getString("email");
        String phone = bl.getString("phone");
		boolean res = bl.getBoolean("result");
		
		try {
			receiveManager.getFriendListeners().get(appId).receivedResultOfAddFriend(account, nickName, res);
			if (res) {
				for (TemplateSubListener<IFriendListener> listenerTemplate 
					: receiveManager.getFriendListeners().getListeners().values()) {
	        		listenerTemplate.listener.receiveFriendListChanged(account, nickName, email, phone, "add");
	        	}
			}
		} catch (RemoteException e) {
			e.printStackTrace();
		}

		return 0;
	}
	
	
	public int receiveRemoveBySomebody(Message msg) {
		Log.d(TAG, "receiveRemoveBySomebody");
		 // send message to client
        Bundle bl = msg.getData();
        String friendId = bl.getString("friendId");  
        String nick = bl.getString("nick");
        
        try {
        	for (TemplateSubListener<IFriendListener> listenerTemplate 
        		: receiveManager.getFriendListeners().getListeners().values()) {
        		listenerTemplate.listener.receivedRemovedByFriend(friendId, nick);
        		listenerTemplate.listener.receiveFriendListChanged(friendId, nick, "", "", "remove");
        	}
		} catch (RemoteException e) {
			e.printStackTrace();
		}
        
		return 0;
	}
	
	public int receiveRemoveResult(Message msg) {
		Log.d(TAG, "receiveRemoveResult");
		Bundle bl = (Bundle) msg.getData();
		
		String account = bl.getString("friendId");
		String appId = bl.getString("appId");
		boolean res = bl.getBoolean("result");
		
		try {
			receiveManager.getFriendListeners().get(appId).receivedResultOfRemoveFriend(account, res);
			
			if (res) {
				for (TemplateSubListener<IFriendListener> listenerTemplate  
					: receiveManager.getFriendListeners().getListeners().values()) {
	        		listenerTemplate.listener.receiveFriendListChanged(account, null, "", "", "remove");
	        	}
			}
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		return 0;
	}
	
	
	public int receivePresenceChange(Message msg) {
		Log.d(TAG, "receivePresenceChange");

		Bundle bl = (Bundle) msg.getData();
		String friendId = bl.getString("friendId");
		String presence = bl.getString("presence");
		
        for (TemplateSubListener<IFriendListener> listenerTemplate  
        	: receiveManager.getFriendListeners().getListeners().values()) {
    		try {
				listenerTemplate.listener.receivedPresenceChanged(friendId, presence);
			} catch (RemoteException e) {
				e.printStackTrace();
			}
    	}
        
		return 0;
	}
	
	
	
	/**
	 * <p></P>
	 * @param msg
	 * @return
	 */
	public int receiveLocation(Message msg) {
		Log.d(TAG, "receiveLocation");
		Bundle bl = (Bundle) msg.getData();
		String friendId = bl.getString("friendId");
		String appId = bl.getString("appId");
		GeoLocation location = bl.getParcelable("location");
		
		try {
			receiveManager.getFriendListeners().get(appId).receivedLocation(friendId, location);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		
		return 0;
	}
	
	
	public int receiveStopShareLocation(Message msg) {
		Log.d(TAG, "receiveStopShareLocation");
		Bundle bl = (Bundle) msg.getData();
		String friendId = bl.getString("friendId");
		String appId = bl.getString("appId");
		
		try {
			receiveManager.getFriendListeners().get(appId).receivedStopSharingLoaction(friendId);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		
		return 0;
	}
	

	public int receiveStopFollowLocation(Message msg) {
		Log.d(TAG, "receiveStopFollowLocation");
		Bundle bl = (Bundle) msg.getData();
		String friendId = bl.getString("friendId");
		String appId = bl.getString("appId");
		
		try {
			receiveManager.getFriendListeners().get(appId).receivedStopFollowLoaction(friendId);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		
		return 0;
	}
	
	
	public int receiveRequestLocation(Message msg) {
		Log.d(TAG, "receiveRequestLocation");
		Bundle bl = (Bundle) msg.getData();
		String friendId = bl.getString("friendId");
		String appId = bl.getString("appId");
		
		try {
			receiveManager.getFriendListeners().get(appId).receivedRequestLocation(friendId, "");
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		return 0;
	}
	
	public int receiveFollowLocation(Message msg) {
		Log.d(TAG, "receiveFollowLocation");
		Bundle bl = (Bundle) msg.getData();
		String friendId = bl.getString("friendId");
		String appId = bl.getString("appId");
		
		try {
			receiveManager.getFriendListeners().get(appId).receivedFollowLocation(friendId, "");
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		return 0;
	}
	
	
}
