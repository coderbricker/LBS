// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.engine;

/**
 * all the messages transfer between client and service.
 */
public final class Command {
    private int cmdId;
	private String fun;
	
	public Command(int cmdId, String fun) {
		this.setCmdId(cmdId);
		this.setFun(fun);
	}

	public int getCmdId() {
		return cmdId;
	}

	public void setCmdId(int cmdId) {
		this.cmdId = cmdId;
	}

	public String getFun() {
		return fun;
	}

	public void setFun(String fun) {
		this.fun = fun;
	}
	
}
