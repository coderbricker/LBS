// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.engine;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;

import android.content.Context;
import android.os.Bundle;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;

import com.gplocation.lbs.application.MainApplication;
import com.gplocation.lbs.data.ThirdApp;
import com.gplocation.lbs.manager.ReceiveManager;
import com.gplocation.lbs.service.LBSCoreService;

/**
 * handle General received messages
 */
public class InternalReceiveEngine {

	private static final String TAG = "InternalReceiveEngine";
	

    public static final int RETURN_SET_USER_MAP_MSG = 0;
    public static final int RETURN_GET_USER_MAP_MSG = 1;
    public static final int RETURN_GET_THIRD_APPS_MSG = 2;
    public static final int RETURN_LOGIN_MSG = 3;
    
	 /**
     * will handled in xmpp runnable
     */
    public static final Command [] InternalReceiveCommands = {
    	new Command(RETURN_SET_USER_MAP_MSG, "receiveSetUserMap"),
    	new Command(RETURN_GET_USER_MAP_MSG, "receiveGetUserMap"),
    	new Command(RETURN_GET_THIRD_APPS_MSG, "receiveThirdApps"),
    	new Command(RETURN_LOGIN_MSG, "receiveLoginResult"),
    	
    };
    

    @SuppressWarnings("unused")
	private Context context;
    private ReceiveManager receiveManager;
    
    public InternalReceiveEngine(Context context) {
    	this.context = context;

    	MainApplication mainApplication = ((MainApplication) ((LBSCoreService) context).getApplication());
		receiveManager = mainApplication.receiveManager;
    }
    
    /**
	 * <p>dynamically decide which function should be called</P>
	 * @param funName method name
	 * @param message, method param is message
	 * @return
	 * @throws NoSuchMethodException
	 * @throws InvocationTargetException
	 * @throws IllegalAccessException
	 */
	public Object dynaCall(String funName, Message message) throws NoSuchMethodException,
			InvocationTargetException, IllegalAccessException {
		Method meth = this.getClass().getMethod(funName, message.getClass());
		return (meth.invoke(this, message));
	}
	
	
	public void receiveSetUserMap(Message msg) {
		Log.d(TAG, "receiveSetUserMap");
		
		Bundle bl = msg.getData();
//		String userId = bl.getString("userId");
		String email = bl.getString("email");
		String appId = bl.getString("appId");
		boolean result = bl.getBoolean("result");
		
		try {
			receiveManager.getInternalListeners().get(appId).receiveResultSetUserMap(email, result);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		
	}
	
	
	public void receiveGetUserMap(Message msg) {
		Log.d(TAG, "receiveGetUserMap");
		
		Bundle bl = msg.getData();
		String userId = bl.getString("userId");
		String nick = bl.getString("nick");
		String phone = bl.getString("phone");
		String email = bl.getString("email");
		String appId = bl.getString("appId");
		boolean result = bl.getBoolean("result");
		
		try {
			receiveManager.getInternalListeners().get(appId).receiveGetUserMap(email, phone, userId, nick, result);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		
	}
	
	
	public void receiveThirdApps(Message msg) {
		Log.d(TAG, "receiveThirdApps");
		
		Bundle bl = msg.getData();
		
		String appId = bl.getString("appId");
		String key = bl.getString("key");
		boolean result = bl.getBoolean("result");
		ArrayList<ThirdApp> apps = bl.getParcelableArrayList("apps");
		Log.d(TAG, "apps=" + apps);
		int size = 0;
		if (apps != null) {
			size = apps.size();
		}
		
		
		if (result) {
			try {
				receiveManager.getInternalListeners().get(appId).receiveThirdApps(key, apps, size);
			} catch (RemoteException e) {
				e.printStackTrace();
			}
		}
	}
	
	
	public void receiveLoginResult(Message msg) {
		Log.d(TAG, "receiveLoginResult");
		
		Bundle bl = msg.getData();
		String appId = bl.getString("appId");
		String email = bl.getString("email");
		String userId = bl.getString("userId");
		String nick = bl.getString("nick");
		String phone = bl.getString("phone");
		boolean result = bl.getBoolean("result");
		
		Log.d(TAG, "receiveLoginResult + result=" + result);
		
		if (result) {
			try {
				receiveManager.getInternalListeners().get(appId).receiveLoginResult(email, userId, nick, phone, result);
			} catch (RemoteException e) {
				e.printStackTrace();
			}
		}
	}
		
}
