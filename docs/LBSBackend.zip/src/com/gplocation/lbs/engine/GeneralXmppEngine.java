// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.engine;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.jivesoftware.smack.PacketListener;
import org.jivesoftware.smack.filter.PacketFilter;
import org.jivesoftware.smack.filter.PacketIDFilter;
import org.jivesoftware.smack.packet.IQ;
import org.jivesoftware.smack.packet.IQ.Type;
import org.jivesoftware.smack.packet.Packet;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.gplocation.lbs.manager.DBManager;
import com.gplocation.lbs.packetprovider.AuthenticateIQ;
import com.gplocation.lbs.service.SmackWrapper;
import com.gplocation.lbs.utils.Constants;

public class GeneralXmppEngine {
	
	private static final String TAG = "GeneralXmppEngine";
	
	private Handler receiveHandler;
	private SmackWrapper xmppClient = null;
	private Context context;
	

	public static final int AUTHENTICAT_MSG = 0;
	
	 /**
     * will handled in xmpp runnable
     */
    public static Command [] generalXmppCommands = {
    	new Command(AUTHENTICAT_MSG, "authenticate"),
    };
    

//    private ReceiveManager receiveManager;
    
    public GeneralXmppEngine(Context context, SmackWrapper xmppClient) {
//		receiveManager = ((MainApplication)((LBSCoreService) context).getApplication()).receiveManager;
		this.xmppClient = xmppClient;
		this.context = context;
    }
    
    /**
	 * <p>dynamically decide which function should be called</P>
	 * @param funName method name
	 * @param message, method param is message
	 * @return
	 * @throws NoSuchMethodException
	 * @throws InvocationTargetException
	 * @throws IllegalAccessException
	 */
	public Object dynaCall(String funName, Message message) throws NoSuchMethodException,
			InvocationTargetException, IllegalAccessException {
		Method meth = this.getClass().getMethod(funName, message.getClass());
		return (meth.invoke(this, message));
	}
  
	
	public class AuthenticatePacketListener implements PacketListener {
		private String appId;
		private String vendor;
		private String appName;
		@SuppressWarnings("unused")
		private String certification;
		
		public AuthenticatePacketListener(String appId, String appName, String vendor, String certification) {
			this.appId = appId;
			this.appName = appName;
			this.vendor = vendor;
			this.certification = certification;
		}

		@Override
		public void processPacket(Packet pk) {
			Log.d(TAG, "AuthenticatePacketListener received:" + pk.toXML());	
			
			boolean res = false;
			if (((IQ) pk).getType().equals(IQ.Type.ERROR)) {
				res = false;
								
			} else if (((IQ) pk).getType().equals(IQ.Type.RESULT)) {
				res = true;
				
				AuthenticateIQ iqPakdet = (AuthenticateIQ) pk;
				// write data into database
				DBManager db = new DBManager(context);
				db.storeAuthorityDB(appId, appName, vendor, iqPakdet.getPrivilege(), iqPakdet.getRestriction(),
						"true", "", "");				
			}
			
			// return to client message
			android.os.Message msg = new android.os.Message();
			msg.what = GeneralReceiveEngine.RETURN_AUTHENTICATE_RESULT_MSG;
			Bundle b = new Bundle();
			b.putInt("type", Constants.MESSAGE_GENERAL_TYPE);
			b.putString("appId", appId);
			b.putBoolean("result", res);
			b.putString("reason", "");
			msg.setData(b);
			
			receiveHandler.sendMessage(msg);			
			
			xmppClient.getXmppConn().removePacketListener(this);
		}		
	}
	
	
	/**
	 * <p>Send xmpp packet to smack</P>
	 * @todo send?
	 * @param msg
	 * @return
	 */
	public int authenticate(Message msg) {
		Log.d(TAG, "authenticate");
		if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
			returnToClientConnectedFailed();
			return -1;
		}
		
		Bundle bl = msg.getData();
		String appName = bl.getString("appName");
		String appId = bl.getString("appId");
		String vendor = bl.getString("vendor");
		String certification = bl.getString("certificate");
		
		AuthenticateIQ setReq = new AuthenticateIQ();
		setReq.setAppId(appId);
		setReq.setAppName(appName);
		setReq.setCertification(certification);
		setReq.setVendor(vendor);
		
		
		setReq.setType(Type.GET);
		setReq.setTo("portal.motolbs.com");
		
		String packageId = setReq.getPacketID();
		PacketFilter idFilter = new PacketIDFilter(packageId);

		xmppClient.xmppConn.addPacketListener(new AuthenticatePacketListener
				(appId, appName, vendor, certification), idFilter);

		Log.d(TAG, "authenticate:" + setReq.toXML());
		xmppClient.xmppConn.sendPacket(setReq);
		
		return 0;
	}

	
	private void returnToClientConnectedFailed() {
		if (receiveHandler != null) {
			Message msg = new Message();
			msg.what = GeneralReceiveEngine.RETURN_CONNECTED_STATE_MSG;
			Bundle bl = new Bundle();
			bl.putInt("connect", xmppClient.connectionState);
			bl.putInt("type", Constants.MESSAGE_GENERAL_TYPE);
			msg.setData(bl);
			
			receiveHandler.sendMessage(msg);
		}
	}
	    
    /**
     * <p>register the receive handler, if not call this function, the handler is null forever</P>
     * @param handler
     */
    public void registerReceiveHandler(Handler handler) {
    	this.receiveHandler = handler;
    }
}
