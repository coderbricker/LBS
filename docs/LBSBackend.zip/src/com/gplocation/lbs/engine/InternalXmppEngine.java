// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.engine;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.jivesoftware.smack.PacketListener;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.filter.PacketFilter;
import org.jivesoftware.smack.filter.PacketIDFilter;
import org.jivesoftware.smack.packet.IQ;
import org.jivesoftware.smack.packet.IQ.Type;
import org.jivesoftware.smack.packet.Packet;
import org.jivesoftware.smackx.packet.VCard;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.gplocation.lbs.application.MainApplication;
import com.gplocation.lbs.data.LBSUserExtend;
import com.gplocation.lbs.packetprovider.ThirdAppsExtensionProvider.ThirdAppsExtension;
import com.gplocation.lbs.packetprovider.UserRegisterIQ;
import com.gplocation.lbs.service.LBSCoreService;
import com.gplocation.lbs.service.SmackWrapper;
import com.gplocation.lbs.utils.Constants;
import com.gplocation.lbs.utils.UserPreference;

public class InternalXmppEngine {
	
	private static final String TAG = "InternalXmppEngine";
	
	private Handler receiveHandler;
	private SmackWrapper xmppClient = null;
	private LBSUserExtend user;
	private Context context;
	
	public static final int MESSAGE_INTERAL_DESTORY = 0;
	public static final int SET_USER_MAP_MSG = 1;
	public static final int GET_USER_MAP_MSG = 2;
	public static final int SEARCH_THIRD_APP_MSG = 3;
	public static final int NEW_USER_LOGIN_MSG = 4;
	public static final int SET_SHARE_LOCATION_TIME = 5;
	
	
	 /**
     * will handled in xmpp runnable
     */
    public static Command [] internalXmppCommands = {
    	new Command(MESSAGE_INTERAL_DESTORY, "internalDestory"),
    	new Command(SET_USER_MAP_MSG, "setUserMap"),
    	new Command(GET_USER_MAP_MSG, "getUserMap"),
    	new Command(SEARCH_THIRD_APP_MSG, "searchThirdApps"),
    	new Command(NEW_USER_LOGIN_MSG, "newUserLogin"),
    	new Command(SET_SHARE_LOCATION_TIME, "setShareLocationTime"),
    };
    

//    private ReceiveManager receiveManager;
    
    public InternalXmppEngine(Context context, SmackWrapper xmppClient) {
    	this.context = context;
//		receiveManager = ((MainApplication)((LBSCoreService) context).getApplication()).receiveManager;
    	user = ((MainApplication) ((LBSCoreService) context).getApplication()).userInfo;
		this.xmppClient = xmppClient;
    }
    
    /**
	 * <p>dynamically decide which function should be called</P>
	 * @param funName method name
	 * @param message, method param is message
	 * @return
	 * @throws NoSuchMethodException
	 * @throws InvocationTargetException
	 * @throws IllegalAccessException
	 */
	public Object dynaCall(String funName, Message message) throws NoSuchMethodException,
			InvocationTargetException, IllegalAccessException {
		Method meth = this.getClass().getMethod(funName, message.getClass());
		return (meth.invoke(this, message));
	}
  
	
	public int internalDestory(Message msg) {
		return 0;
	}
	
	
	/**
     * listen group setting package according to pakcetID
     */
    private class UserRegisterListener implements PacketListener {
    	private String userId;
    	private String email;
    	private String appId;
    	private String phone;
    	private String nick;
    	private String pass;

		public UserRegisterListener(String appId, String userId, String nick, 
				String phone, String email, String pass) {
			this.appId = appId;
			this.userId = userId;
			this.nick = nick;
			this.pass = pass;
			this.phone = phone;
			this.email = email;
		}

		@Override
		public void processPacket(Packet pk) {
			Log.d(TAG, pk.toXML());
			boolean res = false;
			if (((IQ) pk).getType().equals(IQ.Type.RESULT)) {
				// send notify packet to all members in group
//				String appId = (String) pk.getProperty("appId"); //now result message has not property.
				res = true;		
				
				// change password
				try {
					xmppClient.xmppConn.getAccountManager().changePassword(pass);
					UserPreference.saveUserPassword(pass, context);
				} catch (XMPPException e) {
					e.printStackTrace();
				}
				
				Log.d(TAG, "change password to:" + pass);
				
				VCard vCard = new VCard();
				try {
					vCard.load(xmppClient.xmppConn);
					vCard.setNickName(nick);
					vCard.setPhoneHome(Constants.DEFAULT_PHONE_TYPE, phone);
					vCard.setEmailHome(email);
					vCard.save(xmppClient.xmppConn);
					
					((MainApplication) ((LBSCoreService) context).getApplication()).userInfo.setUserNick(nick);
					
					UserPreference.saveUserNick(nick, context);
					UserPreference.savevCardEmail(email, context);
					UserPreference.savevCardPhone(phone, context);
					
				} catch (XMPPException e) {
					e.printStackTrace();
				}
				
            } else if (((IQ) pk).getType().equals(IQ.Type.ERROR)) {
            	
            }
//			
			Message msg = new Message();
			msg.what = InternalReceiveEngine.RETURN_SET_USER_MAP_MSG;
			Bundle bl = new Bundle();
			bl.putInt("type", Constants.MESSAGE_INTERAL_TYPE);
			bl.putString("appId", appId);
			bl.putString("userId", userId);
			bl.putString("email", email);
			bl.putBoolean("result", res);
			msg.setData(bl);
			
			receiveHandler.sendMessage(msg);
			
			xmppClient.xmppConn.removePacketListener(this);
		}
	}
    
    
    /**
     * listen group setting package according to pakcetID
     */
    private class GetUserRegisterListener implements PacketListener {
    	private String email;
    	private String appId;
    	private String action;
    	private String password;
    	
		public GetUserRegisterListener(String appId, String email, String action, String pass) {
			this.email = email;
			this.appId = appId;
			this.action = action;
			this.password = pass;
		}
		

		@Override
		public void processPacket(Packet pk) {
			Log.d(TAG, pk.toXML());
			String userId = "";
			String nick = "";
			String phone = "";
			boolean res = false;
			if (((IQ) pk).getType().equals(IQ.Type.RESULT)) {
				// send notify packet to all members in group
//				String appId = (String) pk.getProperty("appId"); //now result message has not property.
				UserRegisterIQ userRegisterIQ = (UserRegisterIQ) pk;
				userId = userRegisterIQ.getUserId();
				phone = userRegisterIQ.getPhone();
				res = true;
			
            } 
//			else if (((IQ) pk).getType().equals(IQ.Type.ERROR)) {
//            	;
//            }
//			
			if (res) {
				VCard vCard = new VCard();
				try {
					vCard.load(xmppClient.xmppConn, userId);
					nick = vCard.getNickName();
					if (nick == null) {
						nick = userId.split("@")[0];
					}
				} catch (XMPPException e) {
					e.printStackTrace();
				}
				
			}
			

			Log.d(TAG, "GetUserRegisterListener, userinformation=" + userId + nick + action);
			
			if (action.equals(Constants.USER_REGISTER_ACTION)) {
				Message msg = new Message();
				msg.what = InternalReceiveEngine.RETURN_GET_USER_MAP_MSG;
				Bundle bl = new Bundle();
				bl.putInt("type", Constants.MESSAGE_INTERAL_TYPE);
				bl.putString("appId", appId);
				bl.putString("userId", userId);
				bl.putString("nick", nick);
				bl.putString("email", email);
				bl.putString("phone", phone);
				bl.putBoolean("result", res);
				msg.setData(bl);
				
				receiveHandler.sendMessage(msg);
			} else if (action.equals(Constants.USER_LOGIN_ACTION)) {
				if (res) {
					String userName = userId.split("@")[0];
					// when user is not the same login user then relogin.
					if (! xmppClient.xmppConn.getUser().split("@")[0].equals(userName)) {
						xmppClient.reLoginXMPPServer(context, userName, password);
						((LBSCoreService) (context)).xmppRunnable.reLoadData();
					}
					if (xmppClient.xmppConn.isAuthenticated()) {
						res = true;
					} else {
						res = false;
					}
					
					Log.d(TAG, "GetUserRegisterListener, userinformation=" + userId + nick);
					
					Message msg = new Message();
					msg.what = InternalReceiveEngine.RETURN_LOGIN_MSG;
					Bundle bl = new Bundle();
					bl.putInt("type", Constants.MESSAGE_INTERAL_TYPE);
					bl.putString("appId", appId);
					bl.putString("userId", userId);
					bl.putString("nick", nick);
					bl.putString("phone", phone);
					bl.putString("email", email);
					bl.putBoolean("result", res);
					msg.setData(bl);
					
					receiveHandler.sendMessage(msg);
				}
			}
			
			xmppClient.xmppConn.removePacketListener(this);
		}
	}
    
    
	
	/**
	 * <p>set user map</P>
	 * @param msg
	 * @return
	 */
	public int setUserMap(Message msg) {
		Log.d(TAG, "setUserMap");
		if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
			returnToClientConnectedFailed();
			return -1;
		}
				
		Bundle bl = msg.getData();
		String appId = bl.getString("appId");
		String email = bl.getString("email");

		String userNick = bl.getString("userNick");
		String passWord = bl.getString("password");
		String phone = bl.getString("phone");
		Log.d(TAG, "phone =" + phone);
		
		
		UserRegisterIQ userRegisterIQ = new UserRegisterIQ();
		userRegisterIQ.setUserId(user.getUserName() + Constants.DEFAULT_USER_DOMAIN);
		userRegisterIQ.setEmail(email);
		userRegisterIQ.setPhone(phone);
		
		userRegisterIQ.setTo("usermap.motolbs.com");
		userRegisterIQ.setType(IQ.Type.SET);
		
		Log.d(TAG, userRegisterIQ.toXML());
		
		String packageId = userRegisterIQ.getPacketID();
		PacketFilter idFilter = new PacketIDFilter(packageId);

		xmppClient.xmppConn.addPacketListener(new UserRegisterListener(
				appId, user.getUserId(), userNick, phone, email, passWord),
				idFilter);

		
		xmppClient.xmppConn.sendPacket(userRegisterIQ);		
		return 0;
	}
	
	public int getUserMap(Message msg) {
		Log.d(TAG, "getUserMap");
		if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
			returnToClientConnectedFailed();
			return -1;
		}
				
		Bundle bl = msg.getData();
		String appId = bl.getString("appId");
		String email = bl.getString("email");
		
		UserRegisterIQ userRegisterIQ = new UserRegisterIQ();
		userRegisterIQ.setEmail(email);
		
		userRegisterIQ.setTo("usermap.motolbs.com");
		userRegisterIQ.setType(IQ.Type.GET);
		
		Log.d(TAG, userRegisterIQ.toXML());
		String packageId = userRegisterIQ.getPacketID();
		PacketFilter idFilter = new PacketIDFilter(packageId);

		xmppClient.xmppConn.addPacketListener(new GetUserRegisterListener(appId, email, 
				Constants.USER_REGISTER_ACTION, ""), idFilter);

		xmppClient.xmppConn.sendPacket(userRegisterIQ);		
		return 0;
	}
	
	public class ThirdAppListener implements PacketListener {
		private String key;
		@SuppressWarnings("unused")
		private int count;
		private String appId;
		
		public ThirdAppListener(String key, int count, String appId) {
			this.key = key;
			this.count = count;
			this.appId = appId;
		}

		@Override
		public void processPacket(Packet pk) {
			Log.d(TAG, "ThirdAppListener received:" + pk.toXML());	
			
			boolean res = false;
			ThirdAppsExtension iqPakect = null;
			if (((IQ) pk).getType().equals(IQ.Type.ERROR)) {
				res = false;
								
			} else if (((IQ) pk).getType().equals(IQ.Type.RESULT)) {
				res = true;
				
				iqPakect = (ThirdAppsExtension) pk;								
			}
			
			Log.d(TAG, "ThirdAppListener" + iqPakect.getApps().size());
			for (int i = 0; i < iqPakect.getApps().size(); ++i) {
				Log.d(TAG, "app name=" + iqPakect.getApps().get(i).getAppName() 
						+ "downloadlink=" + iqPakect.getApps().get(i).getDownloadLink());
			}
			
			// return to client message
			android.os.Message msg = new android.os.Message();
			msg.what = InternalReceiveEngine.RETURN_GET_THIRD_APPS_MSG;
			Bundle b = new Bundle();
			b.putInt("type", Constants.MESSAGE_INTERAL_TYPE);
			b.putString("appId", appId);
			b.putString("key", key);
			b.putBoolean("result", res);
			b.putString("reason", "");
			if (iqPakect != null) {
				b.putParcelableArrayList("apps", iqPakect.getApps());
			}
			msg.setData(b);
			
			receiveHandler.sendMessage(msg);			
			
			xmppClient.getXmppConn().removePacketListener(this);
		}
	}
	
	
	/**
	 * <p>Search the third application according to a key</P>
	 * @param msg
	 * @return
	 */
	public int searchThirdApps(Message msg) {
		Log.d(TAG, "getThirdApps");
		if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
			returnToClientConnectedFailed();
			return -1;
		}
		
		Bundle bl = msg.getData();
		int count = bl.getInt("count");
		String key = bl.getString("key");
		String appId = bl.getString("appId");
		
		IQ request = new IQ() {
			@Override
			public String getChildElementXML() {
				StringBuilder sb = new StringBuilder();
				sb.append("<application xmlns=\"application:motolbs:disc\" />");
				return sb.toString();
			}
		};
		
		request.setType(Type.GET);
		request.setTo("portal.motolbs.com");
		request.setProperty("appId", appId);
		Log.d(TAG, "searchThirdApps:" + request.toXML());

		String id = request.getPacketID();
		PacketFilter idFilter = new PacketIDFilter(id);
		
		this.xmppClient.getXmppConn().addPacketListener(
				new ThirdAppListener(key, count, appId), idFilter);
		
		xmppClient.getXmppConn().sendPacket(request);
		
		// todo
//		bl.putInt("count", maxCount);
		return 0;
	}
	
	/**
	 * <p>New user want to login into this platform</P>
	 * @param msg
	 * @return
	 */
	public int newUserLogin(Message msg) {
		Log.d(TAG, "newUserLogin" );
		if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
			returnToClientConnectedFailed();
			return -1;
		}
		
		Bundle bl = msg.getData();
		
		String email = bl.getString("email");
		String pass = bl.getString("password");
		String appId = bl.getString("appId");
		
		
		UserRegisterIQ userRegisterIQ = new UserRegisterIQ();
		userRegisterIQ.setEmail(email);
		
		userRegisterIQ.setTo("usermap.motolbs.com");
		userRegisterIQ.setType(IQ.Type.GET);
		
		Log.d(TAG, userRegisterIQ.toXML());
		String packageId = userRegisterIQ.getPacketID();
		PacketFilter idFilter = new PacketIDFilter(packageId);

		xmppClient.xmppConn.addPacketListener(new GetUserRegisterListener(appId, email, 
				Constants.USER_LOGIN_ACTION, pass), idFilter);

		xmppClient.xmppConn.sendPacket(userRegisterIQ);		
		
		
		return 0;
	}
	
	public int setShareLocationTime(Message msg) {
		Log.d(TAG, "setShareLocationTime");
		
		Bundle bl = msg.getData();
		String startHour = bl.getString("start");
		String endHour = bl.getString("end");
		
		
		UserPreference.saveShareLocationHour(startHour, endHour, context);
		
		return 0;
	}
	
	private void returnToClientConnectedFailed() {
		if (receiveHandler != null) {
			Message msg = new Message();
			msg.what = GeneralReceiveEngine.RETURN_CONNECTED_STATE_MSG;
			Bundle bl = new Bundle();
			bl.putInt("connect", xmppClient.connectionState);
			bl.putInt("type", Constants.MESSAGE_GENERAL_TYPE);
			msg.setData(bl);
			
			receiveHandler.sendMessage(msg);
		}
	}
	    
    /**
     * <p>register the receive handler, if not call this function, the handler is null forever</P>
     * @param handler
     */
    public void registerReceiveHandler(Handler handler) {
    	this.receiveHandler = handler;
    }
}
