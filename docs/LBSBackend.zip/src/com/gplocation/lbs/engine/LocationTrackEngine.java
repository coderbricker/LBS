package com.gplocation.lbs.engine;

import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import org.jivesoftware.smack.XMPPConnection;
import org.jivesoftware.smack.packet.Message;

import android.content.Context;
import android.location.Location;

import com.gplocation.lbs.packetprovider.LocationExtensionProvider.LocationExtension;
import com.gplocation.lbs.packetprovider.TrackLocationExtension;
import com.gplocation.lbs.utils.LocationHelper;

public class LocationTrackEngine {
    private Context context;
    private int interval;
//    private int distance;
    private Timer timer;
    private LocationExtension oldLocation;
    private XMPPConnection xmppConnection; 
    private static final String LOCATIONTRACK = "locationtrack.motolbs.com"; 
    
    public LocationTrackEngine(XMPPConnection xmppConnection, Context context, int interval, int distance) {
        this.xmppConnection = xmppConnection;
        this.context = context;
        this.interval = interval;
//        this.distance = distance;
        timer = new Timer();
    }
    
    public void uploadLocationRegular() {
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                Location location = LocationHelper.getLocation(context);
                LocationExtension newLocation = getLocationExtension(location);
                Message message = new Message();
                message.setTo(LOCATIONTRACK);
                message.addExtension(new TrackLocationExtension(newLocation, oldLocation));
                xmppConnection.sendPacket(message);
                oldLocation = newLocation;
            }
        }, new Date(), interval*1000);
        
    }
    
    private LocationExtension getLocationExtension(Location location){
        LocationExtension locationExtension = new LocationExtension("");
        if(location!=null){
            locationExtension.setAccuracy(String.valueOf(location.getAccuracy()));
            locationExtension.setLatitude(String.valueOf(location.getLatitude()));
            locationExtension.setLongitude(String.valueOf(location.getLongitude()));
        }else{
            locationExtension.setAccuracy("121");
            locationExtension.setLatitude("123");
            locationExtension.setLongitude("37");
        }
        return locationExtension;
    }
}
