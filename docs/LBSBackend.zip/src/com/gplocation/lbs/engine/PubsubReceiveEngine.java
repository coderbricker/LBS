// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.engine;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

import android.content.Context;
import android.os.Bundle;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;

import com.gplocation.lbs.application.MainApplication;
import com.gplocation.lbs.manager.ReceiveManager;
import com.gplocation.lbs.service.LBSCoreService;

/**
 * handle all received Pubsub messages
 */
public class PubsubReceiveEngine {

	private static final String TAG = "ReceiveEngine";
	public static final int UPDATEONTOPIC = 0;
	public static final int FETCHTOPICS = 1;
	 /**
     * will handled in xmpp runnable
     */
    public static Command [] pubsubReceiveCommands = { 
        new Command(UPDATEONTOPIC, "updateOnTopic"),
        new Command(FETCHTOPICS, "fetchTopics")
    	
    };
    

    private Context context;
    private ReceiveManager receiveManager;
    
    public PubsubReceiveEngine(Context context) {
    	this.context = context;
    	MainApplication mainApplication = ((MainApplication)((LBSCoreService) this.context).getApplication());
		receiveManager = mainApplication.receiveManager;
    }
    
    /**
     * when a  subscribed topic updated notify the user
     * Briefly describe what it does.
     * <p>If necessary, describe how it does and how to use it.</P>
     * @param msg
     * @return
     */
    public int updateOnTopic(Message msg) {
        Log.d(TAG, "updateOnTopic");
        
        Bundle bl = msg.getData();
        String topic = bl.getString("topic");
        String appId = bl.getString("appId");
        List<String> items = bl.getStringArrayList("itemsData");
        try {
            receiveManager.getPubSubListeners().get(appId).receivedUpdateOnTopic(topic, items);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
                        
        return 0;
    }
    public int fetchTopics(Message msg) {
    	Log.d(TAG, "fetchTopics");
        Bundle bl = msg.getData();
        String appId = bl.getString("appId");
        List<String> leafNodes = bl.getStringArrayList("leafNodes");
        try {
            receiveManager.getPubSubListeners().get(appId).receivedSearchedTopics(leafNodes);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        
        return 0;
    }
    
    
    /**
	 * <p>dynamically decide which function should be called</P>
	 * @param funName method name
	 * @param message, method param is message
	 * @return
	 * @throws NoSuchMethodException
	 * @throws InvocationTargetException
	 * @throws IllegalAccessException
	 */
	public Object dynaCall(String funName, Message message) throws NoSuchMethodException,
			InvocationTargetException, IllegalAccessException {
		Method meth = this.getClass().getMethod(funName, message.getClass());
		return (meth.invoke(this, message));
	}
		
}
