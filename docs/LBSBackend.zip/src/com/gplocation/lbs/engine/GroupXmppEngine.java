// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.engine;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

import org.jivesoftware.smack.PacketListener;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.filter.PacketFilter;
import org.jivesoftware.smack.filter.PacketIDFilter;
import org.jivesoftware.smack.packet.IQ;
import org.jivesoftware.smack.packet.IQ.Type;
import org.jivesoftware.smack.packet.Packet;
import org.jivesoftware.smackx.packet.VCard;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.gplocation.lbs.application.MainApplication;
import com.gplocation.lbs.data.GroupInfo;
import com.gplocation.lbs.data.Setting;
import com.gplocation.lbs.manager.DBManager;
import com.gplocation.lbs.manager.GroupManager;
import com.gplocation.lbs.manager.GroupSettingManager;
import com.gplocation.lbs.manager.LBSLocationManager;
import com.gplocation.lbs.packetprovider.NotifyExtensionProvider;
import com.gplocation.lbs.service.LBSCoreService;
import com.gplocation.lbs.service.SmackWrapper;
import com.gplocation.lbs.utils.ChinesePinYin;
import com.gplocation.lbs.utils.Constants;
/**
 * group engine
 */
public class GroupXmppEngine {
	
	private static final String TAG = "GroupXmppEngine";
	
    public static final int SEND_MESSAGE_MSG = 0;
    public static final int SHARE_LOCATION_MSG = 1;
    public static final int STOP_SHARE_LOCATION_MSG = 2;
    public static final int EXCUTE_SETTING_MSG = 3;
    public static final int STOP_EXCUTE_SETTING_MSG = 4;
    public static final int SEARCH_MSG = 5;
    public static final int APPROVE_INVITATION_MSG = 6;
    public static final int CREATE_MSG = 7;
    public static final int REMOVE_MSG = 8;
    public static final int EXIT_MSG = 9;
    public static final int CHANGE_INFO_MSG = 10;
    public static final int SET_MEMBER_AS_OWNER_MSG = 11;
    public static final int INVITE_USER_MSG = 12;
    public static final int REMOVE_MEMBER_MSG = 13;
    public static final int JOIN_MSG = 14;
    public static final int REQUEST_SETTING_MSG = 15;
    public static final int SET_SETTING_MSG = 16;
	 /**
     * will handled in xmpp runnable
     */
    public static Command [] groupXmppCommands = {
    	new Command(SEND_MESSAGE_MSG, "sendMessage"),
    	new Command(SHARE_LOCATION_MSG, "shareLocation"),
    	new Command(STOP_SHARE_LOCATION_MSG, "stopShareLocation"),
    	new Command(EXCUTE_SETTING_MSG, "excuteGroupSetting"),
    	new Command(STOP_EXCUTE_SETTING_MSG, "stopExcuteGroupSetting"),
    	new Command(SEARCH_MSG, "searchGroup"),
    	new Command(APPROVE_INVITATION_MSG, "approveInvitation"),
    	new Command(CREATE_MSG, "create"),
    	new Command(REMOVE_MSG, "remove"),
    	new Command(EXIT_MSG, "exit"),
    	new Command(CHANGE_INFO_MSG, "changeGroupInfo"),
    	new Command(SET_MEMBER_AS_OWNER_MSG, "setMemberAsOwner"),
    	new Command(INVITE_USER_MSG, "inviteUser"),
    	new Command(REMOVE_MEMBER_MSG, "removeMember"),  
    	new Command(JOIN_MSG, "join"),   	
    	new Command(REQUEST_SETTING_MSG, "requestGroupSetting"),   
    	new Command(SET_SETTING_MSG, "setGroupSetting")    	
    	
    };
    
    private Handler receiveHandler;
	private SmackWrapper xmppClient = null;
	private GroupManager groupManager;
	private GroupSettingManager groupSettingManager;
	private LBSLocationManager lbsLocationManager;
//    private String userName; 
    private String userId;
    private Context context;
    
	/**
	 * String: groupId/appId String
	 */
	private Map<String, Timer> timerMap = new HashMap<String, Timer>();
    
    public GroupXmppEngine(Context context, SmackWrapper xmppClient) {
    	MainApplication mainApplication = ((MainApplication) ((LBSCoreService) context).getApplication());
    	groupManager = mainApplication.groupManager;
    	groupSettingManager = mainApplication.groupSettingManager;
    	lbsLocationManager = mainApplication.lbsLocationManager;
		this.xmppClient = xmppClient;
		this.context = context;

//		userName = mainApplication.userInfo.getUserNick();
		userId = mainApplication.userInfo.getUserId();
    }
    
    /**
	 * <p>dynamically decide which function should be called</P>
	 * @param funName method name
	 * @param message, method param is message
	 * @return
	 * @throws NoSuchMethodException
	 * @throws InvocationTargetException
	 * @throws IllegalAccessException
	 */
	public Object dynaCall(String funName, Message message) throws NoSuchMethodException,
			InvocationTargetException, IllegalAccessException {
		Method meth = this.getClass().getMethod(funName, message.getClass());
		return (meth.invoke(this, message));
	}
	
	/**
	 * <p>Send message</P>
	 * @return
	 */
	public int sendMessage(Message msg) {
		Log.d(TAG, "sendMessage");
		if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
			returnToClientConnectedFailed();
			return -1;
		}
		
		Bundle bl = msg.getData();
		String groupId = bl.getString("groupId");
		boolean withLocation = bl.getBoolean("withLocation");
		String text = bl.getString("text");
		String appId = bl.getString("appId");
		
		lbsLocationManager.shareInGroup(appId, text, groupId, withLocation);
		return 0;
		
	}
	
	
	/**
	 * <p>client send group share location command</P>
	 * @param msg
	 * @return
	 */
	public int shareLocation(Message msg) {
		Log.d(TAG, "shareLocation");
		if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
			returnToClientConnectedFailed();
			return -1;
		}
		
		Bundle bl = msg.getData();
		final String groupId = bl.getString("groupId");
		boolean continous = bl.getBoolean("continous");
		int interval = bl.getInt("interval");
		final String appId = bl.getString("appId");
		
		
		if (continous) {
			Timer timer = new Timer();
			timer.schedule(new TimerTask() {
				
				@Override
				public void run() {
					Date d = new Date();
					int hours = d.getHours();
					String start = null;
					String end = null;
//					UserPreference.getShareLocationHour(start, end, context);
					DBManager dbManager = new DBManager(context);
					ArrayList<Setting>  set = (ArrayList<Setting>) dbManager.readGroupSetting(appId, groupId, groupId);
					for (int i=0; i<set.size(); ++i) {
						String key = set.get(i).getKey();
						if (key.equals("startTime")) {
							start = set.get(i).getValue();
						} else if (key.equals("startTime")) {
							end = set.get(i).getValue();
						}
					}
					
					
					if (start != null && end != null) {
						if (hours > Integer.parseInt(start) && hours < Integer.parseInt(end)) {
							lbsLocationManager.shareInGroup(appId, groupId);
						}
						
					} else {
						lbsLocationManager.shareInGroup(appId, groupId);
					}
				}
			}, 0, interval * 1000);
			
			this.timerMap.put(groupId + "/" + appId, timer);
		} else {
			lbsLocationManager.shareInGroup(appId, groupId);
		}
				
		return 0;
	}
	
	/**
	 * <p>stop share location</P>
	 * @param cmd
	 * @return
	 */
	public int stopShareLocation(android.os.Message cmd) {
		Log.d(TAG, "stopShareLocation");
		if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
			returnToClientConnectedFailed();
			return -1;
		}

		Bundle bl = cmd.getData();
		final String groupId = bl.getString("groupId");
		String appId = bl.getString("appId");
		
		Timer timer = this.timerMap.get(groupId + "/" + appId);
		if (timer != null) {
		    this.timerMap.get(groupId + "/" + appId).cancel();
		    this.timerMap.remove(groupId + "/" + appId);				
		}

		lbsLocationManager.stopShare(groupId, appId);
		
		return 0;
	}
	
	
	
	/**
	 * <p></P>
	 * @param cmd
	 * @return
	 */
	public int excuteGroupSetting(android.os.Message cmd) {
		Log.d(TAG, "excuteGroupSetting");
		if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
			returnToClientConnectedFailed();
			return -1;
		}
		
		Bundle bl = cmd.getData();
		final String groupId = bl.getString("groupId");
		String appId = bl.getString("appId");
		String settingName = bl.getString("settingName");
		
		//
		org.jivesoftware.smack.packet.Message packet = new org.jivesoftware.smack.packet.Message();
		NotifyExtensionProvider.NotifyExtension notifyExtension = new NotifyExtensionProvider.NotifyExtension(
				Constants.NOTIFY_START_EXCUTE_GROUP_SETTING, groupId + "/" + settingName);
		packet.addExtension(notifyExtension);
		packet.setTo(groupId);
		packet.setType(org.jivesoftware.smack.packet.Message.Type.groupchat);
		packet.setProperty("appId", appId);
		
		Log.d(TAG, packet.toXML());
		this.xmppClient.xmppConn.sendPacket(packet);
		
		return 0;
	}
	
	
	/**
	 * <p></P>
	 * @param cmd
	 * @return
	 */
	public int stopExcuteGroupSetting(android.os.Message cmd) {
		Log.d(TAG, "stopExcuteGroupSetting");
		if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
			returnToClientConnectedFailed();
			return -1;
		}
		
		Bundle bl = cmd.getData();
		final String groupId = bl.getString("groupId");
		String appId = bl.getString("appId");
		String settingName = bl.getString("settingName");
		
		//
		org.jivesoftware.smack.packet.Message packet = new org.jivesoftware.smack.packet.Message();
		NotifyExtensionProvider.NotifyExtension notifyExtension = new NotifyExtensionProvider.NotifyExtension(
				Constants.NOTIFY_STOP_EXCUTE_GROUP_SETTING, groupId + "/" + settingName);
		packet.addExtension(notifyExtension);
		packet.setTo(groupId);
		packet.setType(org.jivesoftware.smack.packet.Message.Type.groupchat);
		packet.setProperty("appId", appId);
		
		Log.d(TAG, packet.toXML());
		this.xmppClient.xmppConn.sendPacket(packet);
		
		return 0;
	}
	
	
	/**
	 * <p></P>
	 * @param cmd
	 * @return
	 */
	public int searchGroup(android.os.Message cmd) {
		Log.d(TAG, "searchGroup");
		if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
			returnToClientConnectedFailed();
			return -1;
		}
		
		Bundle bl = cmd.getData();		
		final String pattern = bl.getString("pattern");
		final String appId = bl.getString("appId");
		final int resultCount = bl.getInt("resultCount");
		
		final String key = pattern; 
		new Thread(new Runnable() {
			@Override
			public void run() {
				ArrayList<GroupInfo> groups = (ArrayList<GroupInfo>) groupManager
						.searchGroupFromServer(key, resultCount);
				int size = groups.size();
				int end = size;
				if (size > resultCount) {
					end = resultCount;
				}
				
				ArrayList<GroupInfo> returnGroups = new ArrayList<GroupInfo>();
				for (int i = 0; i < end; ++i) {
					returnGroups.add(groups.get(i));
				}
				
				android.os.Message msg = new android.os.Message();
				msg.what = GroupReceiveEngine.RETURN_SEARCH_MSG;
				Bundle b = new Bundle();
				b.putInt("type", Constants.MESSAGE_GROUP_TYPE);
				b.putString("appId", appId);
				b.putString("pattern", pattern);
				b.putParcelableArrayList("groupInfo", returnGroups);
				b.putInt("count", size);
				msg.setData(b);
				
				receiveHandler.sendMessage(msg);				
			}
			
		}).start();
		
		return 0;
	}
	
	
	/**
	 * <p>send query group setting message, when join a new group, if settingName == null, the query all</P>
	 * @param appId
	 * @param groupId
	 * @param settingName
	 */
	public void sendQueryGroupSetting(String appId, String groupId, String settingName) {
		// should query group setting data to client
		android.os.Message msg = new android.os.Message();
		msg.what = GroupXmppEngine.REQUEST_SETTING_MSG;
		Bundle b = new Bundle();
		b.putInt("type", Constants.MESSAGE_GROUP_TYPE);
		b.putString("appId", appId);
		b.putString("groupId", groupId);
		b.putString("settingName", settingName);
		msg.setData(b);
				
		requestGroupSetting(msg);
	}
	
	/**
	 * <p>approve somebody's invitation into a group, no need to return message to client,
	 * 		but should query group setting</P>
	 * @param cmd
	 * @return
	 */
	public int approveInvitation(android.os.Message cmd) {
		Log.d(TAG, "approveInvitation");
		if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
			returnToClientConnectedFailed();
			return -1;
		}
		
		Bundle bl = cmd.getData();	
		final String groupId = bl.getString("groupId");
		String appId = bl.getString("appId");
		
		String userName = ((MainApplication) ((LBSCoreService) context).getApplication()).userInfo.getUserNick();
		boolean res = this.groupManager.joinGroup(groupId, userName);
    	if (res) {
//			Preference.saveJoinedGroups(groupId, Preference.ADD, context);
    		
			// should query group setting data to client
    		sendQueryGroupSetting(appId, groupId, null);
    		
    		sendMemberListChange(groupId, userId, userName, "none",  "add");
    	}
		
    	//send data back to client group list changed
    	android.os.Message msg = new android.os.Message();
    	msg.what = GroupReceiveEngine.RETURN_GROUP_LIST_CHANGED_MSG;
    	Bundle b = new Bundle();
    	b.putInt("type", Constants.MESSAGE_GROUP_TYPE);
    	b.putString("groupId", groupId);
    	b.putString("appId", appId);
    	b.putString("action", "add");
    	msg.setData(b);
    	receiveHandler.sendMessage(msg);
    	
		return 0;
	}
	
	
	
	
		
	/**
	 * Group listener to create a new group or not
	 * @todo could use PacketCollector
	 */
	private class GroupPacketListener implements PacketListener {
		private String appId;
		private String description;
		private String groupName;

		public GroupPacketListener(String groupName, String des, String appId) {
			description = des;
			this.groupName = groupName;
			this.appId = appId;
		}

		@Override
		public void processPacket(Packet pk) {
			Log.d(TAG, "GroupPacketListener received:" + pk.toXML());
			String groupId = pk.getFrom();
//			String appId = (String) pk.getProperty("appId");
			String reason = "";
			boolean res = false;
			
			String userName = ((MainApplication) ((LBSCoreService) context).getApplication()).userInfo.getUserNick();
			if (((IQ) pk).getType().equals(IQ.Type.ERROR)) {
				// create group
				res = groupManager.createGroup(groupId, description, userName);
				if (res) {
					// send member list changed message
					sendMemberListChange(groupId, userId, userName, "owner", "add");
					
					// set group setting
//					android.os.Message msgSetting = new android.os.Message();
//					msgSetting.what = GroupXmppEngine.SET_SETTING_MSG;
//					Bundle bl = new Bundle();
//					bl.putInt("type", Constances.MESSAGE_GROUP_TYPE);
//					bl.putString("appId", appId);
//					bl.putString("groupId", groupId);
//					bl.putString("settingName", groupId); // groupId as its settingName
					
					ArrayList<Setting> gSetting = new ArrayList<Setting>();
					Setting setting = new Setting("interval", "20", "String");
					gSetting.add(setting);
					Setting setting1 = new Setting("startTime", "0:0", "String");
					gSetting.add(setting1);
					Setting setting2 = new Setting("endTime", "23:59", "String");
					gSetting.add(setting2);
//					bl.putParcelableArrayList("setting", (ArrayList<? extends Parcelable>) gSetting);
//					
//					msgSetting.setData(bl);
					
					groupSettingManager.set(appId, groupId, groupId, gSetting);
//					setGroupSetting(msgSetting);
//		    		sendQueryGroupSetting(appId, groupId, null);
				} else {
					reason = "Create failed";
				}
				
			} else {
				reason = "The group already exists!";
			}
			
			Log.d(TAG, "send Message to receivehandler");
			
			// return to client message
			android.os.Message msg = new android.os.Message();
			msg.what = GroupReceiveEngine.RETURN_CREATE_MSG;
			Bundle b = new Bundle();
			b.putInt("type", Constants.MESSAGE_GROUP_TYPE);
			b.putString("appId", appId);
			b.putString("groupId", groupId);
			b.putString("groupName", groupName);
			b.putBoolean("result", res);
			b.putString("reason", reason);
			msg.setData(b);
			
			receiveHandler.sendMessage(msg);			
			
			xmppClient.getXmppConn().removePacketListener(this);
		}

	}
	
	/**
	 * <p>Create a group, but firstly send query message to server, then create or not in return message listener</P>
	 * @param cmd
	 * @return
	 */
	public int create(android.os.Message cmd) {
		Log.d(TAG, "create");
		if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
			returnToClientConnectedFailed();
			return -1;
		}
		

		Bundle bl = cmd.getData();	
		//note it is not group Id	
		String groupName = bl.getString("groupName");
		final String groupId = ChinesePinYin.getSelling(groupName)+ Constants.DEFAULT_CONFERENCE_SERVICE;
//		String subject = bl.getString("subject");
		String description = bl.getString("description");
		String appId = bl.getString("appId");
		
		// query whether the group exists
		IQ request = new IQ() {
			@Override
			public String getChildElementXML() {
				StringBuilder sb = new StringBuilder();
				sb.append("<query xmlns=\"http://jabber.org/protocol/disco#info\" />");
				return sb.toString();
			}
		};
		request.setType(Type.GET);
		request.setTo(groupId);
		request.setProperty("appId", appId);
		Log.d(TAG, "queryGroupForCreate:" + request.toXML());

		String id = request.getPacketID();
		PacketFilter idFilter = new PacketIDFilter(id);
		
		this.xmppClient.getXmppConn().addPacketListener(
				new GroupPacketListener(groupName, description, appId), idFilter);
		
		xmppClient.getXmppConn().sendPacket(request);
		
		return 0;
	}
	
	
	/**
	 * <p>remove a group</P>
	 * @param cmd
	 * @return
	 */
	public int remove(android.os.Message cmd) {
		Log.d(TAG, "remove");
		if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
			returnToClientConnectedFailed();
			return -1;
		}
		
		Bundle bl = cmd.getData();	
		//note it is not group Id				
		final String groupId = bl.getString("groupId");
		String appId = bl.getString("appId");
		
		//
		boolean res = groupManager.remvoeGroup(groupId, userId);
		// return to client message
		android.os.Message msg = new android.os.Message();
		msg.what = GroupReceiveEngine.RETURN_REMOVE_MSG;
		Bundle b = new Bundle();
		b.putInt("type", Constants.MESSAGE_GROUP_TYPE);
		b.putString("appId", appId);
		b.putString("groupId", groupId);
		b.putBoolean("result", res);
		msg.setData(b);

		receiveHandler.sendMessage(msg);

		if (res) {
			sendGroupListChange(groupId, "remove");
			removeGroupTimer(groupId);
		}
		
		return 0;
	}
	
	/**
	 * <p>exit a group</P>
	 * @param cmd
	 * @return
	 */
	public int exit(android.os.Message cmd) {
		Log.d(TAG, "exit");
		if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
			returnToClientConnectedFailed();
			return -1;
		}
		
		Bundle bl = cmd.getData();	
		//note it is not group Id				
		final String groupId = bl.getString("groupId");
		String appId = bl.getString("appId");
		boolean res = groupManager.exitGroup(groupId);
		
		// return to client message
		android.os.Message msg = new android.os.Message();
		msg.what = GroupReceiveEngine.RETURN_EXIT_MSG;
		Bundle b = new Bundle();
		b.putInt("type", Constants.MESSAGE_GROUP_TYPE);
		b.putString("appId", appId);
		b.putString("groupId", groupId);
		b.putBoolean("result", res);
		msg.setData(b);

		receiveHandler.sendMessage(msg);
		
		if (res) {
			sendGroupListChange(groupId, "remove");
			removeGroupTimer(groupId);
		}

		return 0;
	}
	
	
	
	/**
	 * <p>change group information</P>
	 * @param cmd
	 * @todo, not handled, because it is used when change nickname or subject, not description
	 * @return
	 */
	public int changeGroupInfo(android.os.Message cmd) {
		Log.d(TAG, "changeGroupInfo");
		if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
			returnToClientConnectedFailed();
			return -1;
		}
		
		Bundle bl = cmd.getData();				
		final String groupId = bl.getString("groupId");
		String appId = bl.getString("appId");
		GroupInfo groupInfo = bl.getParcelable("groupInfo");
		
		boolean res = groupManager.setGroupInfo(groupInfo);
		
		
		android.os.Message msg = new android.os.Message();
		msg.what = GroupReceiveEngine.RETURN_SET_GROUP_INFORMATION_MSG;
		Bundle b = new Bundle();
		b.putInt("type", Constants.MESSAGE_GROUP_TYPE);
		b.putString("appId", appId);
		b.putString("groupId", groupId);
		b.putParcelable("groupInfo", groupInfo);
		b.putBoolean("result", res);
		msg.setData(b);

		receiveHandler.sendMessage(msg);
		
		
		return 0;
	}
	
	
	/**
	 * <p>Set member as owner</P>
	 * @param cmd
	 * @return
	 */
	public int setMemberAsOwner(android.os.Message cmd) {
		Log.d(TAG, "setMemberAsOwner");
		if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
			returnToClientConnectedFailed();
			return -1;
		}
		
		Bundle bl = cmd.getData();	
		//note it is not group Id				
		final String groupId = bl.getString("groupId");
		String memberId = bl.getString("memberId");
		String appId = bl.getString("appId");
		
		boolean res = groupManager.setUserAsOwner(groupId, memberId);

		// return to client message
		android.os.Message msg = new android.os.Message();
		msg.what = GroupReceiveEngine.RETURN_SET_MEMBER_OWNER_MSG;
		Bundle b = new Bundle();
		b.putInt("type", Constants.MESSAGE_GROUP_TYPE);
		b.putString("appId", appId);
		b.putString("groupId", groupId);
		b.putString("memberId", memberId);
		b.putBoolean("result", res);
		msg.setData(b);

		receiveHandler.sendMessage(msg);
		
		if (res) {
			String nick = null;
			VCard vCard = new VCard();
			try {
				vCard.load(xmppClient.xmppConn, memberId);
				nick = vCard.getNickName();
			} catch (XMPPException e) {
				e.printStackTrace();
			}
			if (nick == null || "".equals(nick)) {
				nick = memberId.split("@")[0];
			}
			 
			sendMemberListChange(groupId, memberId, nick, "owner", "add");
		}
		
		return 0;
	}
	
		
	/**
	 * <p></P>
	 * @param cmd
	 * @return
	 */
	public int inviteUser(android.os.Message cmd) {
		Log.d(TAG, "inviteUser");
		if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
			returnToClientConnectedFailed();
			return -1;
		}
		
		Bundle bl = cmd.getData();	
		//note it is not group Id				
		final String groupId = bl.getString("groupId");
		String memberId = bl.getString("memberId");
		String appId = bl.getString("appId");
		
		boolean res = groupManager.inviteUserIntoGroup(groupId, memberId);

		// return to client message
		android.os.Message msg = new android.os.Message();
		msg.what = GroupReceiveEngine.RETURN_INVITE_USER_MSG;
		Bundle b = new Bundle();
		b.putInt("type", Constants.MESSAGE_GROUP_TYPE);
		b.putString("appId", appId);
		b.putString("groupId", groupId);
		b.putString("memberId", memberId);
		b.putBoolean("result", res);
		msg.setData(b);

		receiveHandler.sendMessage(msg);
		return 0;
	}
	
	
	/**
	 * <p>send to receiver memeberlist changed</P>
	 * @param groupId
	 * @param userId
	 * @param userNick
	 * @param action
	 */
	private void sendGroupListChange(String groupId, String action) {
		android.os.Message msg = new android.os.Message();
		msg.what = GroupReceiveEngine.RETURN_GROUP_LIST_CHANGED_MSG;
    	
    	Bundle bl = new Bundle();
    	bl.putInt("type", Constants.MESSAGE_GROUP_TYPE);
    	bl.putString("groupId", groupId);
    	bl.putString("action", action);
    	msg.setData(bl);
    	
    	receiveHandler.sendMessage(msg);  
	}
	
	
	/**
	 * <p>send to receiver memeberlist changed</P>
	 * @param groupId
	 * @param userId
	 * @param userNick
	 * @param action
	 */
	private void sendMemberListChange(String groupId, String userId, String userNick, String role, String action) {
		android.os.Message msg = new android.os.Message();
		msg.what = GroupReceiveEngine.RETURN_MEMBER_LIST_CHANGED_MSG;
    	
    	Bundle bl = new Bundle();
    	bl.putInt("type", Constants.MESSAGE_GROUP_TYPE);
    	bl.putString("groupId", groupId);
    	bl.putString("memberId", userId);
    	bl.putString("nick", userNick);
    	bl.putString("role", role);
    	bl.putString("action", action);
    	msg.setData(bl);
    	
    	receiveHandler.sendMessage(msg);  
	}
	
	/**
	 * <p></P>
	 * @param cmd
	 * @return
	 */
	public int removeMember(android.os.Message cmd) {
		Log.d(TAG, "removeMember");
		if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
			returnToClientConnectedFailed();
			return -1;
		}
		
		Bundle bl = cmd.getData();	
		//note it is not group Id				
		final String groupId = bl.getString("groupId");
		String memberId = bl.getString("memberId");
		String nick = bl.getString("nick");
		String appId = bl.getString("appId");
		
		boolean res = groupManager.removeMember(groupId, nick);
//		returnOperateResultToClient(Constances.CLIENT_ACTION_REMOVE_MEMBER_FROM_GROUP, (String) cmd.obj, res);

		// return to client message
		android.os.Message msg = new android.os.Message();
		msg.what = GroupReceiveEngine.RETURN_REMOVE_MEMBER_MSG;
		Bundle b = new Bundle();
		b.putInt("type", Constants.MESSAGE_GROUP_TYPE);
		b.putString("appId", appId);
		b.putString("groupId", groupId);
		b.putString("memberId", memberId);
		b.putString("nick", nick);
		b.putBoolean("result", res);
		msg.setData(b);

		receiveHandler.sendMessage(msg);
		
		
		if (res) {
			// a presence package will send to you
			sendMemberListChange(groupId, memberId, nick, "", "remove");			
		}
		
		return 0;
	}
	
	
	/**
	 * <p></P>
	 * @param cmd
	 * @return
	 */
	public int join(android.os.Message cmd) {
		Log.d(TAG, "join");
		if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
			returnToClientConnectedFailed();
			return -1;
		}
		
		Bundle bl = cmd.getData();	
		//note it is not group Id				
		final String groupId = bl.getString("groupId");
		String appId = bl.getString("appId");
		

		String userName = ((MainApplication) ((LBSCoreService) context).getApplication()).userInfo.getUserNick();
		boolean res = groupManager.joinGroup(groupId, userName);
		
		// return to client message
		android.os.Message msg = new android.os.Message();
		msg.what = GroupReceiveEngine.RETURN_JOIN_MSG;
		Bundle b = new Bundle();
		b.putInt("type", Constants.MESSAGE_GROUP_TYPE);
		b.putString("appId", appId);
		b.putString("groupId", groupId);
		b.putBoolean("result", res);
		msg.setData(b);

		receiveHandler.sendMessage(msg);
		
		if (res) {
			sendQueryGroupSetting(appId, groupId, null);
			
			sendGroupListChange(groupId, "add");
			sendMemberListChange(groupId, userId, userName, "none", "add");
		}
		
		return 0;
	}
	
	/**
	 * <p>request group setting from sever</P>
	 * @param cmd
	 * @return
	 */
	public int requestGroupSetting(android.os.Message cmd) {
		Log.d(TAG, "requestGroupSetting");
		if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
			returnToClientConnectedFailed();
			return -1;
		}
		
		Bundle bl = cmd.getData();	
		//note it is not group Id				
		final String groupId = bl.getString("groupId");
		String appId = bl.getString("appId");
		String settingName = bl.getString("settingName");
		
		groupSettingManager.query(appId, groupId, settingName);
		
		// send back to client to get group setting when got from server		
		return 0;
	}
	
	
	/**
	 * <p></P>
	 * @param cmd
	 * @return
	 */
	public int setGroupSetting(android.os.Message cmd) {
		Log.d(TAG, "setGroupSetting");
		if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
			returnToClientConnectedFailed();
			return -1;
		}
		
		Bundle bl = cmd.getData();	
		//note it is not group Id				
		final String groupId = bl.getString("groupId");
		String appId = bl.getString("appId");
		String settingName = bl.getString("settingName");
		ArrayList<Setting> settingList = bl.getParcelableArrayList("setting");

		groupSettingManager.set(appId, groupId, settingName, settingList);
		
		return 0;
	}
	
	private void returnToClientConnectedFailed() {
		if (receiveHandler != null) {
			Message msg = new Message();
			msg.what = GeneralReceiveEngine.RETURN_CONNECTED_STATE_MSG;
			Bundle bl = new Bundle();
			bl.putInt("connect", xmppClient.connectionState);
			bl.putInt("type", Constants.MESSAGE_GENERAL_TYPE);
			msg.setData(bl);
			
			receiveHandler.sendMessage(msg);
		}
	}
	     
    /**
     * <p>register the receive handler, if not call this function, the handler is null forever</P>
     * @param handler
     */
    public void registerReceiveHandler(Handler handler) {
    	this.receiveHandler = handler;
    }
    
    
    /**
     * <p>remvoe timer</P>
     * @param appId
     */
    public void removeTimer(String appId) {
    	Set<String> keys = timerMap.keySet();
    	for (String string : keys) {
			Timer timer = timerMap.get(string);
			if (string.endsWith(appId) && timer != null) {
				timer.cancel();
				timerMap.remove(string);
			}
		}
    }
    
    
    /**
     * <p>remvoe timer</P>
     * @param appId
     */
    public void removeGroupTimer(String groupId) {
    	Set<String> keys = timerMap.keySet();
    	for (String string : keys) {
			Timer timer = timerMap.get(string);
			if (string.startsWith(groupId) && timer != null) {
				timer.cancel();
				timerMap.remove(string);
			}
		}
    }
}
