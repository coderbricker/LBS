// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.engine;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.Timer;
import java.util.TimerTask;

import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smackx.packet.VCard;

import android.app.Service;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.gplocation.lbs.application.MainApplication;
import com.gplocation.lbs.manager.LBSLocationManager;
import com.gplocation.lbs.manager.RosterManager;
import com.gplocation.lbs.service.SmackWrapper;
import com.gplocation.lbs.utils.Constants;
import com.gplocation.lbs.utils.UserPreference;

/**
 * handle roster in xmpp
 */
public class RosterXmppEngine {

	private static final String TAG = "RosterXmppEngine";
	

    public static final int ADD_FRIEND_MSG = 0;
    public static final int REMOVE_FRIEND_MSG = 1;
    public static final int SEND_MESSAGE_MSG = 2;
    public static final int SEND_BINARY_MESSAGE_MSG = 3;
    public static final int REQUEST_LOCATION_MSG = 4;
    public static final int FOLLOW_LOCATION_MSG = 5;
    public static final int STOP_FOLLOW_LOCATION_MSG = 6;
    public static final int SHARE_LOCATION_MSG = 7;
    public static final int SHARE_LOCATION_DISTANCE_MSG = 8;
    public static final int STOP_SHARE_LOCATION_MSG = 9;
    
	 /**
     * will handled in xmpp runnable
     */
    public static Command [] rosterXmppCommands = {
    	new Command(ADD_FRIEND_MSG, "addFriend"),
    	new Command(REMOVE_FRIEND_MSG, "removeFriend"),
    	new Command(SEND_MESSAGE_MSG, "sendMessage"),
    	new Command(SEND_BINARY_MESSAGE_MSG, "sendBinaryMessage"),
    	new Command(REQUEST_LOCATION_MSG, "requestLocation"),
    	new Command(FOLLOW_LOCATION_MSG, "followLocation"),
    	new Command(STOP_FOLLOW_LOCATION_MSG, "stopFollowLocation"),
    	new Command(SHARE_LOCATION_MSG, "shareLocation"),
    	new Command(SHARE_LOCATION_DISTANCE_MSG, "shareLocationDistance"),
    	new Command(STOP_SHARE_LOCATION_MSG, "stopShareLocation")
    };
    

	private RosterManager rosterManager;
	private LBSLocationManager lbsLocationManager;
	private SmackWrapper xmppClient = null;
	private Handler receiveHandler;
	private Context context;
	
	/**
	 * String: friendId/appId String
	 */
	public Map<String, Timer> timerMap = new HashMap<String, Timer>();
    
    public RosterXmppEngine(Context context, SmackWrapper xmppClient) {
    	this.context = context;
		rosterManager = ((MainApplication) ((Service) context).getApplication()).rosterManager;
		lbsLocationManager = ((MainApplication) ((Service) context).getApplication()).lbsLocationManager;
		this.xmppClient = xmppClient;
    }
    
    /**
	 * <p>dynamically decide which function should be called</P>
	 * @param funName method name
	 * @param message, method param is message
	 * @return
	 * @throws NoSuchMethodException
	 * @throws InvocationTargetException
	 * @throws IllegalAccessException
	 */
	public Object dynaCall(String funName, Message message) throws NoSuchMethodException,
			InvocationTargetException, IllegalAccessException {
		Method meth = this.getClass().getMethod(funName, message.getClass());
		return (meth.invoke(this, message));
	}
	
	
	/**
	 * @todo should judge whether the friend which wanted to add is existed in
	 *       server
	 * @param cmd
	 * @param roster
	 * @return
	 */
	public int addFriend(android.os.Message cmd) {
    	Log.d(TAG, "xmpp receive addFriend");
		if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
			returnToClientConnectedFailed();
			return -1;
		}

		
		Bundle bl = cmd.getData();
		String account = bl.getString("friendId");
		String nickName = bl.getString("nick");
//		String appId = bl.getString("appId");
		boolean res = rosterManager.addRoster(account, nickName);
		bl.putBoolean("result", res);
		
		VCard vCard = new VCard();
		try {
			vCard.load(xmppClient.xmppConn, account);
			
			String email = vCard.getEmailHome();
			bl.putString("email", email);
			
			String phone = vCard.getPhoneHome(Constants.DEFAULT_PHONE_TYPE);
			bl.putString("phone", phone);
		} catch (XMPPException e) {
			e.printStackTrace();
		}
		
		if (receiveHandler != null) {
			Message msg = new Message();
			msg.what = RosterReceiveEngine.RETURN_ADD_RESULT_MSG;
			msg.setData(bl);
			receiveHandler.sendMessage(msg);
		}
		
		return 0;
	}

	/**
	 * remove friend
	 * 
	 * @param cmd
	 * @param roster
	 * @return
	 */
	public int removeFriend(android.os.Message cmd) {
    	Log.d(TAG, "xmpp receive removeFriend");
		if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
			returnToClientConnectedFailed();
			return -1;
		}

		Bundle bl = cmd.getData();
		String account = bl.getString("friendId");
//		String appId = bl.getString("appId");
		boolean res = rosterManager.removeRoster(account);
		bl.putBoolean("result", res);
		if (receiveHandler != null) {
			Message msg = new Message();
			msg.what = RosterReceiveEngine.RETURN_REMOVE_RESULT_MSG;
			msg.setData(bl);
			receiveHandler.sendMessage(msg);
		}
		
		
		if (res) {
			removeRosterTimer(account);
		}
		
		
		return 0;
	}
	
	
	/**
	 * <p>Send message</P>
	 * @param cmd
	 * @return
	 */
	public int sendMessage(android.os.Message cmd) {
    	Log.d(TAG, "xmpp receive sendMessage");
		if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
			returnToClientConnectedFailed();
			return -1;
		}
		
		
		Bundle bl = cmd.getData();
		String account = bl.getString("friendId");
		String text = bl.getString("text");
		String appId = bl.getString("appId");
		boolean withLocation = bl.getBoolean("withLocation"); 

		lbsLocationManager.share(appId, text, account, withLocation);
		
		return 0;
	}
	
	/**
	 * <p>Send Binary message</P>
	 * @todo
	 * @param cmd
	 * @return
	 */
	public int sendBinaryMessage(android.os.Message cmd) {
    	Log.d(TAG, "xmpp receive sendBinaryMessage");
		if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
			returnToClientConnectedFailed();
			return -1;
		}
		
		return 0;
	}
	
	/**
	 * <p>Share location</P>
	 * @param cmd
	 * @return
	 */
	public int shareLocation(android.os.Message cmd) {
		Log.d(TAG, "shareLocation");
		if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
			returnToClientConnectedFailed();
			return -1;
		}
		
		Bundle bl = cmd.getData();
		final String friend = bl.getString("friendId");
		final String appId = bl.getString("appId");
		boolean continuse = bl.getBoolean("continuse");
		int interval = bl.getInt("interval"); // in minus

		if (continuse) {
			Timer timer = new Timer();
			timer.schedule(new TimerTask() {
				
				@SuppressWarnings("unused")
				@Override
				public void run() {
					Date d = new Date();
					int hours = d.getHours();
					String start = null;
					String end = null;
					UserPreference.getShareLocationHour(start, end, context);
					
					if (start != null && end != null) {
						if (hours > Integer.parseInt(start) && hours < Integer.parseInt(end)) {
							lbsLocationManager.share(appId, friend);
						}
						
					} else {
						lbsLocationManager.share(appId, friend);
					}
				}
			}, 0, interval * 1000);
			
			this.timerMap.put(friend + "/" + appId, timer);
		} else {
			lbsLocationManager.share(appId, friend);
		}
		
		return 0;
	}

	/**
	 * <p>Share location by distance</P>
	 * @param cmd
	 * @return
	 */
	public int shareLocationDistance(android.os.Message cmd) {
		Log.d(TAG, "shareLocationDistance");
		if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
			returnToClientConnectedFailed();
			return -1;
		}

		Bundle bl = cmd.getData();
		final String friend = bl.getString("friendId");
		final String appId = bl.getString("appId");
		boolean continuse = bl.getBoolean("continuse");
		final int distance = bl.getInt("distance"); // in meter
		
		if (continuse) {
			Timer timer = new Timer();
			timer.schedule(new TimerTask() {
				
				@Override
				public void run() {
					lbsLocationManager.shareByDistance(appId, friend, distance);
				}
			}, 0, Constants.DEFAULT_SHARING_LOCATION_SECOND * 1000);
			
			this.timerMap.put(friend + "/" + appId, timer);
		} else {
			lbsLocationManager.shareByDistance(appId, friend, distance);
		}
				

		return 0;
	}
	
	
	/**
	 * <p>stop share location</P>
	 * @param cmd
	 * @return
	 */
	public int stopShareLocation(android.os.Message cmd) {
		Log.d(TAG, "stopShareLocation");
		if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
			returnToClientConnectedFailed();
			return -1;
		}

		Bundle bl = cmd.getData();
		final String friend = bl.getString("friendId");
		String appId = bl.getString("appId");
		
		this.timerMap.get(friend + "/" + appId).cancel();
		this.timerMap.remove(friend + "/" + appId);				


		// to tell the shared man "I stop sharing"
		lbsLocationManager.stopShare(friend, appId);
		
		return 0;
	}
	
	

	/**
	 * <p>request somebody's location</P>
	 * @param cmd
	 * @return
	 */
	public int requestLocation(android.os.Message cmd) {
		Log.d(TAG, "requestLocation");
		if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
			returnToClientConnectedFailed();
			return -1;
		}

		Bundle bl = cmd.getData();
		final String friend = bl.getString("friendId");
		String appId = bl.getString("appId");
		lbsLocationManager.request(friend, appId);
		
		return 0;
	}

	/**
	 * <p>follow somebody's location</P>
	 * @param cmd
	 * @return
	 */
	public int followLocation(android.os.Message cmd) {
		Log.d(TAG, "followLocation");
		if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
			returnToClientConnectedFailed();
			return -1;
		}

		Bundle bl = cmd.getData();
		final String friend = bl.getString("friendId");
		String appId = bl.getString("appId");
		lbsLocationManager.follow(friend, appId);
		
		return 0;
	}
	
	/**
	 * <p>Stop follow</P>
	 * @param cmd
	 * @return
	 */
	public int stopFollowLocation(android.os.Message cmd) {
		Log.d(TAG, "stopFollowLocation");
		if (xmppClient.connectionState != Constants.CONNECTION_CONNECTED) {
			returnToClientConnectedFailed();
			return -1;
		}

		Bundle bl = cmd.getData();
		final String friend = bl.getString("friendId");
		String appId = bl.getString("appId");
		lbsLocationManager.stopFollow(friend, appId);
		
		return 0;
	}
	
	
	private void returnToClientConnectedFailed() {
		if (receiveHandler != null) {
			Message msg = new Message();
			msg.what = GeneralReceiveEngine.RETURN_CONNECTED_STATE_MSG;
			Bundle bl = new Bundle();
			bl.putInt("connect", xmppClient.connectionState);
			bl.putInt("type", Constants.MESSAGE_GENERAL_TYPE);
			msg.setData(bl);
			
			receiveHandler.sendMessage(msg);
		}
	}
	
	
    /**
     * <p>register the receive handler, if not call this function, the handler is null forever</P>
     * @param handler
     */
    public void registerReceiveHandler(Handler handler) {
    	this.receiveHandler = handler;
    	rosterManager.registerReceiveHandler(handler);
    }
    
    
    /**
     * <p>remvoe timer</P>
     * @param appId
     */
    public void removeTimer(String appId) {
    	Set<String> keys = timerMap.keySet();
    	for (String string : keys) {
			Timer timer = timerMap.get(string);
			if (string.endsWith(appId) && timer != null) {
				timer.cancel();
				timerMap.remove(string);
			}
		}
    }
    
    /**
     * <p>remvoe timer</P>
     * @param appId
     */
    public void removeRosterTimer(String friendId) {
    	Set<String> keys = timerMap.keySet();
    	for (String string : keys) {
			Timer timer = timerMap.get(string);
			if (string.startsWith(friendId) && timer != null) {
				timer.cancel();
				timerMap.remove(string);
			}
		}
    }
}
