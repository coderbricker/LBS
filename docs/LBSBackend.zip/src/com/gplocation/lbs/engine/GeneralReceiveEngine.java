// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.engine;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;

import android.content.Context;
import android.os.Bundle;
import android.os.Message;
import android.os.RemoteException;

import com.gplocation.lbs.application.MainApplication;
import com.gplocation.lbs.client.IGeneralListener;
import com.gplocation.lbs.manager.ReceiveManager;
import com.gplocation.lbs.service.LBSCoreService;
import com.gplocation.lbs.template.TemplateListeners.TemplateSubListener;

/**
 * handle General received messages
 */
public class GeneralReceiveEngine {

	@SuppressWarnings("unused")
	private static final String TAG = "GeneralReceiveEngine";
	

    public static final int RETURN_CONNECTED_STATE_MSG = 0;
    public static final int RETURN_AUTHENTICATE_RESULT_MSG = 1;
    
	/**
	 * will handled in xmpp runnable
	 */
    public static Command [] generalReceiveCommands = {
    	new Command(RETURN_CONNECTED_STATE_MSG, "receiveConnectedState"),
    	new Command(RETURN_AUTHENTICATE_RESULT_MSG, "receiveAuthenticate")
    };

    @SuppressWarnings("unused")
	private Context context;
    private ReceiveManager receiveManager;
    
    public GeneralReceiveEngine(Context context) {
    	this.context = context;

    	MainApplication mainApplication = ((MainApplication) ((LBSCoreService) context).getApplication());
		receiveManager = mainApplication.receiveManager;
    }
    
    /**
	 * <p>dynamically decide which function should be called</P>
	 * @param funName method name
	 * @param message, method param is message
	 * @return
	 * @throws NoSuchMethodException
	 * @throws InvocationTargetException
	 * @throws IllegalAccessException
	 */
	public Object dynaCall(String funName, Message message) throws NoSuchMethodException,
			InvocationTargetException, IllegalAccessException {
		Method meth = this.getClass().getMethod(funName, message.getClass());
		return (meth.invoke(this, message));
	}
	
	/**
	 * <p>general message will send to every body</P>
	 * @param msg
	 * @return
	 */
	public int receiveConnectedState(Message msg) {
		Bundle bl = msg.getData();
		int connect = bl.getInt("connect");
		
		HashMap<String, TemplateSubListener<IGeneralListener>> listeners = 
				receiveManager.getGeneralListeners().getListeners();
		for (TemplateSubListener<IGeneralListener> listener : listeners.values()) {
			try {
				listener.listener.receiveServiceStatusChanged(connect, "");
			} catch (RemoteException e) {
				e.printStackTrace();
			}
		}
		
		return 0;
	}
	
	
	/**
	 * <p></P>
	 * @param msg
	 * @return
	 */
	public int receiveAuthenticate(Message msg) {
		Bundle bl = msg.getData();
		String appId = bl.getString("appId");
		boolean result = bl.getBoolean("result");
		String reason = bl.getString("reason");
		
		try {
			receiveManager.getGeneralListeners().get(appId).receiveAuthenticateResult(result, reason);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		
		if (!result) {
			receiveManager.getGeneralListeners().remove(appId);
		}
		
		return 0;
	}
	
}
