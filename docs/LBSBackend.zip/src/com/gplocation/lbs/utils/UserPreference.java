// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.utils;

import java.util.HashSet;
import java.util.Set;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.util.Log;

import com.gplocation.lbs.data.LBSUserExtend;

/**
 * @brief read/write sharedpreference file
 */
public class UserPreference {
    
    public static final String LBSPREFERENCES = "LBSPreferences";
    public static final String USERNAME = "userName";
    public static final String USERID = "userId";
    public static final String USERNICK = "userNick";
    public static final String VCARDPHONE = "vcardPhone";
    public static final String VCARDEMAIL = "vcardEmail";

    public static final String SHARESTARTHOUR = "shareStartHour";
    public static final String SHAREENDHOUR = "shareEndHour";
    public static final String GROUPNAME = "groupName";
    public static final String JOINEDGROUP = "joinedGroup";
    public static final String HOST = "host";
    public static final String USERPASSWORD = "userPassword";
    public static final String DOMAIN = "domain";
    public static final String PORT = "port";
    public static final String ADD = "add";
    public static final String DELETE = "delete";
    public static final String NA = "";
    public static final String BASEURL = "192.168.1.101";
//    public static final String BASEURL = "1.202.242.138"; 

    public static final String GETUSERINFOURL = "http://" + BASEURL 
    		+ ":8088/LBSServerAppPortal/registerAction.action";

    //    public static final String GETUSERINFOURL = 
    //    "http://1.202.242.138:8088/LBSServerAssistant/registerAction.action";

    public static LBSUserExtend getUserInfo(Context context) {
        SharedPreferences preferences = context.getSharedPreferences(LBSPREFERENCES, Context.MODE_PRIVATE);
        String userName = preferences.getString(USERNAME, NA);
        String userId = preferences.getString(USERID, NA);
        String userNick = preferences.getString(USERNICK, NA);
        String vcardPhone = preferences.getString(VCARDPHONE, NA);
        String vcardEmail = preferences.getString(VCARDEMAIL, NA);
        String host = preferences.getString(HOST, NA);
        String userPassword = preferences.getString(USERPASSWORD, NA);
        String domain = preferences.getString(DOMAIN, NA);
        int port = preferences.getInt(PORT, 0);

        return new LBSUserExtend(userName, userId, userNick, vcardPhone, vcardEmail, host, userPassword, domain, port);
    }

    public static void saveUserInfo(LBSUserExtend userInfo, Context context) {
        SharedPreferences preferences = context.getSharedPreferences(LBSPREFERENCES, Context.MODE_PRIVATE);
        Editor editor = preferences.edit();

        editor.putString(USERNAME, userInfo.getUserName()); 
        editor.putString(USERID, userInfo.getUserId());
        editor.putString(USERNICK, userInfo.getUserNick());
        editor.putString(VCARDPHONE, userInfo.getvCardPhone());
        editor.putString(VCARDEMAIL, userInfo.getvCardEmail());
        editor.putString(HOST, userInfo.getHost());
        editor.putString(USERPASSWORD, userInfo.getUserPassword());
        editor.putString(DOMAIN, userInfo.getDomain());
        editor.putInt(PORT, userInfo.getPort());

        editor.commit();

    }
    
    public static void saveUserPassword(String password, Context context) {
        SharedPreferences preferences = context.getSharedPreferences(LBSPREFERENCES, Context.MODE_PRIVATE);
        Editor editor = preferences.edit();

        editor.putString(USERPASSWORD, password);
        editor.commit();
    }
    
    public static void saveUserNick(String user, Context context) {
        SharedPreferences preferences = context.getSharedPreferences(LBSPREFERENCES, Context.MODE_PRIVATE);
        Editor editor = preferences.edit();

        editor.putString(USERNICK, user);
        editor.commit();
    }
    
    public static void saveUserId(String user, Context context) {
        SharedPreferences preferences = context.getSharedPreferences(LBSPREFERENCES, Context.MODE_PRIVATE);
        Editor editor = preferences.edit();

        editor.putString(USERID, user);
        editor.commit();
    }
    
    public static void saveUser(String user, Context context) {
        SharedPreferences preferences = context.getSharedPreferences(LBSPREFERENCES, Context.MODE_PRIVATE);
        Editor editor = preferences.edit();

        editor.putString(USERNAME, user);
        editor.commit();
    }
    
    
    public static void savevCardPhone(String phone, Context context) {
        SharedPreferences preferences = context.getSharedPreferences(LBSPREFERENCES, Context.MODE_PRIVATE);
        Editor editor = preferences.edit();

        editor.putString(VCARDPHONE, phone);
        editor.commit();
    }
    
    public static void savevCardEmail(String email, Context context) {
        SharedPreferences preferences = context.getSharedPreferences(LBSPREFERENCES, Context.MODE_PRIVATE);
        Editor editor = preferences.edit();

        editor.putString(VCARDEMAIL, email);
        editor.commit();
    }
    

    /**
     * get the saved joinedGroup names
     * @param context context of the application
     * @return the reasult of saved joinedGroup names
     */
    public static Set<String> getJoinedGroups(Context context) {
        Set<String> returnSet = new HashSet<String>();
        SharedPreferences preferences = context.getSharedPreferences(LBSPREFERENCES, Context.MODE_PRIVATE);

        String jsons = preferences.getString(JOINEDGROUP, NA);
        try {
            JSONArray jsonArray = new JSONArray(jsons);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                returnSet.add(jsonObject.getString(GROUPNAME));
            }
        } catch (JSONException e) {
            Log.d(LBSPREFERENCES, "getJoinedGroups");
            return new HashSet<String>();
        }

        return returnSet;
    }

    /**
     * 
     * update the saved joinedGroup names
     * @param groupName the groupName will be added or deleted
     * @param operate add or delete
     * @param context context of the application
     */
    public static void saveJoinedGroups(String groupName, String operate, Context context) {
        SharedPreferences preferences = context.getSharedPreferences(LBSPREFERENCES, Context.MODE_PRIVATE);
        Editor editor = preferences.edit();

        Set<String> set = getJoinedGroups(context);

        if (ADD.equals(operate)) {
            set.add(groupName);
        } else if (DELETE.equals(operate)) {
            set.remove(groupName);
        }

        JSONArray jsonArray = new JSONArray();
        for (String string : set) {
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put(GROUPNAME, string);
                jsonArray.put(jsonObject);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        editor.putString(JOINEDGROUP, jsonArray.toString());
        editor.commit();

    }
    
    
    public static void getShareLocationHour(String start, String end, Context context) {
         SharedPreferences preferences = context.getSharedPreferences(LBSPREFERENCES, Context.MODE_PRIVATE);

         start = preferences.getString(SHARESTARTHOUR, NA);
         end = preferences.getString(SHAREENDHOUR, NA);
    }

    public static void saveShareLocationHour(String start, String end, Context context) {
        SharedPreferences preferences = context.getSharedPreferences(LBSPREFERENCES, Context.MODE_PRIVATE);
        Editor editor = preferences.edit();
        
        editor.putString(SHARESTARTHOUR, start);
        editor.putString(SHAREENDHOUR, end);
        editor.commit();
   }
}
