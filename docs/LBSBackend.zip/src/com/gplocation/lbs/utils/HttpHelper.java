// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.utils;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

/**
 * @brief get message through http
 */
public class HttpHelper {

    public static String httpGet(String url) {
        HttpGet httpGet = new HttpGet(url);
        HttpResponse httpResponse = null;
        String result = "";
        try {
            httpResponse = new DefaultHttpClient().execute(httpGet);
            if (httpResponse.getStatusLine().getStatusCode() == 200) {
                result = EntityUtils.toString(httpResponse.getEntity());
            }
        } catch (Exception e) {
            return "http request error!";
        }
        return result;
    }

    public static String httpPost(String url) {
        HttpGet httpGet = new HttpGet(url);

        HttpResponse httpResponse = null;
        String result = "";
        try {
            httpResponse = new DefaultHttpClient().execute(httpGet);
            if (httpResponse.getStatusLine().getStatusCode() == 200) {
                result = EntityUtils.toString(httpResponse.getEntity());
            }
        } catch (Exception e) {
            return "http request error!";
        }

        return result;
    }
}
