// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.utils;

public class Constants {

	public static final int CONNECTION_UNKNOWN = 0;
    public static final int CONNECTION_CONNECTED = 1;
    public static final int CONNECTION_FAILED = 2;
    public static final int CONNECTION_DISCONNECTED = 3;

    public static final int PRESENCE_OFFLINE = 0;
    public static final int PRESENCE_ONLINE = 1;
    
    public static final int RETURN_SUCCESS = 0;
    public static final int RETURN_EXIST = 1;
    public static final int RETURN_FAILED = 2;

    public static final int OPERATE_SUCCESS = 1;
    public static final int OPERATE_FAILED = 2;
    
    public static final int APP_LBS_CLIENT = 0;
    
    public static final int LOCATION_IN_FRIEND = 0;
    public static final int LOCATION_IN_GROUP = 1;
    
    
    public static final int MESSAGE_INTERAL_DESTORY = 0;
    
    // message types, in Message.getData().getInt("type") internal type just used in backend own
    public static final int MESSAGE_INTERAL_TYPE = 1;
    public static final int MESSAGE_GENERAL_TYPE = 2;
    public static final int MESSAGE_FRIEND_TYPE = 3;
    public static final int MESSAGE_GROUP_TYPE = 4;
    public static final int MESSAGE_PUBSUB_TYPE = 5;

    
    public static final int WITH_LOCATION_TYPE_CONTAIN = 0;
    public static final int WITH_LOCATION_TYPE_CONTAIN_NO = 1;
    public static final int WITH_LOCATION_TYPE_CONTAIN_MSG = 2;
    
    
    
    public static final String DEFAULT_PHONE_TYPE = "VOICE";
    public static final int DEFAULT_SHARING_LOCATION_SECOND = 20;
    public static final int DEFAULT_GROUP_SETTING_INTERVAL = 2;
    public static final String DEFAULT_USER_DOMAIN = "@motolbs.com";
    public static final String DEFAULT_CONFERENCE_SERVICE = "@conference.motolbs.com";
    public static final String DEFAULT_APPID = "1234567890";
    public static final String DEFAULT_PORTAL_SERVICE = "";
    
    public static final String DEFAULT_CHARSET = "UTF-8";
    
    
    public static final String USER_REGISTER_ACTION = "register";
    public static final String USER_LOGIN_ACTION = "login";
    
    //SERVICE_ACTION
    public static final String GERNERAL_SERVICE_ACTION = "com.gplocation.lbs.client.IGeneral";
    public static final String FRIEND_SERVICE_READ_ACTION = "com.gplocation.lbs.client.friend.IFriend";
    public static final String FRIEND_SERVICE_WRITE_ACTION = "com.gplocation.lbs.client.friend.IOperateFriend";
    public static final String GROUP_SERVICE_READ_ACTION = "com.gplocation.lbs.client.group.IGroup";
    public static final String GROUP_SERVICE_WRITE_ACTION = "com.gplocation.lbs.client.group.IOperateGroup";
    public static final String PUBSUB_SERVICE_PUBLISTH_ACTION = "com.gplocation.lbs.client.pubsub.IPublish";
    public static final String PUBSUB_SERVICE_SUBSCRIBE_ACTION = "com.gplocation.lbs.client.pubsub.ISubscribe";
    public static final String INTERAL_ACTION = "com.gplocation.lbs.client.internal.IInternal";
    
    
    
    public static final String CLIENT_ACTION_ADD_FRIEND = "addFriend";
    public static final String CLIENT_ACTION_REMOVE_FRIEND = "remvoeFriend";
    public static final String CLIENT_ACTION_CREATE_GROUP = "createGroup";
    public static final String CLIENT_ACTION_REMOVE_GROUP = "removeGroup";
    public static final String CLIENT_ACTION_EXIT_GROUP = "exitGroup";
    
    public static final String CLIENT_ACTION_INVITE_USER_INTO_GROUP = "inviteUserIntoGroup";
    public static final String CLIENT_ACTION_JOIN_GROUP = "joinGroup";
    public static final String CLIENT_ACTION_REMOVE_MEMBER_FROM_GROUP = "removeMemberFromGroup";
    public static final String CLIENT_ACTION_SET_MEMBER_AS_OWNER = "setMemberAsOwner";
    
    public static final String NOTIFY_UPDATE_GROUP_SETTING = "UpdateGroupSetting";
    public static final String NOTIFY_START_SHARING_IN_GROUP = "StartSharing";
    public static final String NOTIFY_STOP_SHARING_IN_GROUP = "EndSharing";
    public static final String NOTIFY_INVITE_USER_INTO_GROUP = "InviteYouToJoinIn";
    public static final String NOTIFY_START_EXCUTE_GROUP_SETTING = "StartExcuteGroupSetting";
    public static final String NOTIFY_STOP_EXCUTE_GROUP_SETTING = "StopExcuteGroupSetting";
}
