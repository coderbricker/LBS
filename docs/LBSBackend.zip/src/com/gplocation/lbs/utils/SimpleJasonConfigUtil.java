package com.gplocation.lbs.utils;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

/**
 * This util used to manage the config string with jason. In fact, we should
 * user official jason lib to parse. but at present, we use this tools
 * temporarily.
 * 
 * @author xingqisheng
 * 
 */
public final class SimpleJasonConfigUtil {
	public static final class SimpleJason {
		/**
		 * we user this map to contain our properties. so it means nesting
		 * property is not allowed.
		 */
		private Map<String, String> propMap = new HashMap<String, String>();

		public SimpleJason() {

		}

		public SimpleJason(String str) {
			parse(str);
		}

		public void parse(String str) {
			if (str != null && str.length() > 2) {
				String content = str.substring(1, str.length() - 1);
				String[] props = content.split(";");
				if (props != null && props.length > 0) {
					for (String prop : props) {
						String[] kv = prop.split(":");
						propMap.put(kv[0], kv[1]);
					}
				}
			}
		}

		public void set(String key, String value) {
			if (value == null) {
				propMap.remove(key);
			}
			propMap.put(key, value);
		}

		public String get(String key) {
			return propMap.get(key);
		}

		public Set<String> keySet() {
			return propMap.keySet();
		}

		@Override
		public String toString() {
			StringBuilder sb = new StringBuilder("{");
			Set<Entry<String, String>> entries = propMap.entrySet();
			for (Entry<String, String> en : entries) {
				sb.append(en.getKey()).append(":");
				sb.append(en.getValue()).append(";");
			}
			if (sb.length() > 1) {
				sb.deleteCharAt(sb.length() - 1);
			}
			sb.append("}");
			return sb.toString();
		}

	}

}
