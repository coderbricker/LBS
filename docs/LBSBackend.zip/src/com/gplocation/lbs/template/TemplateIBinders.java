// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.template;

import java.util.HashMap;


/**
 * Template listeners, contains one type of general, friend, group, pubsub IBinder.
 * @param <T> one type of friend, group, pubsub IBinder.
 */
public class TemplateIBinders<T> {
	
	@SuppressWarnings("unused")
	private static final String TAG = "TemplateIBinders";
	
	private HashMap<String, T> binders = new HashMap<String, T>();
	
	public TemplateIBinders() {
		
	}
	
	/**
	 * <p>Add a new binder bound with appId, the new binder will replace the older one</P>
	 * @param listener
	 * @param appId
	 * @return
	 */
	public void add(T binder, String appId) {
		binders.put(appId, binder); // new listener will replace the older one
	}
		
	public void removeAll() {
		binders.clear();
	}
	
	public void remove(String appId) {
		binders.remove(appId);		
	}
	
	public boolean contain(String appId) {
		return binders.containsKey(appId);
	}

	public T get(String appId) {
		return binders.get(appId);
	}

	public HashMap<String, T> getBinders() {
		return binders;
	}

}
