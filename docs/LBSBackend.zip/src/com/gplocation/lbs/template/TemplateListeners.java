// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.template;

import java.util.HashMap;

import android.util.Log;


/**
 * Template listeners, contains one type of general, friend, group, pubsub listener.
 * @param <T> one type of general, friend, group, pubsub listener.
 */
public class TemplateListeners<T> {
	
	private static final  String TAG = "TemplateListeners";
	
	public static class TemplateSubListener<T> {
		public T listener;
		public int count = 0; // the listener's count
		
		public TemplateSubListener(T listener) {
			this.listener = listener;
			count = 0;
		}
	}
	
	private HashMap<String, TemplateSubListener<T>> listeners = new HashMap<String, TemplateSubListener<T>>();
	
	public TemplateListeners() {
		
	}
	
	/**
	 * <p>Add a new listener bound with appId, the new listener will replace the older one</P>
	 * @param listener
	 * @param appId
	 * @return
	 */
	public void add(T listener, String appId) {
		if (listeners.get(appId) != null) {
			listeners.get(appId).listener = listener; // new listener will replace the older one
		} else {
			TemplateSubListener<T> subListener = new TemplateSubListener<T>(listener); 
			listeners.put(appId, subListener);
		}
		
		listeners.get(appId).count++;
		Log.d(TAG, "listeners add" + appId + "count=" + listeners.get(appId).count);
	}
		
	public void remove(String appId) {
		if (listeners.get(appId) != null) {
			listeners.get(appId).count--;
			Log.d(TAG, "listeners remove" + appId + "count=" + listeners.get(appId).count);
			
			if (listeners.get(appId).count <= 0) {
				
				Log.d(TAG, "listeners remove" + appId);
				listeners.remove(appId);
			}
		} 
		
	}
	
	public boolean contain(String appId) {
		return listeners.containsKey(appId);
	}

	public T get(String appId) {
		return listeners.get(appId).listener;
	}


	public HashMap<String, TemplateSubListener<T>> getListeners() {
		return listeners;
	}


	public void setListeners(HashMap<String, TemplateSubListener<T>> listeners) {
		this.listeners = listeners;
	}

}
