package com.gplocation.lbs.application;

import android.app.Application;
import android.util.Log;

import com.gplocation.lbs.data.LBSUser;
import com.gplocation.lbs.datamanager.FriendManager;
import com.gplocation.lbs.datamanager.GroupManager;
import com.gplocation.lbs.datamanager.GroupSettingManager;
import com.gplocation.lbs.datamanager.IconManager;
import com.gplocation.lbs.datamanager.ThirdAppManager;

/**
 * main application for this application,all of the application can get and use it
 */
public class MainApplication extends Application {
	private static final String TAG = "MainApplication";
	
	public LBSUser userInfo;
	public FriendManager friendManager = FriendManager.getInstance();
	public GroupManager groupManager = GroupManager.getInstance();
	public GroupSettingManager groupSettingManager = GroupSettingManager.getInstance();
	public ThirdAppManager thirdAppManager = ThirdAppManager.getInstance();
	public IconManager iconManager = IconManager.getInstance();

	@Override
	public void onCreate() {
		super.onCreate();
		Log.d(TAG, "Client MainApplication onCreate");
	}
}
