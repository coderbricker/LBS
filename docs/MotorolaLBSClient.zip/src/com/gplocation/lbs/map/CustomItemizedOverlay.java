// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.map;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.Log;

import com.baidu.mapapi.map.ItemizedOverlay;
import com.baidu.mapapi.map.MapView;
import com.baidu.mapapi.map.OverlayItem;
/**
 * an extend ItemizedOverlay for the unit of the map item
 */
public class CustomItemizedOverlay extends ItemizedOverlay<OverlayItem> {
    private final static String TAG = "CustomItemizedOverlay";
	
    private ArrayList<OverlayItem> mapOverlays = new ArrayList<OverlayItem>();
    private ArrayList<Boolean> onTapBool = new ArrayList<Boolean>();
    
    @SuppressWarnings("unused")
	private Context context;
    private String userName;
    
    
    public String getUserName() {
        return userName;
    }

    public CustomItemizedOverlay(Drawable defaultMarker, MapView mapview) {
        super(defaultMarker,mapview);
    }

    public CustomItemizedOverlay(Drawable defaultMarker, Context context, String userName,MapView mapview) {
        this(defaultMarker,mapview);
        this.context = context;
        this.userName = userName;
    }
    public CustomItemizedOverlay(Drawable defaultMarker, Context context,MapView mapview) {
        this(defaultMarker,mapview);
        this.context = context;
    }

    @Override
    protected OverlayItem createItem(int i) {
        return mapOverlays.get(i);
    }

    @Override
    public int size() {
        return mapOverlays.size();
    }

//    @Override
//    public void draw(Canvas canvas, MapView mapView, boolean shadow) {
//    	Log.d(TAG, "draw");
//    	
//    	Projection projection = mapView.getProjection(); 
//		for (int index = size() - 1; index >= 0; index--) {
//			if (onTapBool.get(index)) {
//				OverlayItem overLayItem = getItem(index); 
//	
//				String title = overLayItem.getSnippet();
//				Point point = projection.toPixels(overLayItem.getPoint(), null); 
//	
//				Paint paintText = new Paint();
//				paintText.setColor(Color.BLUE);
//				paintText.setTextSize(15);
//				canvas.drawText(title, point.x - 38, point.y + 10, paintText);
//			}
//		}
//    	
//    	super.draw(canvas, mapView, shadow);
//    }
    
    @Override
    protected boolean onTap(int index) {  
    	Log.d(TAG, "onTap");
    	boolean onTapValue = onTapBool.get(index);
    	onTapBool.set(index, !onTapValue);
    	
//        OverlayItem item = mapOverlays.get(index);
        
//        LayoutInflater inflater = ((Activity) context).getLayoutInflater();
//    	final Dialog dialog = new Dialog(context, R.style.Dialog_No_Title);
//    	
//		View view = inflater.inflate(R.layout.dialog, null);
//		dialog.setContentView(view);
//		
//		TextView titleView = (TextView) view.findViewById(R.id.dialog_title);
//		TextView msgView = (TextView) view.findViewById(R.id.dialog_message);
//		
//		titleView.setText(item.getTitle());
//		msgView.setText(item.getSnippet());
//		
//		Button okBtn = (Button) view.findViewById(R.id.dialog_signle_ok_btn);
//		okBtn.setVisibility(View.VISIBLE);
//		okBtn.setOnClickListener(new OnClickListener() {
//			@Override
//			public void onClick(View v) {
//				dialog.dismiss();
//			}
//		});
//		
//		view.findViewById(R.id.dialog_layout_two_button).setVisibility(View.GONE);
//		
//		dialog.show();
		
//        ((LBSClientMainActivity) context).popupSingleButtonDialog(item.getTitle(),
//        		item.getSnippet()).show();
        return true;
    }

    public void addOverlay(OverlayItem overlay) {
        mapOverlays.add(overlay);
        onTapBool.add(false);
    }

}
