// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.tabs;

import java.util.ArrayList;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.RemoteException;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.gplocation.lbs.R;
import com.gplocation.lbs.activity.LBSClientMainActivity;
import com.gplocation.lbs.activity.ShowMapActivity;
import com.gplocation.lbs.application.MainApplication;
import com.gplocation.lbs.data.Friend;
import com.gplocation.lbs.data.GeoLocation;
import com.gplocation.lbs.datamanager.DataObserver;
import com.gplocation.lbs.datamanager.FriendManager;
import com.gplocation.lbs.datamanager.FriendManager.FriendStatus;
import com.gplocation.lbs.engine.ShareLocationEngine;
import com.gplocation.lbs.listadapter.FriendDetailAdapter;
import com.gplocation.lbs.listadapter.FriendsListAdapter;
import com.gplocation.lbs.utils.ConstantData;

/**
 * the Friend Tab
 */
public class TabFriends implements DataObserver {
	
	private static final String TAG = "TabFriends";
	
    private Context context;
    private ListView listView;
    private FriendsListAdapter adapter;
    
    private Dialog showFriendDialog;
    private Friend showFriend;

    public TabFriends(Context context) {
        this.context = context;
        initView();
    }
    

	@Override
	public void init() {
		
	}

	@Override
	public void update() {
		MainApplication mainApplication = (MainApplication) ((LBSClientMainActivity) context)
				.getApplication();
		final FriendManager friendManager = mainApplication.friendManager;
		if (showFriend != null && friendManager.contain(showFriend.getAccount()) < 0) {
			showFriendDialog.dismiss();
			showFriend = null;
		}
	}

    /**
     * initial ListView and its adapter
     */
    private void initView() {
        listView = (ListView) ((LBSClientMainActivity) context).findViewById(R.id.listView);
        listView.setOnItemClickListener(new OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int position, long id) {
                Friend friend = adapter.getFriendsList().get(position);
                FriendStatus friendStatus = adapter.getFriendsStatus().get(position);
                adapter.notifyDataSetChanged();
                showFriendDialog = getFriendOptDialog((LBSClientMainActivity) context, friend, friendStatus);
                showFriendDialog.show();
                showFriend = friend;
            }

        });

        adapter = new FriendsListAdapter(context);
        MainApplication mainApplication = (MainApplication) ((LBSClientMainActivity) context).getApplication();
        final FriendManager friendManager = mainApplication.friendManager;
        friendManager.registerObserver(adapter);
        
        listView.setAdapter(adapter);
        
        friendManager.registerObserver(this);
    }

    
    private Dialog getFriendOptDialog(final LBSClientMainActivity ctx, final Friend friend, 
    		final FriendStatus friendStatus) {
        final String account = friend.getAccount();
        // full screen dialog
        final Dialog friendDetailDialog = new Dialog(ctx, R.style.Dialog_Fullscreen);
      	
    	LayoutInflater inflater = ctx.getLayoutInflater();
        View friendDetailView = inflater.inflate(R.layout.friend_detail, null);
        friendDetailDialog.setContentView(friendDetailView);
        
        TextView nick = (TextView) friendDetailView.findViewById(R.id.friend_detail_nick);
        nick.setText(friend.getNickName());
        
        
        String information = "";
        boolean hasEmail = false;
        if (friend.getEmail() != null && !"".equals(friend.getEmail())) {
        	information += ctx.getString(R.string.register_email) + " " + friend.getEmail();
        	hasEmail = true;
        }
        
        if (friend.getPhone() != null && !"".equals(friend.getPhone())) {
        	if (hasEmail) {
        		information += "\n";
        	}
        	information += ctx.getString(R.string.register_mobile) + " " + friend.getPhone();
        }
                
        TextView info = (TextView) friendDetailView.findViewById(R.id.friend_detail_text);
        info.setText(information);
        
        ListView listView = (ListView) friendDetailView.findViewById(R.id.friend_detail_list);
        final FriendDetailAdapter friendAdapter = new FriendDetailAdapter(ctx);
        listView.setAdapter(friendAdapter);
        
        friendAdapter.setFollowCheck(friendStatus.follow);
        friendAdapter.setShareContinuouslyCheck(friendStatus.shareContinuous);
        
        
        listView.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View view, int position,
					long id) {
				switch(position) {
				case ConstantData.MENU_SHARELOCATION:                        
                    try {
						ctx.iFriend.shareLocation(account, false, 0);
					} catch (RemoteException e) {
						e.printStackTrace();
					}
                    break;
                    
                case ConstantData.MENU_REQUESTLOCATION:
                	try {
						ctx.iFriend.requestLocation(account);
					} catch (RemoteException e) {
						e.printStackTrace();
					}    
                	friendStatus.request = true;
                    break;
                    
                case ConstantData.MENU_FOLLOWLOCATION:
                	// todo
                	// if the person is not agree your follow request, the check box should uncheck automatically
                	try {
	                	if (friendAdapter.getFollowCheck()) {
	                		ctx.iFriend.stopFollowLocation(account);
	                		friendAdapter.setFollowCheck(false);
	                		friendStatus.follow = false;
	                	} else {
	                		ctx.iFriend.followLocation(account);
	                		friendAdapter.setFollowCheck(true);
	                		friendStatus.follow = true;
	                	}						
					} catch (RemoteException e) {
						e.printStackTrace();
					}
                    break;

                case ConstantData.MENU_SHARECONTINUSE:
                	if (friendStatus.shareContinuous) {
                		Log.d(TAG, "stop sharing");
                    	try {
    						((LBSClientMainActivity) context).iFriend.stopSharingLoaction(account);
    					} catch (RemoteException e) {
    						e.printStackTrace();
    					}
                    	
                    	friendStatus.shareContinuous = false;
                    	friendAdapter.setShareContinuouslyCheck(false);
                	} else {
                    	ShareLocationEngine.shareContinously(ctx, account);
                		friendStatus.shareContinuous = true;
                		friendAdapter.setShareContinuouslyCheck(true);
                	}
                	
                	adapter.notifyDataSetChanged();
                    break;
                default:
                    break;
				}
			}
		});
        
        
        Button posBtn = (Button) friendDetailView.findViewById(R.id.friend_detail_location);
        if (friendStatus.location != null) {
	        posBtn.setText(ctx.getString(R.string.location_head) + " (" 
	        		+ friendStatus.location.getLongitude() + "," 
	        		+ friendStatus.location.getLatitude() +	")");
        } else {
	        posBtn.setText(ctx.getString(R.string.location_head));
        }
        
        posBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				GeoLocation location = friendStatus.location;
				 if (location != null) {
					 friendStatus.locationCome = false;
					 
					 Intent intent = new Intent(context, ShowMapActivity.class);
					 intent.putExtra("account", account);
					 intent.putExtra("location", location);
					 try {
						 ((LBSClientMainActivity) (context)).startActivityForResult(intent, 
								 ConstantData.REQUEST_MAP_ACTIVITY);
					 } catch (Exception e) {
						 Toast.makeText(context, e.getMessage(), Toast.LENGTH_LONG).show();
					 }
				 }
			}
		});
        
        Button removeBtn = (Button) friendDetailView.findViewById(R.id.friend_detail_remove);
        removeBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				LayoutInflater layoutInflater = (LayoutInflater) ctx.getLayoutInflater();
				final Dialog dialog = new Dialog(ctx, R.style.Dialog_No_Title);
		    	
				View view = layoutInflater.inflate(R.layout.dialog, null);
				dialog.setContentView(view);
				dialog.show();
				
				
				TextView titleView = (TextView) view.findViewById(R.id.dialog_title);
				TextView msgView = (TextView) view.findViewById(R.id.dialog_message);
				
				titleView.setText(ctx.getString(R.string.deletePrompting));
				msgView.setText(R.string.deleteConfirmMessage);
				
				Button okBtn = (Button) view.findViewById(R.id.dialog_ok);
				okBtn.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						dialog.dismiss();
						friendDetailDialog.dismiss();
						try {
							ctx.iOperateFriend.removeFriend(account);
						} catch (RemoteException e) {
							e.printStackTrace();
						}
					}
				});
				
				
				Button cancelBtn = (Button) view.findViewById(R.id.dialog_cancel);
				cancelBtn.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {
						dialog.dismiss();
					}
				});
			}
		});
        
        
        return friendDetailDialog;
    }

    
    /**
     * called when new location come
     * @param location new location 
     * @param shareContinusly is share continusly 
     * @param newLocationCome is first come to the map
     */
    public void updateFriendLocation(String friendId, final GeoLocation location) {
        if (adapter != null) {
            ArrayList<Friend> friendsList = (ArrayList<Friend>) adapter.getFriendsList();
            ArrayList<FriendStatus> friendStutsList = (ArrayList<FriendStatus>) adapter.getFriendsStatus();
            for (int i = 0; i < friendsList.size(); ++ i) {
            	if (friendsList.get(i).getAccount().equals(friendId)) {
            		if ((friendStutsList.get(i).agreeRequest || friendStutsList.get(i).agreeFollow) 
            				&& !((LBSClientMainActivity) (context)).showMap) {
            			Intent intent = new Intent(context, ShowMapActivity.class);
                        intent.putExtra("account", friendId);
                        intent.putExtra("location", location);
                        try {
                            ((LBSClientMainActivity) (context)).startActivityForResult(intent,
                                ConstantData.REQUEST_MAP_ACTIVITY);
                        } catch (Exception e) {
                        	e.printStackTrace();
                        }
            		

                        ((LBSClientMainActivity) (context)).showMap = true;
                        friendStutsList.get(i).locationCome = false;
            		}
            		
            		
            		// send broadcast
            		Intent broadcast = new Intent();
                    broadcast.putExtra("account", friendId);
                    broadcast.putExtra("location", location);
                    broadcast.setAction("cn.com.lbs.location");
                    context.sendBroadcast(broadcast);
            		break;
            	}
            
            }
            adapter.notifyDataSetChanged();
        }
    }

    public void setmListView(ListView mListView) {
        this.listView = mListView;
    }

    public ListView getmListView() {
        return listView;
    }
    
    public FriendsListAdapter getmAdapter() {
        return adapter;
    }

}
