// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.tabs;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.RemoteException;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.TimePicker;

import com.gplocation.lbs.R;
import com.gplocation.lbs.activity.GroupShowMapActivity;
import com.gplocation.lbs.activity.LBSClientMainActivity;
import com.gplocation.lbs.application.MainApplication;
import com.gplocation.lbs.data.Friend;
import com.gplocation.lbs.data.GeoLocation;
import com.gplocation.lbs.data.Setting;
import com.gplocation.lbs.datamanager.DataObserver;
import com.gplocation.lbs.datamanager.Group;
import com.gplocation.lbs.datamanager.GroupAddUser;
import com.gplocation.lbs.datamanager.GroupLocation;
import com.gplocation.lbs.datamanager.GroupLocation.UserLocation;
import com.gplocation.lbs.datamanager.GroupManager;
import com.gplocation.lbs.datamanager.GroupSettingManager;
import com.gplocation.lbs.datamanager.GroupSettingManager.GroupSetting;
import com.gplocation.lbs.listadapter.GroupAddUserAdapter;
import com.gplocation.lbs.listadapter.GroupListAdapter;
import com.gplocation.lbs.listadapter.GroupMembersListAdapter;
import com.gplocation.lbs.utils.ConstantData;

/**
 * the group tap
 */
public class TabGroup implements DataObserver {

	private static final String TAG = "TabGroup";
    private Context context;
    private ListView listView;
    private GroupListAdapter adapter;
    @SuppressWarnings("unused")
	private Dialog dialog;
    private GroupManager groupManager;
    @SuppressWarnings("unused")
	private GroupSettingManager groupSettingManager;
    private Dialog groupDetailDialog;
    
    private ListView showGroupMembers;
    private String showGroupId;
    private ImageView showArrowImageView;
    private View showListViewLayout;
    private View showListDivider;
    
    // dialog
    private ImageView shareLocationImageView;

    public TabGroup(final Context context) {
        this.context = context;
        MainApplication mainApplication = (MainApplication) ((LBSClientMainActivity) context).getApplication();
        this.groupManager = mainApplication.groupManager;
        this.groupSettingManager = mainApplication.groupSettingManager;
        
        groupManager.registerObserver(this);
        initView();
    }

    

	@Override
	public void init() {
		
	}
	
	 

	@Override
	public void update() {
		final Group group = groupManager.getGroup(showGroupId);
		if (group == null) {
			if (groupDetailDialog != null) {
				groupDetailDialog.dismiss();
			}
		} else {
			if (showGroupMembers != null) {
	            showListDivider.setVisibility(View.VISIBLE);
	            showArrowImageView.setBackgroundResource(R.drawable.group_arrow);
	            group.setShowMembers(false);
	            showListViewLayout.setVisibility(View.GONE);
	            
	            //            
	//			float itemPx = context.getResources().getDimensionPixelSize(
	//            		R.dimen.group_member_item_height);
	//			showGroupMembers.getLayoutParams().height = (int) itemPx 
	//	         		* groupManager.getGroup(showGroupId).getMembers().size();
			}
			
			 
	        if (group.isShared() && shareLocationImageView != null) {
	            shareLocationImageView.setBackgroundResource(R.drawable.checkbox_selected);
	        } else {
	            shareLocationImageView.setBackgroundResource(R.drawable.checkbox);
	        }
		}
	}
	
    /**
     * init expandableListView and map
     */
    private void initView() {
        listView = (ListView) ((LBSClientMainActivity) context).findViewById(R.id.grouplistView);

        adapter = new GroupListAdapter(context);
        groupManager.registerObserver(adapter);
        listView.setAdapter(adapter);

        //pop group detail window
        listView.setOnItemClickListener(new OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                LayoutInflater inflater = ((Activity) context).getLayoutInflater();
                final View groupDetailView = inflater.inflate(R.layout.group_detail, null);
                groupDetailDialog = new Dialog(context, R.style.Dialog_Fullscreen);

                TextView groupName = (TextView) groupDetailView.findViewById(R.id.group_detail_groupname);
                TextView description = (TextView) groupDetailView.findViewById(R.id.group_detail_groupdescription);

                final Group group = groupManager.getGroupMembers().get(arg2);

                final String groupIdString = group.getGroupInfo().getGroupId();
                showGroupId = groupIdString;
                
                final String userId = ((MainApplication) ((LBSClientMainActivity) context)
                		.getApplication()).userInfo.getUserId();

                groupName.setText(group.getGroupInfo().getGroupName());
                description.setText(group.getGroupInfo().getGroupDescription());
                // init shared state
                shareLocationImageView = (ImageView) groupDetailView
                    .findViewById(R.id.group_sharelocation_check);
                if (group.isShared()) {
                    shareLocationImageView.setBackgroundResource(R.drawable.checkbox_selected);
                } else {
                    shareLocationImageView.setBackgroundResource(R.drawable.checkbox);
                }

                // group members
                View arrowLayout = groupDetailView.findViewById(R.id.group_arrow_layout);
                
                showArrowImageView = (ImageView) groupDetailView.findViewById(R.id.group_arrow);
                showListViewLayout = groupDetailView.findViewById(R.id.group_member_list_layout);
                showListDivider = groupDetailView.findViewById(R.id.group_member_list_divider);
                
                arrowLayout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View arg0) {

                        if (group.isShowMembers()) {
                        	showListDivider.setVisibility(View.VISIBLE);
                        	showArrowImageView.setBackgroundResource(R.drawable.group_arrow);
                            group.setShowMembers(false);
                            showListViewLayout.setVisibility(View.GONE);
                        } else {
                        	showListDivider.setVisibility(View.GONE);
                        	showArrowImageView.setBackgroundResource(R.drawable.group_arrow_unfold);
                            group.setShowMembers(true);
                            showListViewLayout.setVisibility(View.VISIBLE);

                            showGroupMembers = (ListView) showListViewLayout.findViewById(R.id.group_members_list);

                            GroupMembersListAdapter groupMembersListAdapter = new GroupMembersListAdapter(
                                groupIdString, context);
                            groupManager.registerObserver(groupMembersListAdapter);
                            showGroupMembers.setAdapter(groupMembersListAdapter);
                            
                            float itemPx = context.getResources().getDimensionPixelSize(
                            		R.dimen.group_member_item_height);
                            Log.d(TAG, "itmePx=" + itemPx);
                            
                            showGroupId = groupIdString;                            		
                            showGroupMembers.getLayoutParams().height = (int) itemPx 
                            		* groupManager.getGroup(groupIdString).getMembers().size();
                            
                           
//                            if (groupManager.getGroup(groupIdString).getMembers().size() < 2) {
//                            	groupMembers.getLayoutParams().height = 70;
//                            }
                        }
                    }
                });

                // group share location
                View shareLocationLayout = groupDetailView.findViewById(R.id.group_sharelocation);
                shareLocationLayout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (group.getOwners().contains(userId)) {
                            ImageView shareLocationImageView = (ImageView) v
                                .findViewById(R.id.group_sharelocation_check);

                            // for test
//                            GroupInfo info = group.getGroupInfo();
//                            info.setGroupDescription("this is a test");
//                            info.setGroupName("test");
//                            try {
//								((LBSClientMainActivity) context).iOperateGroup.changeGroupInfo(groupIdString, info);
//							} catch (RemoteException e1) {
//								e1.printStackTrace();
//							}
                            
                            
                            if (group.isShared()) {
                                group.setShared(false);
                                shareLocationImageView.setBackgroundResource(R.drawable.checkbox);
                                try {
                                    ((LBSClientMainActivity) context).iGroup.stopExcuteGroupSetting(groupIdString,
                                        groupIdString);                                    
                                } catch (RemoteException e) {
                                    e.printStackTrace();
                                }
                            } else {
                                group.setShared(true);
                                shareLocationImageView.setBackgroundResource(R.drawable.checkbox_selected);
                                try {
                                    ((LBSClientMainActivity) context).iGroup.excuteGroupSetting(groupIdString,
                                        groupIdString);

                                } catch (RemoteException e) {
                                    e.printStackTrace();
                                }
                            }
                            groupManager.update();
                        } else {
                            final Dialog tempDialog = new Dialog(context, R.style.Dialog_No_Title);

                            LayoutInflater inflater1 = ((Activity) context).getLayoutInflater();
                            View dialogView = inflater1.inflate(R.layout.dialog, null);
                            TextView dialogTitle = (TextView) dialogView.findViewById(R.id.dialog_title);
                            TextView dialogMessage = (TextView) dialogView.findViewById(R.id.dialog_message);
                            View dialogLayoutTwoButton = dialogView.findViewById(R.id.dialog_layout_two_button);
                            Button dialogSignleOk = (Button) dialogView.findViewById(R.id.dialog_signle_ok_btn);

                            dialogTitle.setText(R.string.Prompt);
                            if (group.isShared()) {
                                dialogMessage.setText(R.string.group_only_owner_can_stop_share_location);
                            } else {
                                dialogMessage.setText(R.string.group_only_owner_can_start_share_location);
                            }
                            dialogLayoutTwoButton.setVisibility(View.GONE);
                            dialogSignleOk.setVisibility(View.VISIBLE);
                            dialogSignleOk.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View arg0) {
                                    if (tempDialog != null && tempDialog.isShowing()) {
                                        tempDialog.dismiss();
                                    }
                                }
                            });
                            tempDialog.setContentView(dialogView);
                            tempDialog.setCancelable(false);
                            tempDialog.show();
                        }

                    }
                });

                // group add user in this group
                View addUserLayout = groupDetailView.findViewById(R.id.group_add_user_in_this_group);
                addUserLayout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (group.getOwners().contains(userId)) {
                            getFriendListView(groupIdString);
                        } else {
                            final Dialog tempDialog = new Dialog(context, R.style.Dialog_No_Title);

                            LayoutInflater inflater1 = ((Activity) context).getLayoutInflater();
                            View dialogView = inflater1.inflate(R.layout.dialog, null);
                            TextView dialogTitle = (TextView) dialogView.findViewById(R.id.dialog_title);
                            TextView dialogMessage = (TextView) dialogView.findViewById(R.id.dialog_message);
                            View dialogLayoutTwoButton = dialogView.findViewById(R.id.dialog_layout_two_button);
                            Button dialogSignleOk = (Button) dialogView.findViewById(R.id.dialog_signle_ok_btn);

                            dialogTitle.setText(R.string.Prompt);
                            dialogMessage.setText(R.string.group_only_owner_can_add_user_in_this_group);
                            dialogLayoutTwoButton.setVisibility(View.GONE);
                            dialogSignleOk.setVisibility(View.VISIBLE);
                            dialogSignleOk.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View arg0) {
                                    if (tempDialog != null && tempDialog.isShowing()) {
                                        tempDialog.dismiss();
                                    }
                                }
                            });
                            tempDialog.setContentView(dialogView);
                            tempDialog.setCancelable(false);
                            tempDialog.show();
                        }
                    }
                });

                // group setting
                View groupSettingLayout = groupDetailView.findViewById(R.id.group_groupsetting);
                groupSettingLayout.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {

                        if (group.getOwners().contains(userId)) {
                            showGroupSetting(groupIdString, true);
                        } else {
                            showGroupSetting(groupIdString, false);
                        }
                    }
                });

                //remove or exit a group
                Button removeGroup = (Button) groupDetailView.findViewById(R.id.group_remove_group);
                if (group.getOwners().contains(userId)) { //owner remove group
                    removeGroup.setText(R.string.remove_group);
                    removeGroup.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            final Dialog tempDialog = new Dialog(context, R.style.Dialog_No_Title);

                            LayoutInflater inflater = ((Activity) context).getLayoutInflater();
                            View dialogView = inflater.inflate(R.layout.dialog, null);
                            TextView dialogTitle = (TextView) dialogView.findViewById(R.id.dialog_title);
                            TextView dialogMessage = (TextView) dialogView.findViewById(R.id.dialog_message);
                            Button dialogOk = (Button) dialogView.findViewById(R.id.dialog_ok);
                            Button dialogCancel = (Button) dialogView.findViewById(R.id.dialog_cancel);

                            dialogTitle.setText(R.string.Prompt);
                            dialogMessage.setText(String.format(
                            		context.getString(R.string.are_you_sure_remove_the_group),
                            		group.getGroupInfo().getGroupName()));
                            dialogOk.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View arg0) {
                                    try {
                                        ((LBSClientMainActivity) context).iOperateGroup.removeGroup(groupIdString);
                                    } catch (RemoteException e) {
                                        e.printStackTrace();
                                    }
                                    if (tempDialog != null && tempDialog.isShowing()) {
                                        tempDialog.dismiss();
                                    }
                                }
                            });
                            dialogCancel.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View arg0) {
                                    if (tempDialog != null && tempDialog.isShowing()) {
                                        tempDialog.dismiss();
                                    }
                                }
                            });
                            tempDialog.setContentView(dialogView);
                            tempDialog.setCancelable(false);
                            tempDialog.show();
                        }
                    });

                } else { // member exit a group
                    removeGroup.setText(R.string.exit_the_group);

                    removeGroup.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            final Dialog tempDialog = new Dialog(context, R.style.Dialog_No_Title);
                            LayoutInflater inflater = ((Activity) context).getLayoutInflater();
                            View dialogView = inflater.inflate(R.layout.dialog, null);
                            TextView dialogTitle = (TextView) dialogView.findViewById(R.id.dialog_title);
                            TextView dialogMessage = (TextView) dialogView.findViewById(R.id.dialog_message);
                            Button dialogOk = (Button) dialogView.findViewById(R.id.dialog_ok);
                            Button dialogCancel = (Button) dialogView.findViewById(R.id.dialog_cancel);

                            dialogTitle.setText(R.string.Prompt);
                            dialogMessage.setText(String.format(context.getString(R.string.are_you_sure_exit_the_group),
                            		group.getGroupInfo().getGroupName()));
                            dialogOk.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View arg0) {
                                    try {
                                        ((LBSClientMainActivity) context).iOperateGroup.exitGroup(groupIdString);
                                    } catch (RemoteException e) {
                                        e.printStackTrace();
                                    }
                                    if (tempDialog != null && tempDialog.isShowing()) {
                                        tempDialog.dismiss();
                                    }
                                }
                            });
                            dialogCancel.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View arg0) {
                                    if (tempDialog != null && tempDialog.isShowing()) {
                                        tempDialog.dismiss();
                                    }
                                }
                            });
                            tempDialog.setContentView(dialogView);
                            tempDialog.setCancelable(false);
                            tempDialog.show();
                        }
                    });

                }

                groupDetailDialog.setContentView(groupDetailView);
                groupDetailDialog.show();
            }
        });

    }

    public Dialog getGroupDetailDialog() {
        return groupDetailDialog;
    }

    /**
     * <p>update the map info a new location came from backend,called this for showing the new location in the map</P>
     * @param fromId
     * @param location
     */
    public void updateGroupLocationSharing(String fromId, final GeoLocation location) {

        String groupId = fromId.split("/")[0];
        String userName = fromId.split("/")[1];
        MainApplication mainApplication = (MainApplication) ((LBSClientMainActivity) context).getApplication();

        location.setFrom(userName);
        GroupLocation groupLocation = mainApplication.groupManager.getGroupLocations().get(groupId);
        if (groupLocation == null) {
            groupLocation = new GroupLocation(groupId);
            mainApplication.groupManager.getGroupLocations().put(groupLocation.getGroupId(), groupLocation);

            groupLocation.addNewLocation(new UserLocation(userName, location), context);

            mainApplication.groupManager.getGroup(groupId).setShared(true);
            mainApplication.groupManager.getGroup(groupId).setNewLocationCome(true);
            ((MainApplication) ((Activity) context).getApplication()).groupManager.update();

            if (!((LBSClientMainActivity) context).groupShowMap)  {
            	Intent intent = new Intent(context, GroupShowMapActivity.class);
	            intent.putExtra("groupId", groupId);
	            try {
	                ((Activity) (context)).startActivityForResult(intent, ConstantData.REQUEST_GROUPMAP_ACTIVITY);
	                ((LBSClientMainActivity) context).groupShowMap = true;
	                mainApplication.groupManager.getGroup(groupId).setNewLocationCome(false);
	            } catch (Exception e) {
	                e.printStackTrace();
	            }
            }
        }

        groupLocation.addNewLocation(new UserLocation(userName, location), context);
        Intent broadcast = new Intent();
        broadcast.putExtra("groupId", groupId);
        broadcast.putExtra("location", location);
        broadcast.setAction("cn.com.lbs.group.location");
        context.sendBroadcast(broadcast);
    }

    /**
     * <p>invite user into a group</P>
     * @param groupId
     */
    private void getFriendListView(final String groupId) {
        LayoutInflater inflater = ((LBSClientMainActivity) context).getLayoutInflater();
        View layoutView = inflater.inflate(R.layout.group_add_user, null);

        ListView listView = (ListView) layoutView.findViewById(R.id.group_add_user_list);

        Button addButton = (Button) layoutView.findViewById(R.id.group_add_user_add);
        Button cancelButton = (Button) layoutView.findViewById(R.id.group_add_user_cancel);

        final List<GroupAddUser> addUsers = new ArrayList<GroupAddUser>();

        MainApplication mainApplication = (MainApplication) ((LBSClientMainActivity) context).getApplication();
        Group group = mainApplication.groupManager.getGroup(groupId);

        List<Friend> friends = mainApplication.friendManager.getFriendList();

        

        for (int i = 0; i < friends.size(); ++i) {
            String account = friends.get(i).getAccount();
            if (group != null && group.getMember(account) == null) {
                addUsers.add(new GroupAddUser(friends.get(i)));
            }
        }

        
        if (addUsers.isEmpty()) {
            final Dialog tempDialog = new Dialog(context, R.style.Dialog_No_Title);

            LayoutInflater inflater1 = ((Activity) context).getLayoutInflater();
            View dialogView = inflater1.inflate(R.layout.dialog, null);
            TextView dialogTitle = (TextView) dialogView.findViewById(R.id.dialog_title);
            TextView dialogMessage = (TextView) dialogView.findViewById(R.id.dialog_message);
            View dialogLayoutTwoButton = dialogView.findViewById(R.id.dialog_layout_two_button);
            Button dialogSignleOk = (Button) dialogView.findViewById(R.id.dialog_signle_ok_btn);

            dialogTitle.setText(R.string.Prompt);
            dialogMessage.setText(R.string.no_friend);
            dialogLayoutTwoButton.setVisibility(View.GONE);
            dialogSignleOk.setVisibility(View.VISIBLE);
            dialogSignleOk.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View arg0) {
                    if (tempDialog != null && tempDialog.isShowing()) {
                        tempDialog.dismiss();
                    }
                }
            });
            tempDialog.setContentView(dialogView);
            tempDialog.setCancelable(false);
            tempDialog.show();
            return;
        }
        
        final GroupAddUserAdapter addUserAdapter = new GroupAddUserAdapter(addUsers, context);

        listView.setAdapter(addUserAdapter);
        listView.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View arg1, int position, long id) {
            	addUsers.get(position).setInvite(!addUsers.get(position).isInvite());
            	
            	addUserAdapter.notifyDataSetChanged();
            }

        });
        
        

        final Dialog tempDialog = new Dialog(context, R.style.Dialog_Fullscreen);
        tempDialog.setContentView(layoutView);
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (GroupAddUser addUser : addUsers) {
                    if (addUser.isInvite()) {
                        String friendJID = addUser.getFriend().getAccount();
                        try {
                            ((LBSClientMainActivity) context).iOperateGroup.inviteUser(groupId, friendJID);
                        } catch (RemoteException e) {
                            e.printStackTrace();
                        }
                    }
                }
                if (tempDialog != null && tempDialog.isShowing()) {
                    tempDialog.dismiss();
                }
            }
        });
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (tempDialog != null && tempDialog.isShowing()) {
                    tempDialog.dismiss();
                }
            }
        });
        tempDialog.show();
    }

    /**
     * <p>show group setting</P>
     * @param groupName
     * @param isOwner
     */
    private void showGroupSetting(final String groupId, boolean isOwner) {
        LayoutInflater inflater = ((LBSClientMainActivity) context).getLayoutInflater();
        View layoutView = inflater.inflate(R.layout.group_setting, null);
        final Dialog groupSettingialog = new Dialog(((LBSClientMainActivity) context), R.style.Dialog_Fullscreen);
        groupSettingialog.setContentView(layoutView);
        groupSettingialog.setTitle(context.getString(R.string.group_setting_info));
        groupSettingialog.show();

        MainApplication mainApplication = (MainApplication) ((LBSClientMainActivity) context).getApplication();
        Group group = mainApplication.groupManager.getGroup(groupId);
        String groupName = group.getGroupInfo().getGroupName();

        TextView groupNameText = (TextView) layoutView.findViewById(R.id.share_group_name);
        groupNameText.setText(groupName);

        TextView groupOwner = (TextView) layoutView.findViewById(R.id.share_group_owner);
        List<String> owners = group.getOwners();
        String ownerString = "";
        if (owners.size() > 0) {
            for (int i = 0; i < owners.size() - 1; ++i) {
                ownerString += owners.get(i) + "\n";
            }
            ownerString += owners.get(owners.size() - 1);
        }
        groupOwner.setText(ownerString);

        TextView groupDescription = (TextView) layoutView.findViewById(R.id.share_group_decription);
        groupDescription.setText(group.getGroupInfo().getGroupDescription());

        //start time & end time
        View startView = layoutView.findViewById(R.id.group_share_start_time_layout);
        View endView = layoutView.findViewById(R.id.group_share_end_time_layout);
        final TextView groupsetStartTime = (TextView) layoutView.findViewById(R.id.group_share_start_time);
        final TextView groupsetEndTime = (TextView) layoutView.findViewById(R.id.group_share_end_time);
        
        startView.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
//				popupTimePickDialog(R.string.group_setting).show();
				
				LayoutInflater inflater = ((Activity) context).getLayoutInflater();
		    	final Dialog dialog = new Dialog(context, R.style.Dialog_No_Title);
		    	
				View view = inflater.inflate(R.layout.time_pick_dialog, null);
				dialog.setContentView(view);
				
				TextView titleView = (TextView) view.findViewById(R.id.time_pick_dialog_title);
				final TimePicker timePicker = (TimePicker) view.findViewById(R.id.group_setting_time_pick);
				
				titleView.setText(R.string.group_setting);
				
				Button okBtn = (Button) view.findViewById(R.id.time_pick_dialog_ok);
				okBtn.setVisibility(View.VISIBLE);
				okBtn.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {	
						groupsetStartTime.setText(timePicker.getCurrentHour() + ":" + timePicker.getCurrentMinute());
						dialog.dismiss();
					}
				});
				
				Button cancelBtn = (Button) view.findViewById(R.id.time_pick_dialog_cancel);
				cancelBtn.setVisibility(View.VISIBLE);
				cancelBtn.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {	
						dialog.dismiss();
					}
				});
				
				dialog.show();
				
			}
		});
        
        endView.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				LayoutInflater inflater = ((Activity) context).getLayoutInflater();
		    	final Dialog dialog = new Dialog(context, R.style.Dialog_No_Title);
		    	
				View view = inflater.inflate(R.layout.time_pick_dialog, null);
				dialog.setContentView(view);
				
				TextView titleView = (TextView) view.findViewById(R.id.time_pick_dialog_title);
				final TimePicker timePicker = (TimePicker) view.findViewById(R.id.group_setting_time_pick);
				
				titleView.setText(R.string.group_setting);
				
				Button okBtn = (Button) view.findViewById(R.id.time_pick_dialog_ok);
				okBtn.setVisibility(View.VISIBLE);
				okBtn.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {	
						groupsetEndTime.setText(timePicker.getCurrentHour() + ":" + timePicker.getCurrentMinute());
						dialog.dismiss();
					}
				});
				
				Button cancelBtn = (Button) view.findViewById(R.id.time_pick_dialog_cancel);
				cancelBtn.setVisibility(View.VISIBLE);
				cancelBtn.setOnClickListener(new OnClickListener() {
					@Override
					public void onClick(View v) {	
						dialog.dismiss();
					}
				});
				
				dialog.show();
			}
		});
        
        
        final TextView groupsetIntervalTime = (TextView) layoutView.findViewById(R.id.share_group_interval_time);
        View view = layoutView.findViewById(R.id.share_group_interval_time_layout);
                
        final GroupSetting setting = mainApplication.groupSettingManager.get(groupId, groupId);

        if (setting != null) {
            String interval = setting.getSettingValue("interval");
            groupsetIntervalTime.setText(interval);
            
            groupsetStartTime.setText(setting.getSettingValue("startTime"));
            groupsetEndTime.setText(setting.getSettingValue("endTime"));

        } else {
            groupsetIntervalTime.setText(String.valueOf(ConstantData.DEFAULT_GROUP_SETTING_INTERVAL));
        }

        Button settingConfirm = (Button) layoutView.findViewById(R.id.share_group_confirm);
        Button settingCancle = (Button) layoutView.findViewById(R.id.share_group_cancle);

        if (isOwner) {
            view.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    LayoutInflater inflater = ((LBSClientMainActivity) context).getLayoutInflater();
                    View layoutView = inflater.inflate(R.layout.change_groupsetting_dialog, null);
                    final Dialog changeGroupSettingDialog = new Dialog(context, R.style.Dialog_No_Title);
                    changeGroupSettingDialog.setContentView(layoutView);

                    TextView title = (TextView) layoutView.findViewById(R.id.group_change_groupsetting_dialog_title);
                    final EditText interval = (EditText) layoutView
                        .findViewById(R.id.group_change_groupsetting_interval);

                    Button submit = (Button) layoutView.findViewById(R.id.group_change_groupsetting_ok);
                    Button cancel = (Button) layoutView.findViewById(R.id.group_change_groupsetting_cancel);

                    title.setText(R.string.group_frequency_change);

                    submit.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            groupsetIntervalTime.setText(interval.getText().toString());
                            if (changeGroupSettingDialog != null && changeGroupSettingDialog.isShowing()) {
                                changeGroupSettingDialog.dismiss();
                            }
                        }
                    });
                    cancel.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (changeGroupSettingDialog != null && changeGroupSettingDialog.isShowing()) {
                                changeGroupSettingDialog.dismiss();
                            }
                        }
                    });
                    changeGroupSettingDialog.show();

                }
            });

        }

        //group setting notify cancel
        settingCancle.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (groupSettingialog.isShowing()) {
                    groupSettingialog.dismiss();
                }
            }
        });

        //group setting notify confirm
        settingConfirm.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                String interval = null;
                String oldStartTime = null;
                String oldEndTime = null;
                if (setting != null) {
                    interval = setting.getSettingValue("interval");
                    oldStartTime = setting.getSettingValue("startTime");
                    oldEndTime = setting.getSettingValue("endTime");
                } 
                
                String startTime = groupsetStartTime.getText().toString();
                String endTime = groupsetEndTime.getText().toString();
                
                // if not equal then set group Setting
                String newInterval = groupsetIntervalTime.getText().toString();
                if ((interval == null || !interval.equals(newInterval)) ||
                	oldStartTime == null || !oldStartTime.equals(startTime) ||
                	oldEndTime == null || !oldEndTime.equals(endTime)) {
                	List<Setting> settingListTarget = new ArrayList<Setting>();
                	
                    if (setting != null) {
                        setting.setSettingValue("interval", newInterval);
                        setting.setSettingValue("startTime", startTime);
                        setting.setSettingValue("endTime", endTime);
                        
                        settingListTarget = setting.settingList;
                    } else {
                    	// default setting value is not exist.
                    	Setting settingObj = new Setting("interval", newInterval, "String");
                    	settingListTarget.add(settingObj);   


                    	Setting settingObj1 = new Setting("startTime", startTime, "String");
                    	settingListTarget.add(settingObj1);   
                    	

                    	Setting settingObj2 = new Setting("endTime", endTime, "String");
                    	settingListTarget.add(settingObj2);                      	
                    }
                    
                    try {
                        ((LBSClientMainActivity) context).iOperateGroup.setGroupSetting(groupId, groupId,
                        		settingListTarget);
                    } catch (RemoteException e) {
                        e.printStackTrace();
                    }
                }
                if (groupSettingialog.isShowing()) {
                    groupSettingialog.dismiss();
                }
            }
        });
    }

}
