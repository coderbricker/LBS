// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.tabs;

import java.util.ArrayList;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.RemoteException;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.gplocation.lbs.R;
import com.gplocation.lbs.activity.LBSClientMainActivity;
import com.gplocation.lbs.application.MainApplication;
import com.gplocation.lbs.data.self.ThirdApp;
import com.gplocation.lbs.datamanager.ThirdAppManager;
import com.gplocation.lbs.listadapter.ThirdAppAdapter;
import com.gplocation.lbs.utils.Utils;

/**
 * the Apps Tab
 */
public class TabApps implements ListView.OnScrollListener, View.OnTouchListener {

	private static final String TAG = "TabApps"; 
	
	
	private Context context; 
	private ListView listView;
	public ThirdAppAdapter adapter;
	
	public TabApps(Context context) {
		this.context = context;
		init();
	}
	
	
	private void init() {
		listView = (ListView) ((LBSClientMainActivity) context)
				.findViewById(R.id.applistView);
		listView.setOnScrollListener(this);
		listView.setOnTouchListener(this);
		
		listView.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1,
					int position, long id) {
				LayoutInflater inflater = ((Activity) context).getLayoutInflater();
				final View appDetailView = inflater.inflate(R.layout.app_detail, null);
				final Dialog appDetailDialog = new Dialog(context, R.style.Dialog_Fullscreen);
				appDetailDialog.setContentView(appDetailView);
				appDetailDialog.show();
				
				ImageView icon = (ImageView) appDetailView.findViewById(R.id.detail_app_icon);
				@SuppressWarnings("unused")
				TextView installTip = (TextView) appDetailView.findViewById(R.id.detail_app_install_tip);
				TextView name = (TextView) appDetailView.findViewById(R.id.detail_app_name);
				TextView author = (TextView) appDetailView.findViewById(R.id.detail_app_author);
				@SuppressWarnings("unused")
				ImageView star = (ImageView) appDetailView.findViewById(R.id.detail_app_star);
				Button newBtn = (Button) appDetailView.findViewById(R.id.detail_app_new); 
				
				TextView description = (TextView) appDetailView.findViewById(R.id.detail_app_description);
				
				LinearLayout doubleButtonLayout = (LinearLayout) appDetailView
						.findViewById(R.id.detail_double_buuton_layout);
				LinearLayout singleButtonLayout = (LinearLayout) appDetailView
						.findViewById(R.id.detail_single_buuton_layout);
				LinearLayout authenticateLayout = (LinearLayout) appDetailView
						.findViewById(R.id.detail_authenticate_layout);
				
				
				final ArrayList<ThirdApp> apps = adapter.getApps();
				
				Bitmap bitmap = ((MainApplication) ((LBSClientMainActivity) context).getApplication())
						.iconManager.getBitmap(apps.get(position).getAppId());
				if (bitmap == null) {
					icon.setImageResource(R.drawable.icon);
				} else {
					icon.setImageBitmap(bitmap);
				}
				
				name.setText(apps.get(position).getAppName());
				author.setText(apps.get(position).getAuthor());
				description.setText(apps.get(position).getDescription());
				
				boolean showNew = false;
				if (adapter.getInstallStatus().get(position)) {
					String installVersion = (String) ((MainApplication) ((LBSClientMainActivity) context)
							.getApplication())
							.thirdAppManager.getInstalledApps().get(position).get(Utils.INSTALLEDAPPSMAPVERSION);
					if (installVersion.compareToIgnoreCase(apps.get(position).getVersion()) < 0) {
						showNew = true;
					}
				}
				
				if (showNew) {
					newBtn.setVisibility(View.VISIBLE);
				} else {
					newBtn.setVisibility(View.GONE);
				}
				

				final ThirdApp app = apps.get(position);
				
				if (adapter.getInstallStatus().get(position)) {
					doubleButtonLayout.setVisibility(View.VISIBLE);
					singleButtonLayout.setVisibility(View.GONE);
					
					boolean authenticate = false;
					try {
						authenticate = ((LBSClientMainActivity) context).internal.getAuthenticate(app.getAppId());
					} catch (RemoteException e) {
						e.printStackTrace();
					}
					
					authenticateLayout.setVisibility(View.VISIBLE);
					if (!authenticate) {
						((TextView) authenticateLayout.findViewById(R.id.detail_authenticate_status))
						.setText(R.string.authenticate_success);
					} 
					
				} else {
					doubleButtonLayout.setVisibility(View.GONE);
					singleButtonLayout.setVisibility(View.VISIBLE);
				}
				
				
				Button install = (Button) appDetailView.findViewById(R.id.detail_install); 
				install.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
//						Utils.downLoadFileToInstall(context, "http://10.100.8.59/TestPHP/test111.apk");
						Utils.asyncDownLoadFile(context, app.getDownloadLink(), 
								((LBSClientMainActivity) context).mainHandler);
						appDetailDialog.dismiss();
					}
				});
				
				
				Button update = (Button) appDetailView.findViewById(R.id.detail_update); 
				update.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						Utils.asyncDownLoadFile(context, app.getDownloadLink(), 
								((LBSClientMainActivity) context).mainHandler);
						appDetailDialog.dismiss();
						
					}
				});
				
				
				Button remove = (Button) appDetailView.findViewById(R.id.detail_remove); 
				remove.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						//remove the authentication
						try {
							((LBSClientMainActivity) context).internal.removeAuthenticate(app.getAppId());
						} catch (RemoteException e) {
							e.printStackTrace();
						}
//						Utils.removePackage(context, app.getPackageName());
						appDetailDialog.dismiss();
					}
				});
			}

		});
		
		adapter = new ThirdAppAdapter(context);
		
		MainApplication mainApplication = (MainApplication) ((LBSClientMainActivity) context).getApplication();
        final ThirdAppManager thirdAppManager = mainApplication.thirdAppManager;
        thirdAppManager.registerObserver(adapter);
        
        listView.setAdapter(adapter);		
	}


	@Override
	public void onScroll(AbsListView view, int firstVisibleItem,
			int visibleItemCount, int totalItemCount) {
		
		Log.d(TAG, "onScroll");		
	}


	@Override
	public void onScrollStateChanged(AbsListView view, int scrollState) {
		Log.d(TAG, "scrolling statue = " + scrollState);
		
		if (view.getId() == listView.getId()) {
			if (scrollState == AbsListView.OnScrollListener.SCROLL_STATE_IDLE) {
				
//				int start = listView.getFirstVisiblePosition();
//				int end = listView.getLastVisiblePosition();
//				Log.d(TAG, "scrolling end + position=" + start + " to " + end);
//				
//				if (adapter != null) {
//					ArrayList<ThirdApp> apps = new ArrayList<ThirdApp>();
//					for (int i=start; i<end+1; ++i) {
//						apps.add(adapter.getApps().get(i));
//					}
//							
//					Handler handler = ((LBSClientMainActivity) context).mainHandler;
//					MainApplication mainApplication = (MainApplication) 
//							((LBSClientMainActivity) context).getApplication();
//					mainApplication.iconManager.loadBitmap(apps, handler);
//				}
			} 
		}
	}


	@Override
	public boolean onTouch(View v, MotionEvent event) {
		Log.d(TAG, "onTouch + " + event.getAction());	
		return false;
	}

}
