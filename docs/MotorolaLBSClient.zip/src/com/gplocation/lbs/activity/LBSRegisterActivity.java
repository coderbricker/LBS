package com.gplocation.lbs.activity;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.gplocation.lbs.R;
import com.gplocation.lbs.data.Register;
import com.gplocation.lbs.utils.ConstantData;

public class LBSRegisterActivity extends Activity {

	private Register registerValue = new Register();
	private boolean isLBSMainActivityCall = false; 
	
	 /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register);
        
        Intent intent = this.getIntent();
        isLBSMainActivityCall = intent.getBooleanExtra("LBSClientMainActivity", false);
        
        Button register = (Button) this.findViewById(R.id.register_ok);

        final EditText user = (EditText) this.findViewById(R.id.register_user);
        final EditText email = (EditText) this.findViewById(R.id.register_email);
        final EditText passWord = (EditText) this.findViewById(R.id.register_password);
        final EditText confirmPassWord = (EditText) this.findViewById(R.id.register_confirm_password);
        final EditText phone = (EditText) this.findViewById(R.id.register_phone);
        
        register.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				String userStr = user.getText().toString().trim();
				String emailStr = email.getText().toString().trim();
				String passStr = passWord.getText().toString();
				String confrimPassStr = confirmPassWord.getText().toString();
				String phoneStr = phone.getText().toString().trim();
				
				if ("".equals(userStr)) {
					popupSingleButtonDialog(R.string.register_input_user_name_promote).show();
					return;
				}
				
				if (!"".equals(userStr) && !userStr.matches(ConstantData.GroupName_Regex)) {
					popupSingleButtonDialog(R.string.register_input_right_user_name_promote).show();
					return;
				}
				

				if ("".equals(emailStr)) {
					popupSingleButtonDialog(R.string.register_input_email_phone_promote).show();
					return;
				}
				
				if (! "".equals(emailStr) && !emailStr.matches(ConstantData.Email_Regex)) {
					popupSingleButtonDialog(R.string.register_input_email_promote).show();
					return;
				}

				if ("".equals(passStr)) {
					popupSingleButtonDialog(R.string.register_input_password_promote).show();
					return;
				}

				if ("".equals(confrimPassStr)) {
					popupSingleButtonDialog(R.string.register_input_confirm_password_promote).show();
					return;
				}
				
				if (!passStr.equals(confrimPassStr)) {
					popupSingleButtonDialog(R.string.register_input_check_password_promote).show();
					return;
				}
				
				registerValue.setEmail(emailStr);
				registerValue.setUserName(userStr);
				registerValue.setPassWord(passStr);
				registerValue.setPhone(phoneStr);
				registerValue.setRegisterTimes(0);

				if (!isLBSMainActivityCall) {
					Intent intent = new Intent(LBSRegisterActivity.this,
							LBSClientMainActivity.class);
					intent.putExtra("register", registerValue);
					LBSRegisterActivity.this.startActivity(intent);
				} else {
					Intent returnIntend = new Intent();
		            returnIntend.putExtra("register", registerValue);
		            setResult(RESULT_OK, returnIntend);
				}

				LBSRegisterActivity.this.finish();
			}
		});
      
        
    }
    
    public Dialog popupSingleButtonDialog(int message) {
    	LayoutInflater inflater = this.getLayoutInflater();
    	final Dialog dialog = new Dialog(this, R.style.Dialog_No_Title);
    	
		View view = inflater.inflate(R.layout.dialog, null);
		dialog.setContentView(view);
		
		TextView titleView = (TextView) view.findViewById(R.id.dialog_title);
		TextView msgView = (TextView) view.findViewById(R.id.dialog_message);
		
		titleView.setText(R.string.Prompt);
		msgView.setText(message);
		
		Button okBtn = (Button) view.findViewById(R.id.dialog_signle_ok_btn);
		okBtn.setVisibility(View.VISIBLE);
		okBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				dialog.dismiss();
			}
		});
		
		view.findViewById(R.id.dialog_layout_two_button).setVisibility(View.GONE);
		
		return dialog;
    }
}
