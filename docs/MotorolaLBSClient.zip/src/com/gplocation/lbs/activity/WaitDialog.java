// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.

package com.gplocation.lbs.activity;

import android.app.Dialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;

import com.gplocation.lbs.R;

public class WaitDialog extends Dialog {

	private TextView titleView;
	private TextView messageView;
	
	public WaitDialog(Context context) {
		super(context, R.style.Dialog_No_Title);
		
		LayoutInflater inflater = ((LBSClientMainActivity) context).getLayoutInflater();
		View progressView = inflater.inflate(R.layout.progress_dialog, null);
		setContentView(progressView);
		
		titleView = (TextView) progressView.findViewById(R.id.progress_dialog_title);
		messageView = (TextView) progressView.findViewById(R.id.progress_dialog_message);
		
		this.setCancelable(false);
	}
	
	
	public void setTitle(String title) {
		titleView.setText(title); 
	}
	
	public void setMessage(String message) {
		messageView.setText(message);
	}

}
