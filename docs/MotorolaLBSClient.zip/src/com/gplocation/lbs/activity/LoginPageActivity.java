package com.gplocation.lbs.activity;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.gplocation.lbs.R;
import com.gplocation.lbs.data.Login;
import com.gplocation.lbs.utils.ConstantData;

public class LoginPageActivity extends Activity {

	private Login login = new Login();
	
	 /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
        
        final EditText email = (EditText) this.findViewById(R.id.login_email);
        final EditText passWord = (EditText) this.findViewById(R.id.login_password);
        final Button loginBtn = (Button) this.findViewById(R.id.login_ok);
        
        
        loginBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				String emailStr = email.getText().toString().trim();
				String passStr = passWord.getText().toString();
			
				if ("".equals(emailStr)) {
					popupSingleButtonDialog(R.string.register_input_email_phone_promote).show();
					return;
				}
				
				if (! "".equals(emailStr) && !emailStr.matches(ConstantData.Email_Regex)) {
					popupSingleButtonDialog(R.string.register_input_email_promote).show();
					return;
				}

				if ("".equals(passStr)) {
					popupSingleButtonDialog(R.string.register_input_password_promote).show();
					return;
				}

				login.setEmail(emailStr);
				login.setPassWord(passStr);

				
				Intent intent = new Intent(LoginPageActivity.this,
						LBSClientMainActivity.class);
				intent.putExtra("login", login);
				LoginPageActivity.this.startActivity(intent);
	            
	            LoginPageActivity.this.finish();
			}
		});
      
        
    }
    
    

    
    public Dialog popupSingleButtonDialog(int message) {
    	LayoutInflater inflater = this.getLayoutInflater();
    	final Dialog dialog = new Dialog(this, R.style.Dialog_No_Title);
    	
		View view = inflater.inflate(R.layout.dialog, null);
		dialog.setContentView(view);
		
		TextView titleView = (TextView) view.findViewById(R.id.dialog_title);
		TextView msgView = (TextView) view.findViewById(R.id.dialog_message);
		
		titleView.setText(R.string.Prompt);
		msgView.setText(message);
		
		Button okBtn = (Button) view.findViewById(R.id.dialog_signle_ok_btn);
		okBtn.setVisibility(View.VISIBLE);
		okBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				dialog.dismiss();
			}
		});
		
		view.findViewById(R.id.dialog_layout_two_button).setVisibility(View.GONE);
		
		return dialog;
    }
}
