// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.activity;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.baidu.mapapi.map.MapController;
import com.baidu.mapapi.map.MapView;
import com.baidu.mapapi.map.Overlay;
import com.baidu.mapapi.map.OverlayItem;
import com.baidu.platform.comapi.basestruct.GeoPoint;
import com.gplocation.lbs.R;
import com.gplocation.lbs.application.MainApplication;
import com.gplocation.lbs.data.GeoLocation;
import com.gplocation.lbs.data.LBSUser;
import com.gplocation.lbs.datamanager.GroupLocation;
import com.gplocation.lbs.datamanager.GroupLocation.UserLocation;
import com.gplocation.lbs.map.CustomItemizedOverlay;
import com.gplocation.lbs.utils.ConstantData;

/**
 * used for share group to show map
 */
public class GroupShowMapActivity extends Activity {

	private static final String TAG = "GroupShowMapActivity";
	private MapView mapView;
	private Set<String> set;
	private int lat = 400106900;
	private int lon = 1164688325;
	private MapController mapController;
	private String account = null;
	private BroadcastReceiver receiver;
	private String groupId;
	private GroupLocation groupLocation;
	private LBSUser lbsUser;

	/**
	 * new handler for new location point showing in map
	 * 
	 * @see android.os.Handler#handleMessage(android.os.Message)
	 */
	private Handler handler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case ConstantData.SHARE_STATE:
				Bundle bundle = msg.getData();
				int latitude = bundle.getInt("latitude");
				int longitude = bundle.getInt("longitude");
				String userName = bundle.getString("userName");
				String groupIdFromBroadcast = bundle.getString("groupId");
				if (groupIdFromBroadcast != null
						&& !groupIdFromBroadcast.equals(groupId)) {
					return;
				}

				groupLocation.setNewLocation(false);
				((MainApplication) GroupShowMapActivity.this.getApplication()).groupManager
						.update();

				if (set.contains(userName)) {
					GeoPoint point = new GeoPoint(latitude, longitude);
					setPoint(point, userName);
				} else {
					set.add(userName);
					GeoPoint point = new GeoPoint(latitude, longitude);
					addPoint(point, userName);
				}
				break;

			default:
				break;
			}
		}
	};

	/**
	 * 
	 * when a new location of a member received, if the member exist then reset
	 * his location
	 * 
	 * @param geoPoint
	 *            the new location point
	 * @param userName
	 *            whose location point
	 */
	private void setPoint(GeoPoint geoPoint, String userName) {
		Drawable drawable = this.getResources().getDrawable(R.drawable.point);
		CustomItemizedOverlay overLay = new CustomItemizedOverlay(drawable,
				this, userName, mapView);

		OverlayItem overlayitem = new OverlayItem(geoPoint,
				GroupShowMapActivity.this.getString(R.string.map_item_title),
				String.format(GroupShowMapActivity.this
						.getString(R.string.map_item_iam), userName));
		overLay.addOverlay(overlayitem);

		List<Overlay> overlays = mapView.getOverlays();
		for (int i = 0; i < overlays.size(); i++) {
			CustomItemizedOverlay overlay2 = (CustomItemizedOverlay) overlays
					.get(i);
			if (userName.equals(overlay2.getUserName())) {
				overlays.remove(i);
				break;
			}
		}
		overlays.add(overLay);

		if (lbsUser != null && lbsUser.getNick().equals(userName)) {
			try {
				mapController.setCenter(geoPoint);
				mapController.setZoom(18);
				mapController.animateTo(geoPoint);

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * when a new location of a member received, if the member not exist then
	 * add his location
	 * 
	 * @param geoPoint
	 *            the new location point
	 * @param userName
	 *            whose location point
	 */
	private void addPoint(GeoPoint geoPoint, String userName) {
		Drawable drawable = this.getResources().getDrawable(R.drawable.point);
		CustomItemizedOverlay overLay = new CustomItemizedOverlay(drawable,
				this, userName, mapView);
		OverlayItem overlayitem = new OverlayItem(geoPoint,
				GroupShowMapActivity.this.getString(R.string.map_item_title),
				String.format(GroupShowMapActivity.this
						.getString(R.string.map_item_iam), userName));
		overLay.addOverlay(overlayitem);

		List<Overlay> overlays = mapView.getOverlays();
		// overlays.clear();
		overlays.add(overLay);
		if (lbsUser != null && lbsUser.getNick().equals(userName)) {
			try {
				mapController.setCenter(geoPoint);
				mapController.setZoom(18);
				mapController.animateTo(geoPoint);

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * when activity create use this function (non-Javadoc)
	 * 
	 * @see com.google.android.maps.MapActivity#onCreate(android.os.Bundle)
	 */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.map);
		Log.d(TAG, "show map activity");
		init();
		// BroadcastReceiver

		lbsUser = ((MainApplication) this.getApplication()).userInfo;
		groupLocation = ((MainApplication) this.getApplication()).groupManager
				.getGroupLocations().get(groupId);
		if (groupLocation != null) {
			groupLocation.setNewLocation(false);
			((MainApplication) GroupShowMapActivity.this.getApplication()).groupManager
					.update();

			Map<String, UserLocation> userLocations = groupLocation
					.getUserLocations();

			Set<String> keys = userLocations.keySet();

			for (String string : keys) {
				UserLocation userLocation = userLocations.get(string);
				GeoLocation locationDomain = userLocation.getGeoLocation();
				Log.d("ShowMapActivity",
						"LocationDomain=" + String.valueOf(locationDomain));
				lat = (int) (Double.parseDouble(locationDomain.getLatitude()) * 1000000);
				lon = (int) (Double.parseDouble(locationDomain.getLongitude()) * 1000000);

				mapView = (MapView) findViewById(R.id.my_map);
				mapController = mapView.getController();
				mapView.setBuiltInZoomControls(true);
				GeoPoint point = new GeoPoint(lat, lon);
				addPoint(point, locationDomain.getFrom());

				set.add(locationDomain.getFrom());
			}
		}

	}

	private void init() {
		receiver = new BroadcastReceiver() {
			@Override
			public void onReceive(Context arg0, Intent arg1) {
				String groupIdFromBroadcast = arg1.getStringExtra("groupId");
				GeoLocation locationDomain = (GeoLocation) arg1
						.getParcelableExtra("location");
				int latitude = (int) (Double.parseDouble(locationDomain
						.getLatitude()) * 1000000);
				int longitude = (int) (Double.parseDouble(locationDomain
						.getLongitude()) * 1000000);
				String userName = locationDomain.getFrom();

				Message message = handler.obtainMessage();
				Bundle bundle = message.getData();
				bundle.putInt("latitude", latitude);
				bundle.putInt("longitude", longitude);
				bundle.putString("userName", userName);
				bundle.putString("groupId", groupIdFromBroadcast);

				message.what = ConstantData.SHARE_STATE;
				handler.sendMessage(message);
			}
		};
		registerReceiver(receiver,
				new IntentFilter("cn.com.lbs.group.location"));
		set = new HashSet<String>();
		Intent intent = this.getIntent();
		groupId = intent.getStringExtra("groupId");
	}

	/**
	 * when activity finish use this function
	 * 
	 * @see com.google.android.maps.MapActivity#onCreate(android.os.Bundle)
	 */
	@Override
	public void finish() {
		Log.d(TAG, "finish");
		if (account != null) {
			Intent returnIntend = new Intent();
			returnIntend.putExtra("account", account);
			setResult(RESULT_OK, returnIntend);
		}
		super.finish();
	}

	/**
	 * when activity destroy use this function
	 * 
	 * @see com.google.android.maps.MapActivity#onCreate(android.os.Bundle)
	 */
	@Override
	protected void onDestroy() {
		super.onDestroy();
		unregisterReceiver(receiver);
		Log.d(TAG, "onDestroy");
	}
}
