// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.

package com.gplocation.lbs.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.gplocation.lbs.R;
import com.gplocation.lbs.data.Register;

public class LBSLoginActivity extends Activity implements OnClickListener {
	
	private Button anonyLogin;
	private Button login;
	private Button register;
	
	 /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_main);
      
        anonyLogin = (Button) this.findViewById(R.id.anonymity_login);
        login = (Button) this.findViewById(R.id.login);
        register = (Button) this.findViewById(R.id.register);
        
        anonyLogin.setOnClickListener(this);
        login.setOnClickListener(this);
        register.setOnClickListener(this);
        
        
        Register registerValue = new Register();
        registerValue.getRegisterFromePreference(this);
        
        if (registerValue.getRegisterTimes() > 0) {
        	this.finish();
        	
        	Intent intent = new Intent(this, LBSClientMainActivity.class);
			intent.putExtra("register", registerValue);
			this.startActivity(intent);
        }
    }

	@Override
	public void onClick(View v) {
		int id = v.getId();
		if (id == anonyLogin.getId()) {
			Intent intent = new Intent(this, LBSClientMainActivity.class);
			this.startActivity(intent);
			this.finish();
		} else if (id == register.getId()) {
			Intent intent = new Intent(this, LBSRegisterActivity.class);
			this.startActivity(intent);
			this.finish();
		} else if (id == login.getId()) {
			Intent intent = new Intent(this, LoginPageActivity.class);
			this.startActivity(intent);
			this.finish();
		}
	}
}
