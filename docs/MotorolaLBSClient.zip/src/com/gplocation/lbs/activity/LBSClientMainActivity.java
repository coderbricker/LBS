// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.

package com.gplocation.lbs.activity;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import android.app.Dialog;
import android.app.TabActivity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TextView;
import android.widget.Toast;

import com.gplocation.lbs.R;
import com.gplocation.lbs.application.MainApplication;
import com.gplocation.lbs.client.GeneralListener;
import com.gplocation.lbs.client.IGeneral;
import com.gplocation.lbs.client.friend.FriendListener;
import com.gplocation.lbs.client.friend.IFriend;
import com.gplocation.lbs.client.friend.IOperateFriend;
import com.gplocation.lbs.client.group.GroupListener;
import com.gplocation.lbs.client.group.IGroup;
import com.gplocation.lbs.client.group.IOperateGroup;
import com.gplocation.lbs.client.internal.IInternal;
import com.gplocation.lbs.client.internal.InternalListener;
import com.gplocation.lbs.data.GeoLocation;
import com.gplocation.lbs.data.GroupInfo;
import com.gplocation.lbs.data.LBSUser;
import com.gplocation.lbs.data.Login;
import com.gplocation.lbs.data.Register;
import com.gplocation.lbs.datamanager.ThirdAppManager;
import com.gplocation.lbs.engine.CommandEngine;
import com.gplocation.lbs.engine.ShareLocationEngine;
import com.gplocation.lbs.listadapter.SearchGroupAdapter;
import com.gplocation.lbs.tabs.TabApps;
import com.gplocation.lbs.tabs.TabFriends;
import com.gplocation.lbs.tabs.TabGroup;
import com.gplocation.lbs.utils.ConstantData;
import com.gplocation.lbs.utils.Preferences;
import com.gplocation.lbs.utils.Utils;

/**
 * main activity in client
 */
public class LBSClientMainActivity extends TabActivity {

    private static final String TAG = "LBSClientMainActivity";

    public WaitDialog progressDialog;
    public WaitDialog searchProgressDialog;
    
    public Dialog searchResultDialog;
    public TabHost tabHost;
    public TabFriends tabFriends;
    public TabGroup tabGroup;
    public TabApps tabApps;
    
    public boolean showMap = false;
    public boolean groupShowMap = false;
    public MainHandler mainHandler;
    private CommandEngine handlerEngine;
    public ShareLocationEngine locationEngine;
	public Register register;
	public Login login;
	
	private LBSUser userInfo;
	
    private int[] tabMenus = {R.menu.mainmenu, R.menu.groupmainmenu};
    

	private Client2ServiceConn srvConn = new Client2ServiceConn(0); // authenticate
	
	public IGeneral iGeneral;
	public IFriend iFriend;
	public IOperateFriend iOperateFriend;
	public IGroup iGroup;
	public IOperateGroup iOperateGroup;
	public IInternal internal;
	
	public GeneralListener listenerGeneral;
	public FriendListener listenerFriend;
	public GroupListener listenerGroup;
	public InternalListener listenerInternal;
	
	
	private void bindGeneral() {
		Intent intent = new Intent();
		intent.setAction("com.gplocation.lbs.client.IGeneral");
		intent.putExtra("appId", "1234567890");
		try {
			// LBSClientMainActivity.this.startService(new
			// Intent("com.gplocation.lbs.client.ILBSClientServer"));
			bindService(intent, srvConn, Context.BIND_AUTO_CREATE);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
    /**
     * Connection from client to service after connected, set listener
     * @author Xu Jianbin
     */
    public class Client2ServiceConn implements ServiceConnection {
    	private int type;
    	public Client2ServiceConn(int type) {
    		this.type = type;
    	}
    	
        @Override
        public void onServiceConnected(ComponentName className, IBinder service) {
            Log.d(TAG, "onServiceConnected()");
            if (type == 0) {
	            iGeneral = IGeneral.Stub.asInterface(service);
	            Log.d(TAG, "0 iGeneral=" + iGeneral);
	            if (iGeneral != null) {           	
	            	try {
	            		listenerGeneral = new GeneralListener(mainHandler);
	            		
	            		// authenticate now
	            		iGeneral.authenticate("testactivity", ConstantData.APPLIED_APPID, 
	            				"wlcscu", ConstantData.APPLIED_KEY, 
	            				listenerGeneral);
	            		
	            		iGeneral.registerInToLBSPlatform("testactivity", 
	            				"1234567890", listenerGeneral, 0);	
	            		boolean isConnected = iGeneral.isServiceAvailable();
	            		Log.d(TAG, "isConnected=" + isConnected);
	            		
						if (isConnected) {
							
							userInfo = iGeneral.getUserInfo();
							((MainApplication) LBSClientMainActivity.this.getApplication()).userInfo = userInfo;
							
							if (userInfo != null) {
								Log.d(TAG, userInfo.toString());
								
								if ((userInfo.getEmail() != null && !"".equals(userInfo.getEmail()))) {
									register = new Register();
									register.setEmail(userInfo.getEmail());
									register.setPhone(userInfo.getPhone());
									register.setUserName(userInfo.getNick());
									register.setRegisterTimes(1);
									
									register.saveInPreference(LBSClientMainActivity.this);
								}
							}
							
			            	
						} else {
							LBSClientMainActivity.this.progressDialog.dismiss();
							
							LayoutInflater inflater = LBSClientMainActivity.this.getLayoutInflater();
					    	final Dialog dialog = new Dialog(LBSClientMainActivity.this, R.style.Dialog_No_Title);
					    	
							View view = inflater.inflate(R.layout.dialog, null);
							dialog.setContentView(view);
							
							TextView titleView = (TextView) view.findViewById(R.id.dialog_title);
							TextView msgView = (TextView) view.findViewById(R.id.dialog_message);
							
							titleView.setText(R.string.connect_failed);
							msgView.setText(R.string.restart_app);
							
							Button okBtn = (Button) view.findViewById(R.id.dialog_signle_ok_btn);
							okBtn.setVisibility(View.VISIBLE);
							okBtn.setOnClickListener(new OnClickListener() {
								@Override
								public void onClick(View v) {
									dialog.dismiss();
									LBSClientMainActivity.this.finish();
								}
							});
							
							view.findViewById(R.id.dialog_layout_two_button).setVisibility(View.GONE);
							dialog.setCancelable(false);
							dialog.show();
							
						}
					} catch (RemoteException e) {
						e.printStackTrace();
					}
	            }
            } 
        }

        @Override
        public void onServiceDisconnected(ComponentName className) {
//            lbsClientServer = null;
        }
    }

    /**
     * 
     * the main handler in client , display the data from backend
     */
    public class MainHandler extends Handler {
        @Override
        public void handleMessage(Message msg) {
        	if (msg.what > -1 && msg.what < CommandEngine.engineCommands.length) {
        		try {
					handlerEngine.dynaCall(CommandEngine.engineCommands[msg.what].fun, msg);
				} catch (NoSuchMethodException e) {
					e.printStackTrace();
				} catch (InvocationTargetException e) {
					e.printStackTrace();
				} catch (IllegalAccessException e) {
					e.printStackTrace();
				}
			} else {
				Log.d(TAG, "the message is out of RosterCoreEngine's handle region");
				super.handleMessage(msg);
			}
        }
    }
    
    
    

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);

        register();
        saveSetting();
        initWindow(); //get the components in main window
        
        new Thread() {
        	public void run() {
                MainApplication mainApplication = (MainApplication) (LBSClientMainActivity.this).getApplication();
        		final ThirdAppManager thirdAppManager = mainApplication.thirdAppManager;
        		thirdAppManager.initInstalledApps(LBSClientMainActivity.this);
        		
        		mainHandler.sendEmptyMessage(CommandEngine.SELF_DOWNLOAD_INSTALLED_APPS_FINISHED);
//        		thirdAppManager.updateInstalledStatus();
        	};
        }.start();
        
		
        initService();
    }

    /**
     * Called when the activity is destroy.
     * @see android.app.ActivityGroup#onDestroy()
     */
    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy");
        
        this.finish();
        this.unbindService(srvConn);
       
        android.os.Process.killProcess(android.os.Process.myPid());
    }
    
    
    /**
     * when Options Item Selected call this (non-Javadoc)
     * @see android.app.Activity#onOptionsItemSelected(android.view.MenuItem)
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int value = item.getItemId();
        switch (value) {
        case R.id.add_friend:
        	this.onCreateDialog(ConstantData.DIALOG_ADD_FRIEND, null);
            break;
        case R.id.setting:
            Intent intent = new Intent(LBSClientMainActivity.this, ShareLocationSettingActivity.class);
            LBSClientMainActivity.this.startActivity(intent);
            break;
        case R.id.aboutmenu:
			GeoLocation location = new GeoLocation();
			location.setAccuracy("121");
			location.setLatitude("123");
			location.setLongitude("37");
			location.setCountry("china");
			if (location != null) {

				Intent intent1 = new Intent(LBSClientMainActivity.this,
						ShowMapActivity.class);
				intent1.putExtra("account", "test");
				intent1.putExtra("location", location);
				try {
					((LBSClientMainActivity) (LBSClientMainActivity.this))
							.startActivityForResult(intent1,
									ConstantData.REQUEST_MAP_ACTIVITY);
				} catch (Exception e) {
					Toast.makeText(LBSClientMainActivity.this, e.getMessage(),
							Toast.LENGTH_LONG).show();
				}
			}
            // in the friend tap, make sure who am i
//        	this.onCreateDialog(ConstantData.DIALOG_ABOUT, null);
            break;
        case R.id.creategroup:
            // int the group tap, create for a new group
        	this.onCreateDialog(ConstantData.DIALOG_CREATE_GROUP, null);
            break;
        case R.id.searchgroup:
            // int the group tap, search a sharedgroup to join in
        	this.onCreateDialog(ConstantData.DIALOG_SEARCH_GROUP, null);
            break;
        case R.id.register_menu:
        case R.id.group_register_menu:
            // int the group tap, search a sharedgroup to join in
        	Intent intent1 = new Intent(this, LBSRegisterActivity.class);
        	intent1.putExtra("LBSClientMainActivity", true);        	
			this.startActivityForResult(intent1, ConstantData.REQUEST_REGISTER_ACTIVITY);
            break;
        default:
            break;
        }
        return true;
    }
	
    /**
     * set OptionsMenu info (non-Javadoc)
     * @see android.app.Activity#onPrepareOptionsMenu(android.view.Menu)
     */
    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
    	 menu.clear();
         MenuInflater inflater = getMenuInflater();
         switch (tabHost.getCurrentTab()) {
         case 0:
             inflater.inflate(tabMenus[0], menu);
                        
             if ((register != null && register.getRegisterTimes() > 0) ||
            		 login != null) {
            	 menu.findItem(R.id.register_menu).setVisible(false);
             }
             break;
         case 1:
             inflater.inflate(tabMenus[1], menu);
             if ((register != null && register.getRegisterTimes() > 0) ||
            		 login != null) {
            	 menu.findItem(R.id.group_register_menu).setVisible(false);
             }
             break;
         //        case 2:
         //            inflater.inflate(tabMenus[2], menu);
         //            break;
         default:
             break;
         }
         
         
         return super.onCreateOptionsMenu(menu);
    }

    
    /**
     * <p>product progress dialog</P>
     * @param title
     * @param message
     * @return
     */
    public Dialog popupProgressDialog(String title, String message) {
    	LayoutInflater inflater = this.getLayoutInflater();
    	final Dialog dialog = new Dialog(this, R.style.Dialog_No_Title);
    	
		View view = inflater.inflate(R.layout.progress_dialog, null);
		dialog.setContentView(view);
		
		TextView titleView = (TextView) view.findViewById(R.id.dialog_title);
		TextView msgView = (TextView) view.findViewById(R.id.dialog_message);
		
		titleView.setText(title);
		msgView.setText(message);
				
		return dialog;
    }
    
    
    /**
     * <p>product a single button dialog</P>
     * @param title
     * @param message
     * @return
     */
    public Dialog popupSingleButtonDialog(String title, String message) {
    	LayoutInflater inflater = this.getLayoutInflater();
    	final Dialog dialog = new Dialog(this, R.style.Dialog_No_Title);
    	
		View view = inflater.inflate(R.layout.dialog, null);
		dialog.setContentView(view);
		
		TextView titleView = (TextView) view.findViewById(R.id.dialog_title);
		TextView msgView = (TextView) view.findViewById(R.id.dialog_message);
		
		titleView.setText(title);
		msgView.setText(message);
		
		Button okBtn = (Button) view.findViewById(R.id.dialog_signle_ok_btn);
		okBtn.setVisibility(View.VISIBLE);
		okBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				dialog.dismiss();
			}
		});
		
		view.findViewById(R.id.dialog_layout_two_button).setVisibility(View.GONE);
		
		return dialog;
    }
    
    @Override
    protected Dialog onCreateDialog(int id, Bundle bl) {    	
		LayoutInflater inflater = this.getLayoutInflater();
    	switch (id) {
    	case ConstantData.DIALOG_ADD_FRIEND:
    		final Dialog addDialog = new Dialog(this, R.style.Dialog_Fullscreen);
            
    		View addView = inflater.inflate(R.layout.add_friend, null);
    		addDialog.setContentView(addView);
    		final EditText input = (EditText) addView.findViewById(R.id.add_friend_edit);
    		
    		Button okBtn = (Button) addView.findViewById(R.id.add_friend_ok);
    		Button cacelBtn = (Button) addView.findViewById(R.id.add_friend_cancel);
    		
    		okBtn.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					String phone = "";
					String email = "";
					String name = input.getText().toString().trim();
					if (name == null || "".equals(name.trim())) {
						LBSClientMainActivity.this.onCreateDialog(
								ConstantData.DIALOG_FRIEND_INPUT_ILLEGAL, null);
						return;
					} else {
						if (name.matches(ConstantData.Email_Regex) || name.matches(ConstantData.Phone_Regex)) {
							if (name.matches(ConstantData.Email_Regex)) {
								email = name;
							} else {
								phone = name;
							}

							addDialog.dismiss();
							try {
								(LBSClientMainActivity.this).internal.getUserMap(email, phone);
	//							(LBSClientMainActivity.this).iOperateFriend.addFriend(name, name + "@motolbs.com");
							} catch (RemoteException e) {
								e.printStackTrace();
							}
						} else {
							LBSClientMainActivity.this.onCreateDialog(
									ConstantData.DIALOG_FRIEND_INPUT_ILLEGAL, null);
						}
					}
				}
			});
    		
    		cacelBtn.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					addDialog.dismiss();
				}
			});
    		
    		
    		addDialog.show();
    		input.requestFocus();
    		
    		break;
    		 
    	case ConstantData.DIALOG_FRIEND_INPUT_ILLEGAL:
    		popupSingleButtonDialog(getString(R.string.lab_add_friend), 
    				getString(R.string.your_friend_name_is_illegal)).show(); 
    		 break;
    		 
    	case ConstantData.DIALOG_GROUP_INPUT_ILLEGAL:
    		popupSingleButtonDialog(getString(R.string.lab_create_group), 
    				getString(R.string.group_illegal)).show(); 
    		
    		break;
    		
    	case ConstantData.DIALOG_ABOUT:
    		MainApplication mainApplication = (MainApplication) LBSClientMainActivity.this.getApplication();
    		userInfo = mainApplication.userInfo;
    		
    		if (("".equals(userInfo.getEmail()) && register != null && register.getRegisterTimes() > 0)) {
    			try {
					userInfo = iGeneral.getUserInfo();
				} catch (RemoteException e) {
					e.printStackTrace();
				}
    		}
    		
    		Log.d(TAG, "user=" + userInfo.getNick());
    		
    		final Dialog aboutDialog = new Dialog(this, R.style.Dialog_Fullscreen);
            
    		View aboutView = inflater.inflate(R.layout.about, null);
    		aboutDialog.setContentView(aboutView);
    		
    		TextView userView = (TextView) aboutView.findViewById(R.id.about_user);
    		if (register != null && register.getRegisterTimes() > 0) {
    			userView.setText(getString(R.string.register_user_name) + " " + register.getUserName());
    		} else {
    			userView.setText(getString(R.string.register_user_name) + " " + userInfo.getNick());
    		}
    		
    		TextView phoneView = (TextView) aboutView.findViewById(R.id.about_phone);
    		if (register != null && register.getRegisterTimes() > 0) {
    			phoneView.setText(getString(R.string.register_mobile) + " " + register.getPhone());
    		} else {
    			phoneView.setText(getString(R.string.register_mobile));
    		}
    		
    		TextView emailView = (TextView) aboutView.findViewById(R.id.about_email);
    		if (register != null && register.getRegisterTimes() > 0) {
    			emailView.setText(getString(R.string.register_email) + " " + register.getEmail());
    		} else {
    			emailView.setText(getString(R.string.register_email));
    		}
    		
    		
    		aboutDialog.show();    		
    		
    		break;
    		
    	case ConstantData.DIALOG_CREATE_GROUP:
    		final Dialog createDialog = new Dialog(this, R.style.Dialog_Fullscreen);
            
    		View createGroupView = inflater.inflate(R.layout.create_group, null);
    		createDialog.setContentView(createGroupView);
    		createDialog.setTitle(R.string.lab_create_group);

            final EditText groupName = (EditText) createGroupView.findViewById(R.id.create_group_name);
            final EditText description = (EditText) createGroupView.findViewById(R.id.create_group_description);
            final Button createGroupBtn = (Button) createGroupView.findViewById(R.id.create_group_create);

            final String rules = ConstantData.GroupName_Regex;
            createGroupBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View arg0) {
                    String shareGroupName = groupName.getText().toString().trim();
                    String shareDescription = description.getText().toString().trim();
                    if (shareGroupName != null && shareGroupName.matches(rules)
                    		&& shareDescription.matches(ConstantData.Description_Regex)) {
                    	try {
							LBSClientMainActivity.this.iOperateGroup.createGroup(shareGroupName, shareDescription);
						} catch (RemoteException e) {
							e.printStackTrace();
						}
                    	
                    	createDialog.dismiss();                   	
                    } else {
                        LBSClientMainActivity.this.onCreateDialog(ConstantData.DIALOG_GROUP_INPUT_ILLEGAL, null);
                    }
               }
            });
            
            
            final Button cancelBtn = (Button) createGroupView.findViewById(R.id.create_group_cancel);
            cancelBtn.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					createDialog.dismiss();
				}
			});
            
            createDialog.show();
    		break;
    		
		case ConstantData.DIALOG_SEARCH_GROUP:
			View searchGroupView = inflater.inflate(R.layout.search_group, null);
			final Dialog dialog = new Dialog(this, R.style.Dialog_Fullscreen);
			dialog.setContentView(searchGroupView);
			dialog.show();
			
			
			final EditText searchGroupName = (EditText) searchGroupView
					.findViewById(R.id.search_group_name);
			Button searchGroupBtn = (Button) searchGroupView
					.findViewById(R.id.search_group_search);

			searchGroupBtn.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View arg0) {
					String shareGroupName = searchGroupName.getText()
							.toString().trim();
					if (shareGroupName != null && !"".equals(searchGroupName)) {
						try {
							iGroup.searchGroups(shareGroupName, 30);
						} catch (RemoteException e) {
							e.printStackTrace();
						}

						// LBSClientMainActivity.this.dismissDialog(ConstantData.DIALOG_SEARCH_GROUP);
						dialog.dismiss();
						searchProgressDialog = new WaitDialog(LBSClientMainActivity.this);
						
						searchProgressDialog.setMessage(getString(R.string.searching));
						searchProgressDialog.show();
					}

				}
			});
			break;
    		
    	case ConstantData.DIALOG_SEARCH_RESULT_GROUP:
            ArrayList<GroupInfo> groups = bl.getParcelableArrayList("searchGroups");

            if (groups == null || groups.size() == 0) {
            	popupSingleButtonDialog(getString(R.string.search_group_search), 
            			getString(R.string.search_group_no_result))
            		.show();
            } else {
	    		searchResultDialog = new Dialog(this, R.style.Dialog_Fullscreen);
	            View groupResultView = inflater.inflate(R.layout.search_group_adapter, null);
	            searchResultDialog.setContentView(groupResultView);
	            searchResultDialog.show();            
	
	            ExpandableListView listView = (ExpandableListView) searchResultDialog
	                .findViewById(R.id.searchgroupexpandablelistView);
	            SearchGroupAdapter searchGroupAdapter = new SearchGroupAdapter(this, groups);
	            listView.setAdapter(searchGroupAdapter);
            }
            
            break;
            
    	default:
    		break;
    	}
    	
    	return super.onCreateDialog(id);
//    	return super.onCreateDialog(id, bl);
    	
    }
    
    
  
    /**
     * <p>create group result dialog</P>
     * @param bl
     */
    public void createSearchGroupResultDialog(Bundle bl) {
    	this.onCreateDialog(ConstantData.DIALOG_SEARCH_RESULT_GROUP, bl);
    }
    
   

    /**
     * when another activity which was started by LBSClientMainActivity with requestCode finished,do sth for it
     * (non-Javadoc)
     * @see android.app.Activity#onActivityResult(int, int, android.content.Intent)
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
        case ConstantData.REQUEST_MAP_ACTIVITY:
            showMap = false;
            break;
        case ConstantData.REQUEST_GROUPMAP_ACTIVITY:
        	groupShowMap = false;
            break;
        case ConstantData.REQUEST_REGISTER_ACTIVITY:
        	if (data != null) {
	        	register = data.getParcelableExtra("register");
	        	// register
	        	if (register != null && register.getRegisterTimes() < 1) {
	        		try {
						internal.setUserMap(register.getUserName(), register.getPassWord(), 
								register.getEmail(), register.getPhone());
					} catch (RemoteException e) {
						e.printStackTrace();
					}
	        	}
        	}
        	
        	break;
        	
        default:
            break;
        }
    }

    
    private void register() {
    	register = this.getIntent().getParcelableExtra("register");
    	login = this.getIntent().getParcelableExtra("login");
//    	if (register != null )
    	
    	
    }
    
    /**
     * init service message
     */
    private void initService() {
        //set client listener to listen the message form service 
        mainHandler = new MainHandler();
        locationEngine = new ShareLocationEngine(new GeoLocation());
        handlerEngine = new CommandEngine(this, locationEngine);
//        stateListener = new LBSStateListener(mainHandler);
        // bind Service
        bindGeneral();
    }

    /**
     * saveSetting for shareLocationMode
     */
    private void saveSetting() {
        //parameters setting
        Preferences setting = new Preferences(this);
        String shareLocationMode = setting.getParameter(ShareLocationEngine.SHARE_LOCATION_MODE);
        if (Utils.isEmpty(shareLocationMode)) {
            //share location one time by default
            setting.saveParameter(ShareLocationEngine.SHARE_LOCATION_MODE, ShareLocationEngine.SHARE_MODE_PERIODICALLY);
            setting.saveParameter(ShareLocationEngine.SHARE_LOCATION_GAP_TIME,
                ShareLocationSettingActivity.SHARE_PERIODICALLY_TWO_MINUTES);
        }
    }

    /**
     * init the main window and get the component in UI.
     */
    private void initWindow() {
        //progress dialog
//        progressDialog = ProgressDialog.show(LBSClientMainActivity.this, this.getString(R.string.wait),
//            this.getString(R.string.connecting), true);

    	LayoutInflater inflater = this.getLayoutInflater();
    	progressDialog = new WaitDialog(this);
		progressDialog.show();
		
			
		final Timer timer = new Timer();
		timer.schedule(new TimerTask() {
			@Override
			public void run() {
				if (progressDialog.isShowing()) {
					progressDialog.dismiss();
					
//					mainHandler.sendEmptyMessage(CommandEngine.APPLICATION_EXIT);	
				}
				
				timer.cancel();
			}
			
		}, 1*1000, 120*1000);
		
		
		
        tabHost = getTabHost();
    	
        final View friendView = inflater.inflate(R.layout.tab_head, null);
        final View friendHeadView = friendView.findViewById(R.id.tab_head);
        ((ImageView) friendView.findViewById(R.id.tab_image)).setBackgroundDrawable(getResources()
        		.getDrawable(R.drawable.tab_friends_selector));
        final TextView friendTextView = ((TextView) friendView.findViewById(R.id.tab_text));
        friendTextView.setText(getString(R.string.tab_friends));
        
        tabHost.addTab(tabHost.newTabSpec(LBSClientMainActivity.this.getString(R.string.tab_friends))
                .setIndicator(friendView)
                .setContent(R.id.Friends));
        

        final View groupView = inflater.inflate(R.layout.tab_head, null);
        final View groupHeadView = groupView.findViewById(R.id.tab_head);
        ((ImageView) groupView.findViewById(R.id.tab_image)).setBackgroundDrawable(getResources()
        		.getDrawable(R.drawable.tab_group_selector));
        final TextView groupTextView = ((TextView) groupView.findViewById(R.id.tab_text));
        groupTextView.setText(getString(R.string.tab_groups));
        tabHost.addTab(tabHost.newTabSpec(LBSClientMainActivity.this.getString(R.string.tab_groups))
                .setIndicator(groupView)
                .setContent(R.id.Groups));
        
        
        final View appView = inflater.inflate(R.layout.tab_head, null);
        final View appHeadView = appView.findViewById(R.id.tab_head);
        ((ImageView) appView.findViewById(R.id.tab_image)).setBackgroundDrawable(getResources()
        		.getDrawable(R.drawable.tab_application_selector));
        final TextView appTextView = ((TextView) appView.findViewById(R.id.tab_text));
        appTextView.setText(getString(R.string.tab_apps));
        tabHost.addTab(tabHost.newTabSpec(LBSClientMainActivity.this.getString(R.string.tab_apps))
                .setIndicator(appView)
                .setContent(R.id.Apps));
    
        final int selectedColor = getResources().getColor(R.color.text_default_color);
        final int normalColor = getResources().getColor(R.color.menu_default_color);
        final int selectedTopPadding = 4;
        final int normalTopPadding = 10;
        
        //setting the current tab to display
        tabHost.setCurrentTab(0);
        friendView.setPadding(0, selectedTopPadding, 0, 0);
        groupView.setPadding(0, normalTopPadding, 0, 0);
        appView.setPadding(0, normalTopPadding, 0, 0);
        friendTextView.setTextColor(selectedColor);
        friendHeadView.setBackgroundDrawable(getResources().getDrawable(R.drawable.tab_head_press));
        groupHeadView.setBackgroundDrawable(getResources().getDrawable(R.drawable.tab_head_bg));
        appHeadView.setBackgroundDrawable(getResources().getDrawable(R.drawable.tab_head_bg));
        
        
        tabHost.setOnTabChangedListener(new OnTabChangeListener() {
			@Override
			public void onTabChanged(String tabId) {
				
				if (tabId.equals(getString(R.string.tab_friends))) {
					friendView.setPadding(0, selectedTopPadding, 0, 0);
					groupView.setPadding(0, normalTopPadding, 0, 0);
			        appView.setPadding(0, normalTopPadding, 0, 0);
			        
			        friendTextView.setTextColor(selectedColor);
			        groupTextView.setTextColor(normalColor);
			        appTextView.setTextColor(normalColor);
			        
			        friendHeadView.setBackgroundDrawable(getResources().getDrawable(R.drawable.tab_head_press));
			        groupHeadView.setBackgroundDrawable(getResources().getDrawable(R.drawable.tab_head_bg));
			        appHeadView.setBackgroundDrawable(getResources().getDrawable(R.drawable.tab_head_bg));
				} else if (tabId.equals(getString(R.string.tab_groups))) {
					groupView.setPadding(0, selectedTopPadding, 0, 0);
					friendView.setPadding(0, normalTopPadding, 0, 0);
			        appView.setPadding(0, normalTopPadding, 0, 0);
			        
			        
			        groupTextView.setTextColor(selectedColor);
			        friendTextView.setTextColor(normalColor);
			        appTextView.setTextColor(normalColor);
			        
			        groupHeadView.setBackgroundDrawable(getResources().getDrawable(R.drawable.tab_head_press));
			        friendHeadView.setBackgroundDrawable(getResources().getDrawable(R.drawable.tab_head_bg));
			        appHeadView.setBackgroundDrawable(getResources().getDrawable(R.drawable.tab_head_bg));
				} else if (tabId.equals(getString(R.string.tab_apps))) {
					appView.setPadding(0, selectedTopPadding, 0, 0);
					friendView.setPadding(0, normalTopPadding, 0, 0);
			        groupView.setPadding(0, normalTopPadding, 0, 0);

			        appTextView.setTextColor(selectedColor);
			        friendTextView.setTextColor(normalColor);
			        groupTextView.setTextColor(normalColor);
			        
			        appHeadView.setBackgroundDrawable(getResources().getDrawable(R.drawable.tab_head_press));
			        groupHeadView.setBackgroundDrawable(getResources().getDrawable(R.drawable.tab_head_bg));
			        friendHeadView.setBackgroundDrawable(getResources().getDrawable(R.drawable.tab_head_bg));
				}
				
			}
		});
        
            
        tabFriends = new TabFriends(this);
//        tabSetting = new TabSetting(this);
        tabApps = new TabApps(this);
        tabGroup = new TabGroup(this);
    }

}
