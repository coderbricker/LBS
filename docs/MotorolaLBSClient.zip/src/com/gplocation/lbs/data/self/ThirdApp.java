// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.data.self;

import android.os.Parcel;
import android.os.Parcelable;

public class ThirdApp implements Parcelable {

	private String appId;
	private String appName;
	private String packageName;
	private String author;
	private String description;
	private String version;
	private String downloadLink;
//	private byte[] iconByte = new byte[1024];
	private String iconLink;
	
		
	public ThirdApp() {
		
	}
	
	public ThirdApp (Parcel source) {
		this.appId = source.readString();
		this.appName = source.readString();
		this.packageName = source.readString();
		this.author = source.readString();
		this.description = source.readString();
		this.version = source.readString();
		this.downloadLink = source.readString();
		this.setIconLink(source.readString());
	}
	
	public String getAppId() {
		return appId;
	}
	
	public void setAppId(String appId) {
		this.appId = appId;
	}
	
	public String getAppName() {
		return appName;
	}
	
	public void setAppName(String appName) {
		this.appName = appName;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public String getVersion() {
		return version;
	}
	
	public void setVersion(String version) {
		this.version = version;
	}
	
	public String getDownloadLink() {
		return downloadLink;
	}
	
	public void setDownloadLink(String downloadLink) {
		this.downloadLink = downloadLink;
	}
	@Override
	public int describeContents() {
		return 0;
	}

	@Override
	public void writeToParcel(Parcel dest, int flags) {
		dest.writeString(appId);
		dest.writeString(appName);
		dest.writeString(packageName);
		dest.writeString(author);
		dest.writeString(description);
		dest.writeString(version);
		dest.writeString(downloadLink);
		dest.writeString(iconLink);
	}
	
	
	public String getIconLink() {
		return iconLink;
	}

	public void setIconLink(String iconLink) {
		this.iconLink = iconLink;
	}


	public String getPackageName() {
		return packageName;
	}

	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}


	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}


	public static final Parcelable.Creator<ThirdApp> CREATOR = new Parcelable.Creator<ThirdApp>() {

        @Override
        public ThirdApp createFromParcel(Parcel source) {
            return new ThirdApp(source);
        }

        @Override
        public ThirdApp[] newArray(int size) {
            return new ThirdApp[size];
        }
    };

}
