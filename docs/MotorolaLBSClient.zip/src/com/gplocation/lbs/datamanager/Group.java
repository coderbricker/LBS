// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.datamanager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.gplocation.lbs.data.GroupInfo;
import com.gplocation.lbs.data.Member;

/**
 * group and group members, all the members is in order.
 */
public class Group {
	
	private GroupInfo groupInfo;
	private ArrayList<Member> members = new ArrayList<Member>();
	private boolean shared;
	private boolean showMembers;
	private boolean newLocationCome = false;
	
	/**
	 * compare according to member nickName, make sure Member's nick is not empty.
	 */
	public class CompareMember implements Comparator<Member> {	    
		@Override
		public int compare(Member object1, Member object2) {
			String account1 = object1.nick;
			String account2 = object2.nick;
			if (account1 != null && account2 != null) {
				return account1.compareTo(account2);
			} else {
				return 0;
			}
		}
	}
		
	/**
	 * a group member class must has groupId, group name etc.
	 */
	public Group(GroupInfo groupInfo) {
		this.groupInfo = groupInfo;
	}
	
	/**
	 * a group member class must has groupId, group name etc.
	 */
	public Group(GroupInfo groupInfo, List<Member> members2) {
		this.groupInfo = groupInfo;
		this.members = (ArrayList<Member>) members2;
		
		if (members != null) {
			CompareMember comparator = new CompareMember();
			Collections.sort(members, comparator);
		}
	}
	
	
	
	/**
	 * <p>insert a member at the location</P>
	 * @param nickName
	 * @return
	 */
	private int insertMember(String nickName) {
		if (members.size() == 0 || nickName.compareTo(members.get(0).nick) <= 0) {
			return 0;
		}
		
		for (int i = 1; i < members.size(); ++i) {
			String friendNameBefore = members.get(i - 1).nick;
			String friendName = members.get(i).nick;
			if (nickName.compareTo(friendNameBefore) > 0 
				&& nickName.compareTo(friendName) <= 0) {
				return i;
			}
		}
		
		return members.size();
	}
		
	/**
	 * <p>add a member, keep the member in order, cover the old one if cover is true</P>
	 * @param account
	 * @param nick
	 * @param role
	 * @param cover
	 */
	public void addMember(String account, String nick, String role, boolean cover) {
		if (nick == null || nick.equals("")) {
			nick = account.split("@")[0];
		}
		
		int location = contain(account);
		if (location > -1) {
			if (cover && role != null && !role.equals("")) {
				members.get(location).nick = nick;
				members.get(location).role = role;
			}
		} else {
			int locInsert = insertMember(nick);
			members.add(locInsert, new Member(account, nick, role));
		}
	}

	/**
	 * <p>add a new member, if the member exits, cover it</P>
	 * @param account
	 * @param nick
	 * @param role
	 */
	public void addMember(String account, String nick, String role) {
		addMember(account, nick, role, true);
	}
	
	/**
	 * <p></P>
	 * @param member
	 */
	public void addMember(Member member) {
		addMember(member.account, member.nick, member.role);
	}
	
	/**
	 * <p></P>
	 * @param account
	 */
	public void removeMember(String account) {

		int location = contain(account);
		if (location > -1) {
			members.remove(location);
		}
	}
	
	/**
	 * <p></P>
	 * @param account
	 * @return
	 */
	public Member getMember(String account) {
		int location = contain(account);
		if (location > -1) {
			return members.get(location);
		} else {
			return null;
		}
	}
	
	
	/**
	 * <p>get owners' account</P>
	 * @return
	 */
	public ArrayList<String> getOwners() {
		ArrayList<String> owners = new ArrayList<String>();
		for (int i = 0; i < members.size(); ++i) {
			if (members.get(i).role.equals("owner")) {
				owners.add(members.get(i).account);
			}
		}
		
		return owners;
	}
	
	/**
	 * <p>Whether contain this member</P>
	 * @param memberId
	 * @return the member location in members list. >-1, contain; -1: not contain
	 */
	public int contain(String memberId) {
		for (int i = 0; i < members.size(); ++i) {
			if (members.get(i).account.equals(memberId)) {
				return i;
			}
		}
		
		return -1;
	}
	
	public ArrayList<Member> getMembers() {
		return members;
	}

	public void setMembers(List<Member> members2) {
		this.members = (ArrayList<Member>) members2;
		
		CompareMember comparator = new CompareMember();
		Collections.sort(members, comparator);
	}

	public GroupInfo getGroupInfo() {
		return groupInfo;
	}

	public void setGroupInfo(GroupInfo groupInfo) {
		this.groupInfo = groupInfo;
	}

    public boolean isShared() {
        return shared;
    }

    public void setShared(boolean shared) {
        this.shared = shared;
    }

    public boolean isShowMembers() {
        return showMembers;
    }

    public void setShowMembers(boolean showMembers) {
        this.showMembers = showMembers;
    }

	public boolean isNewLocationCome() {
		return newLocationCome;
	}

	public void setNewLocationCome(boolean newLocationCome) {
		this.newLocationCome = newLocationCome;
	}

	
}
