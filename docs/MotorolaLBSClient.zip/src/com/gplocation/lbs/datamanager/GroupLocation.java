package com.gplocation.lbs.datamanager;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import android.app.Activity;
import android.content.Context;

import com.gplocation.lbs.application.MainApplication;
import com.gplocation.lbs.data.GeoLocation;

public class GroupLocation {
    private String groupId;
    private boolean newLocation;

    private Map<String, UserLocation> userLocations;

    public GroupLocation(String groupId) {
        this.groupId = groupId;
        userLocations = new HashMap<String, GroupLocation.UserLocation>();
    }

    public void addNewLocation(UserLocation userLocation , Context context) {
        userLocations.put(userLocation.getUserName(), userLocation);
        setNewLocation(true);
        ((MainApplication) ((Activity) context).getApplication()).groupManager.update();
    }

    public Map<String, UserLocation> getUserLocations() {
        return userLocations;
    }
    
    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public boolean isNewLocation() {
        return newLocation;
    }

    public void setNewLocation(boolean newLocation) {
        this.newLocation = newLocation;
    }

    public static class UserLocation {
        private String userName;
        private long locationTime;
        private GeoLocation geoLocation;

        public UserLocation(String userName, GeoLocation geoLocation) {
            this.userName = userName;
            this.geoLocation = geoLocation;
            this.locationTime = new Date().getTime();
        }

        public GeoLocation getGeoLocation() {
            return geoLocation;
        }

        public long getLocationTime() {
            return locationTime;
        }

        public String getUserName() {
            return userName;
        }
    }
}
