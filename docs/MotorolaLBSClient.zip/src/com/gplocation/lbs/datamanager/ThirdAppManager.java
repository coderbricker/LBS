package com.gplocation.lbs.datamanager;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import android.content.Context;
import android.util.Log;

import com.gplocation.lbs.data.self.ThirdApp;
import com.gplocation.lbs.utils.Utils;

public class ThirdAppManager {

	private static final String TAG = "ThirdAppManager";
	private static ThirdAppManager thirdAppManager;
	
	private ArrayList<ThirdApp> apps = new ArrayList<ThirdApp>();
	private ArrayList<Boolean> installedThirdApps = new ArrayList<Boolean>();
	private List<Map<String, Object>> installedApps;
	
	private ArrayList<DataObserver> observers = new ArrayList<DataObserver>();
	
	private ThirdAppManager() {
		
	}
	
	public static synchronized ThirdAppManager getInstance() {
		if (thirdAppManager == null) {
			thirdAppManager = new ThirdAppManager();
		}

		return thirdAppManager;
	}
	
	
	/**
	 * <p>
	 * register observer
	 * </P>
	 * 
	 * @param observer
	 */
	public void registerObserver(DataObserver observer) {
		this.observers.add(observer);
	}
	
	/**
	 * <p>call observer's update function</P>
	 */
	public void update() {
		for (int i = 0; i < observers.size(); ++i) {
			observers.get(i).update();
		}
	}
	
	public ArrayList<ThirdApp> getApps() {
		return apps;
	}

	public void setApps(ArrayList<ThirdApp> apps) {
		this.apps = apps;	
		update();
	}
	
	
	public void updateInstalledStatus() {
//		Log.d(TAG, "updateInstalledStatus + " + installedApps.size());
		
		installedThirdApps.clear();
		for (int i = 0; i < apps.size(); ++i) {
			boolean installed = false;
			for (int j = 0; installedApps != null && j < installedApps.size(); ++j) {
				if (installedApps.get(j).get(Utils.INSTALLEDAPPSMAPNAME).equals(apps.get(i).getAppName())) {
					installed = true;
					Log.d(TAG, "updateInstalledStatus + set a true value");
					break;
				}
			}
			
			installedThirdApps.add(installed);
		}
		
//		for (int i=0; i<installedThirdApps.size(); ++i) {
//			Log.d(TAG, "updateInstalledStatus + i" + installedThirdApps.get(i));
//		}
		
		update();
	}
	
	public void initInstalledApps(Context context) {		
		installedApps = Utils.fetchInstallApps(context);
	}
	
	public void init(ArrayList<ThirdApp> apps) {
		this.apps = apps;
		
		for (int i = 0; i < apps.size(); ++ i) {
			Log.d(TAG, apps.get(i).getAppName() + " appId=" + apps.get(i).getAppId());
		}
		
		updateInstalledStatus();
		
	}

	public ArrayList<Boolean> getInstalledThirdApps() {
		return installedThirdApps;
	}

	public void setInstalledThirdApps(ArrayList<Boolean> installedThirdApps1) {
		this.installedThirdApps = installedThirdApps1;
	}

	public List<Map<String, Object>> getInstalledApps() {
		return installedApps;
	}

	public void setInstalledApps(List<Map<String, Object>> installedApps) {
		this.installedApps = installedApps;
	}
	
}


