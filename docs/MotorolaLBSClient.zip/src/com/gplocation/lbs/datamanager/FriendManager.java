// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.datamanager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import android.util.Log;

import com.gplocation.lbs.data.Friend;
import com.gplocation.lbs.data.GeoLocation;

/**
 * manage friend list
 * @note friend list is sorted by nickname
 * @author
 * 
 */
public class FriendManager {

	private final static String TAG = "FriendManager";
	
	private ArrayList<Friend> friendList = new ArrayList<Friend>();
	
	private ArrayList<FriendStatus> friendStatus = new ArrayList<FriendManager.FriendStatus>();
	
	private ArrayList<DataObserver> observers = new ArrayList<DataObserver>();

	private static FriendManager friendManager;

	
	public static class FriendStatus {
		public GeoLocation location;
		public boolean shareContinuous;
		public boolean request;
		public boolean follow;
		public boolean followReturn;
		public boolean locationCome;	
		public boolean agreeRequest;
		public boolean agreeFollow;
		
		public FriendStatus() {
			
		}
	}
	
	
	private FriendManager() {

	}

	public static synchronized FriendManager getInstance() {
		if (friendManager == null) {
			friendManager = new FriendManager();
		}

		return friendManager;
	}

	/**
	 * <p>
	 * register observer
	 * </P>
	 * 
	 * @param observer
	 */
	public void registerObserver(DataObserver observer) {
		this.observers.add(observer);
	}
	
	/**
	 * <p>set friend's location</P>
	 * @param friendId
	 * @param location
	 */
	public void setFriendLocation(String friendId, GeoLocation location) {
		int loc = contain(friendId);
		if (loc > -1) {
			friendStatus.get(loc).location = location;
		}
	}

	/**
	 * <p>set friend whether sharing</P>
	 * @param friendId
	 * @param share
	 */
	public void setFriendShareContinous(String friendId, boolean share) {
		int loc = contain(friendId);
		if (loc > -1) {
			friendStatus.get(loc).shareContinuous = share;
			update();
		}
	}
	
	
	/**
	 * <p>set friend status whether agree the friend's request</P>
	 * @param friendId
	 * @param agreeRequest
	 */
	public void setFriendAgreeRequest(String friendId, boolean agreeRequest) {
		int loc = contain(friendId);
		if (loc > -1) {
			friendStatus.get(loc).agreeRequest = agreeRequest;
			update();
		}
	}
	
	
	/**
	 * <p>set friend status whether agree the friend's follow</P>
	 * @param friendId
	 * @param agreeFollow
	 */
	public void setFriendAgreeFollow(String friendId, boolean agreeFollow) {
		int loc = contain(friendId);
		if (loc > -1) {
			friendStatus.get(loc).agreeFollow = agreeFollow;
			update();
		}
	}
	
	
	/**
	 * <p>set a friend send his location now or his location has been seen</P>
	 * @param friendId
	 * @param come
	 */
	public void setFriendLocationCome(String friendId, boolean come) {
		Log.d(TAG, "setFriendLocationCome " + friendId);
		int loc = contain(friendId);
		if (loc > -1) {
			friendStatus.get(loc).locationCome = come;
			update();
		}
	}
	
	
	public class CompareFriend implements Comparator<Friend> {	    
		@Override
		public int compare(Friend object1, Friend object2) {
			String account1 = object1.getNickName();
			String account2 = object2.getNickName();
			return account1.compareTo(account2);
		}
	}
	
	
	/**
	 * <p>call observer init function</P>
	 */
	public void init(ArrayList<Friend> friendList) {
		// make sure the nickname is not null
		for (int i = 0; i < friendList.size(); ++i) {
			if (friendList.get(i).getNickName() == null) {
				String account = friendList.get(i).getAccount();
				friendList.get(i).setNickName(account.split("@")[0]);
			}
		}
		
		
		CompareFriend compareFriend = new CompareFriend();
		Collections.sort(friendList, compareFriend);
		this.friendList = friendList;
		
		for (int i = 0; i < friendList.size(); ++i) {
			friendStatus.add(new FriendStatus());
		}
		
		for (int i = 0; i < observers.size(); ++i) {
			observers.get(i).init();
		}
	}
	
	/**
	 * <p>call observer's update function</P>
	 */
	public void update() {
		for (int i = 0; i < observers.size(); ++i) {
			observers.get(i).update();
		}
	}

	/**
	 * <p>insert friend at the location</P>
	 * @param account
	 * @return
	 */
	private int insertFriend(String nickName) {
		if (friendList.size() == 0 || nickName.compareTo(friendList.get(0).getNickName()) <= 0) {
			return 0;
		}
		
		for (int i = 1; i < friendList.size(); ++i) {
			String friendNameBefore = friendList.get(i - 1).getNickName();
			String friendName = friendList.get(i).getNickName();
			if (nickName.compareTo(friendNameBefore) > 0 
				&& nickName.compareTo(friendName) <= 0) {
				return i;
			}
		}
		
		return friendList.size();
	}
	
	
	/**
	 * <p>
	 * add a friend or do nothing if exist
	 * </P>
	 * 
	 * @param friend
	 */
	public void add(Friend friend) {
		int loc = contain(friend.getAccount());
		if (loc > -1) {
//			updatePresence(friend.getAccount(), friend.getPresence());
		} else {
			if (friend.getNickName() == null || friend.getNickName().equals("")) {
				friend.setNickName(friend.getAccount().split("@")[0]);
			}
			
			int locInsert = insertFriend(friend.getNickName());
			friendList.add(locInsert, friend);
			friendStatus.add(locInsert, new FriendStatus());
			update();
		}
	}

	/**
	 * <p>
	 * add a friend or do nothing 
	 * </P>
	 * 
	 * @param account
	 * @param nick
	 * @param presence
	 */
	public void add(String account, String nick, String email, String phone, String presence) {
		int loc = contain(account);
		if (loc > -1) {
//			updatePresence(account, presence);
		} else {
			if (nick == null || nick.equals("")) {
				nick = account.split("@")[0];
			}
			
			int locInsert = insertFriend(nick);
			Friend friend = new Friend(account, nick, email, phone, presence);
			friendList.add(locInsert, friend);
			friendStatus.add(locInsert, new FriendStatus());
			update();
		}
	}

	/**
	 * <p>
	 * remove a friend
	 * </P>
	 * 
	 * @param friend
	 */
	public void remove(Friend friend) {
		int loc = contain(friend.getAccount());
		if (loc > -1) {
			friendList.remove(loc);
			friendStatus.remove(loc);
			update();
		}
	}

	/**
	 * <p>
	 * remove a friend
	 * </P>
	 * 
	 * @param account
	 */
	public void remove(String account) {
		int loc = contain(account);
		if (loc > -1) {
			friendList.remove(loc);
			friendStatus.remove(loc);
			update();
		}
	}

	/**
	 * <p>
	 * update a friend's presence state
	 * </P>
	 * 
	 * @param account
	 * @param presence
	 */
	public void updatePresence(String account, String presence) {
		int loc = contain(account);

		if (loc > -1) {
			friendList.get(loc).setPresence(presence);
			update();
		}
	}

	/**
	 * <p>
	 * Whether has this account
	 * </P>
	 * 
	 * @param account
	 * @return
	 */
	public int contain(String account) {
		for (int i = 0; i < friendList.size(); ++i) {
			if (friendList.get(i).getAccount().equals(account)) {
				return i;
			}
		}

		return -1;
	}

	public ArrayList<Friend> getFriendList() {
		return friendList;
	}

	public void setFriendList(ArrayList<Friend> friendList) {
		this.friendList = friendList;
	}

	public ArrayList<FriendStatus> getFriendStatus() {
		return friendStatus;
	}

	public void setFriendStatus(ArrayList<FriendStatus> friendStatus1) {
		this.friendStatus = friendStatus1;
	}
}
