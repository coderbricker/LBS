package com.gplocation.lbs.datamanager;

import com.gplocation.lbs.data.Friend;

public class GroupAddUser {
    
    private Friend friend; 
    private boolean invite;
    
    public GroupAddUser() {
    }
    public GroupAddUser(Friend friend) {
        this.friend = friend;
    }
    
    public Friend getFriend() {
        return friend;
    }
    public void setFriend(Friend friend) {
        this.friend = friend;
    }
    public boolean isInvite() {
        return invite;
    }
    public void setInvite(boolean invite) {
        this.invite = invite;
    }
    
    

}
