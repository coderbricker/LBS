package com.gplocation.lbs.datamanager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.os.RemoteException;

import com.gplocation.lbs.client.group.IGroup;
import com.gplocation.lbs.data.GroupInfo;
import com.gplocation.lbs.data.Member;
import com.gplocation.lbs.data.Setting;
import com.gplocation.lbs.datamanager.GroupSettingManager.GroupSetting;

/**
 * manage group list
 */
public class GroupManager {

    //	private static final String TAG = "groupManager";

    private ArrayList<Group> groups = new ArrayList<Group>();
    private ArrayList<DataObserver> observers = new ArrayList<DataObserver>();
    private Map<String, GroupLocation> groupLocations = new HashMap<String, GroupLocation>();
    // igroup interface
    private IGroup igroup;

    private static GroupManager groupManager;

    private GroupManager() {

    }

    public static synchronized GroupManager getInstance() {
        if (groupManager == null) {
            groupManager = new GroupManager();
        }

        return groupManager;
    }

    /**
     * <p> register observer </P>
     * 
     * @param observer
     */
    public void registerObserver(DataObserver observer) {
        this.observers.add(observer);
    }

    /**
     * compare according to groupName, make sure group Name is not empty.
     */
    public class CompareGroupInfo implements Comparator<GroupInfo> {
        @Override
        public int compare(GroupInfo object1, GroupInfo object2) {
            String account1 = object1.getGroupName();
            String account2 = object2.getGroupName();
            return account1.compareTo(account2);
        }
    }

    /**
     * <p>call observer init function, init the group member from groupInfo list</P>
     */
    public void init(IGroup igroup, GroupSettingManager groupSettingManager) {
        this.igroup = igroup;

        ArrayList<GroupInfo> groupInfoList = null;
        try {
            groupInfoList = (ArrayList<GroupInfo>) igroup.getJoinedGroups();
        } catch (RemoteException e1) {
            e1.printStackTrace();
        }

        CompareGroupInfo compareGroup = new CompareGroupInfo();
        Collections.sort(groupInfoList, compareGroup);

        for (int i = 0; i < groupInfoList.size(); ++i) {
            String groupId = groupInfoList.get(i).getGroupId();
            List<Member> members = null;
            List<Setting> settings = null;
            try {
                members = igroup.getGroupMembers(groupId);
                settings = igroup.getGroupSetting(groupId, groupId);
            } catch (RemoteException e) {
                e.printStackTrace();
            }
            Group group = new Group(groupInfoList.get(i), members);
            groups.add(group);

            GroupSetting groupSetting = new GroupSetting(groupId, groupId, settings);
            groupSettingManager.add(groupSetting);

        }

        for (int i = 0; i < observers.size(); ++i) {
            observers.get(i).init();
        }
    }

    /**
     * <p>call observer's update function</P>
     */
    public void update() {
        for (int i = 0; i < observers.size(); ++i) {
            observers.get(i).update();
        }
    }

    /**
     * <p>get groupinfo from groupId</P>
     * @param groupId
     * @return
     */
    public GroupInfo getGroupInfo(String groupId) {
        int loc = contain(groupId);

        if (loc > -1) {
            return this.groups.get(loc).getGroupInfo();
        } else {
            return null;
        }
    }

    /**
     * <p>insert a group at the location</P>
     * @param account
     * @return
     */
    private int insertGroup(String groupName) {
        if (groups.size() == 0 || groupName.compareTo(groups.get(0).getGroupInfo().getGroupName()) <= 0) {
            return 0;
        }

        for (int i = 1; i < groups.size(); ++i) {
            String friendNameBefore = groups.get(i - 1).getGroupInfo().getGroupName();
            String friendName = groups.get(i).getGroupInfo().getGroupName();
            if (groupName.compareTo(friendNameBefore) > 0 && groupName.compareTo(friendName) <= 0) {
                return i;
            }
        }

        return groups.size();
    }

    /**
     * <p>add a group</P>
     * @param groupId
     */
    public void addGroup(String groupId) {

        int loc = contain(groupId);
        if (loc < 0) {
            GroupInfo groupInfo = null;
            try {
                groupInfo = igroup.getGroupInfo(groupId);
            } catch (RemoteException e) {
                e.printStackTrace();
            }
            if (groupInfo == null) {
                groupInfo = new GroupInfo(groupId, groupId.split("@")[0], "");
            }

            Group group = new Group(groupInfo);
            int locInsert = insertGroup(group.getGroupInfo().getGroupName());
            this.groups.add(locInsert, group);

            update();
        } else {
        	if (groups.get(loc).getGroupInfo().getGroupDescription() == null) {
        		 GroupInfo groupInfo = null;
                 try {
                     groupInfo = igroup.getGroupInfo(groupId);
                 } catch (RemoteException e) {
                     e.printStackTrace();
                 }
                 
                 if (groupInfo != null) {
                	 groups.get(loc).setGroupInfo(groupInfo);
                	 
                	 update();
                 }
        	}
        }
    }

    /**
     * <p> add a member into groupmember list, add a group if the group is not exist. </P>
     * 
     * @param groupId
     * @param member
     */
    public void addMember(String groupId, Member member) {
        int[] locs = contain(groupId, member.account);
        if (locs[0] > -1) {
            groups.get(locs[0]).addMember(member);
        } else {
            GroupInfo groupInfo = null;
            try {
                groupInfo = igroup.getGroupInfo(groupId);
            } catch (RemoteException e) {
                e.printStackTrace();
            }
            if (groupInfo == null) {
                groupInfo = new GroupInfo(groupId, groupId.split("@")[0], "");
            }

            Group group = new Group(groupInfo);
            group.addMember(member);

            int insertGroup = insertGroup(group.getGroupInfo().getGroupName());
            groups.add(insertGroup, group);
        }

        update();
    }

    /**
     * <p>add a member into groupmember list, add a group if the group is not exist. </P>
     * 
     * @param groupId
     * @param memberId
     * @param memberNick
     * @param memberRole
     */
    public void addMember(String groupId, String memberId, String memberNick, String memberRole) {
        int[] locs = contain(groupId, memberId);
        if (locs[0] > -1) {
            groups.get(locs[0]).addMember(memberId, memberNick, memberRole);
        } else {
            GroupInfo groupInfo = null;
            try {
                groupInfo = igroup.getGroupInfo(groupId);
            } catch (RemoteException e) {
                e.printStackTrace();
            }

            if (groupInfo == null) {
                groupInfo = new GroupInfo(groupId, groupId.split("@")[0], "");
            }

            Group group = new Group(groupInfo);
            group.addMember(memberId, memberNick, memberRole);

            int insertGroup = insertGroup(group.getGroupInfo().getGroupName());
            groups.add(insertGroup, group);
        }

        update();
    }

    /**
     * <p> remove a group </P>
     * 
     * @param groupId
     */
    public void removeGroup(String groupId) {
        int loc = contain(groupId);
        if (loc > -1) {
            this.groups.remove(loc);
            update();
        }
    }

    /**
     * <p> remove a member, remove a group if the group is empty. </P>
     * 
     * @param groupId
     * @param memberId
     */
    public void removeMember(String groupId, String memberId) {
        int[] locs = contain(groupId, memberId);
        if (locs[0] > -1 && locs[1] > -1) {
            this.groups.get(locs[0]).getMembers().remove(locs[1]);
            if (groups.get(locs[0]).getMembers().size() == 0) {
                groups.remove(locs[0]);
            }
            update();
        }
    }

    /**
     * <p> whether contain this group </P>
     * 
     * @param groupId
     * @return
     */
    public int contain(String groupId) {
        for (int i = 0; i < groups.size(); ++i) {
            if (groups.get(i).getGroupInfo().getGroupId().equals(groupId)) {
                return i;
            }
        }

        return -1;
    }

    /**
     * <p> whether contain this group, this member </P>
     * 
     * @param groupId
     * @param memberId
     * @return int[2], int[0], group location, int[1], member location
     */
    public int[] contain(String groupId, String memberId) {
        int[] locs = new int[2];
        locs[0] = -1;
        locs[1] = -1;

        locs[0] = contain(groupId);
        if (locs[0] > -1) {
            locs[1] = this.groups.get(locs[0]).contain(memberId);
        }

        return locs;
    }

    /**
     * <p> get a gorup's member </P>
     * 
     * @param groupId
     * @return
     */
    public Group getGroup(String groupId) {
        int loc = contain(groupId);
        if (loc > -1) {
            return this.groups.get(loc);
        }

        return null;
    }

    public ArrayList<Group> getGroupMembers() {
        return groups;
    }

    public Map<String, GroupLocation> getGroupLocations() {
        return groupLocations;
    }

    public void addGroupLocation(GroupLocation groupLocation) {
        groupLocations.put(groupLocation.getGroupId(), groupLocation);
    }
}
