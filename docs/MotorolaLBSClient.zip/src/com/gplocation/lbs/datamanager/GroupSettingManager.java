// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.datamanager;

import java.util.ArrayList;
import java.util.List;

import com.gplocation.lbs.data.Setting;

/**
 * group setting data struct
 */
public class GroupSettingManager {

	public static class GroupSetting {
		public String groupId;
		public String settingName;
		public ArrayList<Setting> settingList = new ArrayList<Setting>();
		
		public GroupSetting(String groupId, String settingName, List<Setting> settings) {
			this.groupId = groupId;
			this.settingList = (ArrayList<Setting>) settings;
			this.settingName = settingName;
		}
		
		
		public String getSettingValue(String key) {
			for (int i = 0; i < settingList.size(); ++ i) {
        		if (settingList.get(i).getKey().equals(key)) {
        			return settingList.get(i).getValue();
        		}
        	}
			
			return null;
		}
		
		
		public void setSettingValue(String key, String value) {
			boolean set = false;
			
			for (int i = 0; i < settingList.size(); ++ i) {
        		if (settingList.get(i).getKey().equals(key)) {
        			settingList.get(i).setValue(value);
        			set = true;
        			break;
        		}
        	}
			
			if (!set) {
				Setting setting = new Setting(key, value, "String");
				settingList.add(setting);
			}
		}
	}

	private ArrayList<GroupSetting> groupSettings = new ArrayList<GroupSettingManager.GroupSetting>();

	private static GroupSettingManager groupSettingManager;
	
	private GroupSettingManager() {
		
	}
	
	public static synchronized GroupSettingManager getInstance() { 
		if (groupSettingManager == null) {
			groupSettingManager = new GroupSettingManager();
		}
		
		return groupSettingManager;
	}
	

	/**
	 * <p>add a group setting or update setting data if exist.</P>
	 * @param groupSetting
	 */
	public void add(GroupSetting groupSetting) {
		int loc = contain(groupSetting);
		if (loc > -1) {
			updateSetting(groupSetting);
		} else {
			groupSettings.add(groupSetting);
		}

	}

	/**
	 * <p>remove a group setting</P>
	 * @param groupSetting
	 */
	public void remove(GroupSetting groupSetting) {
		int loc = contain(groupSetting);
		if (loc > -1) {
			groupSettings.remove(loc);
		}
	}

	
	
	public GroupSetting get(String groupId, String settingName) {
		GroupSetting setting = new GroupSetting(groupId, settingName, null);
		int loc = contain(setting);
		
		if (loc > -1) {
			return this.groupSettings.get(loc);
		} else {
			return null;
		}		
	}
	
	/**
	 * <p>update the setting data</P>
	 * @param groupSetting
	 */
	public void updateSetting(GroupSetting groupSetting) {
		int loc = contain(groupSetting);
		if (loc > -1) {
			groupSettings.get(loc).settingList = groupSetting.settingList;
		}
	}

	/**
	 * <p>whether contain a group setting</P>
	 * @param groupSetting
	 * @return
	 */
	public int contain(GroupSetting groupSetting) {
		for (int i = 0; i < groupSettings.size(); ++i) {
			if (groupSettings.get(i).groupId.equals(groupSetting.groupId)
					&& groupSettings.get(i).settingName.equals(groupSetting.settingName)) {
				return i;
			}
		}

		return -1;
	}
	
	public ArrayList<GroupSetting> getGroupSettings() {
		return groupSettings;
	}

	public void setGroupSettings(ArrayList<GroupSetting> groupSettings) {
		this.groupSettings = groupSettings;
	}

}
