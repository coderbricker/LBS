package com.gplocation.lbs.datamanager;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.BaseAdapter;

import com.gplocation.lbs.data.self.ThirdApp;

public class IconManager {

	@SuppressWarnings("unused")
	private static final  String TAG = "IconManager";
	
	private static final int MAX_ICON_NUMBER = 100;
	private static final int MAX_THREAD_NUMBER = 10;

	private static IconManager iconManager;
	private Map<String, Bitmap> cachedBitmap = new HashMap<String, Bitmap>();
	private int threadNumber = 0;
	
	private IconManager() {

	}

	public static synchronized IconManager getInstance() {
		if (iconManager == null) {
			iconManager = new IconManager();
		}

		return iconManager;
	}
	
	private class DownLoadImageTask extends AsyncTask<String, Void, Bitmap> {

		private BaseAdapter adapter;
		private String appId;
		
		public DownLoadImageTask(BaseAdapter adapter, String appId) {
			this.adapter = adapter;
			this.appId = appId;
		}
		
		@Override
		protected Bitmap doInBackground(String... urls) {
			String urldisplay = urls[0];
			Bitmap icon = null;
			
			try {
				InputStream in = new java.net.URL(urldisplay).openStream();
				icon = BitmapFactory.decodeStream(in);
			} catch (Exception e) {
				Log.e("Error", e.getMessage());
				e.printStackTrace();
			}
			
			return icon;
		}
		
		@Override
		protected void onPostExecute(Bitmap result) {
			if (result != null && adapter != null) {
//				int drawableWidth = 80; 
//				int drawableHeight = 80;
////				ViewGroup.LayoutParams params = new ViewGroup.LayoutParams(drawableWidth, drawableHeight);
//				LayoutParams  params = new LayoutParams(drawableWidth, drawableHeight);
//				bmImage.setLayoutParams(params);
				
//				bmImage.setImageBitmap(result);
			}
			
			if (result != null) {
				if (cachedBitmap.size() >= MAX_ICON_NUMBER) {
					Set<String> appIds = cachedBitmap.keySet();
					cachedBitmap.remove(appIds.iterator().next());
				} 
				
				cachedBitmap.put(appId, result);
				
				if (adapter != null) {
					adapter.notifyDataSetChanged();
				}
				
			}
			
			threadNumber --;
		}
		
	}

	public Bitmap getBitmap(String appId) {
		return cachedBitmap.get(appId);
	}
	
	
	public void loadBitmap(ThirdApp app, BaseAdapter adapter) {
		Bitmap result = cachedBitmap.get(app.getAppId());
		if (result == null) {
			if (threadNumber < MAX_THREAD_NUMBER) {
				new DownLoadImageTask(adapter, app.getAppId()).execute(app.getIconLink());
				threadNumber ++;
			}
		}
	}

}
