package com.gplocation.lbs.datamanager;

/**
 * observe the data, if data changed, call update function
 */
public interface DataObserver {
	public void init();
	public void update();
}
