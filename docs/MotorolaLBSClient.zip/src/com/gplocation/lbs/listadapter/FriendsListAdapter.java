// Copyright (c) 2011-2014 gplocation Ltd. All rights reserved.
package com.gplocation.lbs.listadapter;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.os.RemoteException;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.gplocation.lbs.R;
import com.gplocation.lbs.activity.LBSClientMainActivity;
import com.gplocation.lbs.activity.ShowMapActivity;
import com.gplocation.lbs.application.MainApplication;
import com.gplocation.lbs.data.Friend;
import com.gplocation.lbs.data.GeoLocation;
import com.gplocation.lbs.datamanager.DataObserver;
import com.gplocation.lbs.datamanager.FriendManager.FriendStatus;
import com.gplocation.lbs.utils.ConstantData;

/**
 * an extend adapter for friendList
 */
public class FriendsListAdapter extends BaseAdapter implements DataObserver {

	private static final String TAG = "FriendsListAdapter";
	
	private List<Friend> friendsList = new ArrayList<Friend>();
	private List<FriendStatus> friendsStatus = new ArrayList<FriendStatus>();
	
	private Context context;

	/**
	 * Hold the controls in list item. Briefly describe what this class does.
	 */
	private class ViewHolder {
		private TextView index;
		private TextView nickName;
		private ImageView continuselySharinglocation;
		private ImageView newLocationCome;
	}

	public FriendsListAdapter(Context context) {
		this.context = context;
	}

	@Override
	public int getCount() {
		return friendsList.size();
	}

	@Override
	public Object getItem(int position) {
		return friendsList.get(position);
	}

	
	
	private class LocationClickListener implements View.OnClickListener {
		private int position;
		public LocationClickListener(int position) {
			this.position = position;
		}

		@Override
		public void onClick(View v) {
			GeoLocation location = friendsStatus.get(position).location;
			if (location != null) {
				friendsStatus.get(position).locationCome = false;
				notifyDataSetChanged();

				Intent intent = new Intent(context, ShowMapActivity.class);
				intent.putExtra("account", friendsList.get(position)
						.getAccount());
				intent.putExtra("nick", friendsList.get(position)
						.getNickName());
				intent.putExtra("location", location);
				try {
					((LBSClientMainActivity) (context)).startActivityForResult(
							intent, ConstantData.REQUEST_MAP_ACTIVITY);
				} catch (Exception e) {
					Toast.makeText(context, e.getMessage(), Toast.LENGTH_LONG)
							.show();
				}
			}
		}
		
	}
	
	/**
	 * rewrite for a new view needed by friendlist
	 * 
	 * @see android.widget.Adapter#getView(int, android.view.View,
	 *      android.view.ViewGroup)
	 */
	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		final ViewHolder holder;
		if (convertView == null) {
			convertView = LayoutInflater.from(context).inflate(R.layout.list_item, null);

			holder = new ViewHolder();
			holder.index = (TextView) convertView.findViewById(R.id.index);
			holder.nickName = (TextView) convertView.findViewById(R.id.nickName);
			holder.continuselySharinglocation = (ImageView) convertView.findViewById(R.id.continue_sharing_location);
			holder.newLocationCome = (ImageView) convertView.findViewById(R.id.new_location_com);

			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}

		final Friend friendDomain = friendsList.get(position);

		
		String presence = friendDomain.getPresence();
		if (presence.equals("unavailable")) {
			holder.nickName.setTextColor(0xff7e7e7e);
		} else {
			Resources resources = (Resources) ((ContextWrapper) context).getBaseContext().getResources(); 
			ColorStateList csl = (ColorStateList) resources.getColorStateList(R.color.friend_nick_name_selector);  
			if (csl != null) {
				holder.nickName.setTextColor(csl);
			}
		}

		holder.nickName.setText(friendDomain.getNickName());
		if (position == 0 || friendDomain.getNickName().charAt(0) 
				!= friendsList.get(position - 1).getNickName().charAt(0)) {
			holder.index.setText(String.valueOf(friendDomain.getNickName().charAt(0)).toUpperCase());
			holder.index.setVisibility(View.VISIBLE);
		} else {
			holder.index.setVisibility(View.GONE);
		}
		

		// not handle yet
		holder.continuselySharinglocation.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				friendsStatus.get(position).shareContinuous = false;
				notifyDataSetChanged();
				
				try {
					((LBSClientMainActivity) context).iFriend.stopSharingLoaction(
							friendsList.get(position).getAccount());
				} catch (RemoteException e) {
					e.printStackTrace();
				}
			}
		});

		
		if (friendsStatus.get(position).shareContinuous) {
			holder.continuselySharinglocation.setVisibility(View.VISIBLE);
		} else {
			holder.continuselySharinglocation.setVisibility(View.GONE);
		}
		if (friendsStatus.get(position).locationCome) {
			holder.newLocationCome.setVisibility(View.VISIBLE);
		} else {
			holder.newLocationCome.setVisibility(View.GONE);
		}

		holder.newLocationCome.setOnClickListener(new LocationClickListener(position));

		return convertView;
	}

	/**
	 * update date for adapter
	 * 
	 * @param rosters, the new date source for the adapter
	 */
	public void updateData(ArrayList<Friend> rosters) {
		if (friendsList == null) {
			friendsList = new ArrayList<Friend>();
		}
		friendsList.clear();

		for (Friend friend : rosters) {
			friendsList.add(friend);
		}

		this.notifyDataSetChanged();

	}

	public void setFriendsList(List<Friend> friendsList) {
		this.friendsList = friendsList;
	}

	public List<Friend> getFriendsList() {
		return friendsList;
	}

	@Override
	public void init() {
		Log.d(TAG, "init");
		MainApplication mainApplication = (MainApplication) ((LBSClientMainActivity) context)
				.getApplication();
		friendsList = mainApplication.friendManager.getFriendList();
		friendsStatus = mainApplication.friendManager.getFriendStatus();
		this.notifyDataSetChanged();
	}

	@Override
	public void update() {
		Log.d(TAG, "update");
		this.notifyDataSetChanged();
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	public List<FriendStatus> getFriendsStatus() {
		return friendsStatus;
	}

	public void setFriendsStatus(List<FriendStatus> friendsStatus1) {
		this.friendsStatus = friendsStatus1;
	}

}
