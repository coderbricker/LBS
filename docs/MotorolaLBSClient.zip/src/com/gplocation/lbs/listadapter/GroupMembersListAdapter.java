package com.gplocation.lbs.listadapter;

import java.util.ArrayList;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.os.RemoteException;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.gplocation.lbs.R;
import com.gplocation.lbs.activity.LBSClientMainActivity;
import com.gplocation.lbs.application.MainApplication;
import com.gplocation.lbs.data.LBSUser;
import com.gplocation.lbs.data.Member;
import com.gplocation.lbs.datamanager.DataObserver;
import com.gplocation.lbs.datamanager.Group;

/**
 * an extend adapter for grouplist
 */
public class GroupMembersListAdapter extends BaseAdapter implements DataObserver {

    private static final String TAG = "GroupListAdapter";

    private ArrayList<Member> members = new ArrayList<Member>();
    private Context context;
    private Group group;
    private LBSUser user;
    private String groupId;

    public GroupMembersListAdapter(String groupId, Context context) {
        MainApplication mainApplication = (MainApplication) ((LBSClientMainActivity) context).getApplication();
        this.group = mainApplication.groupManager.getGroup(groupId);
        this.members = this.group.getMembers();
        this.context = context;
        this.user = ((MainApplication) ((LBSClientMainActivity) context)
        		.getApplication()).userInfo;
        this.groupId = groupId;
    }

    /**
     * @see com.gplocation.lbs.datamanager.DataObserver#init()
     */
    @Override
    public void init() {
        Log.d(TAG, "init");
    }

    /**
     * @see com.gplocation.lbs.datamanager.DataObserver#update()
     */
    @Override
    public void update() {
        Log.d(TAG, "update");
        this.notifyDataSetChanged();
    }

    
    @Override
    public View getView(int arg0, View arg1, ViewGroup arg2) {
        LayoutInflater inflater = ((LBSClientMainActivity) context).getLayoutInflater();
        View convertView = inflater.inflate(R.layout.group_members_list_adapter, null);

        ImageView owner = (ImageView) convertView.findViewById(R.id.group_members_owner);
        ImageView remove = (ImageView) convertView.findViewById(R.id.group_members_remove);
        ArrayList<String> groupOwners = group.getOwners();
        
        if (groupOwners != null && groupOwners.contains(user.getUserId())) {
            owner.setVisibility(View.VISIBLE);
            remove.setVisibility(View.VISIBLE);
        }
        if (groupOwners != null && !groupOwners.contains(members.get(arg0).account)) {
            owner.setBackgroundResource(R.drawable.group_owner_set_icon);
        }
        
        TextView merber = (TextView) convertView.findViewById(R.id.group_members_name);
//        merber.setText("Hello");
        
        final String memberNick = members.get(arg0).nick;
        final String memberId = members.get(arg0).account;
        merber.setText(memberNick);
        
        owner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                if (user.getNick().contains(memberNick)) { //if the member operated is self
                    
                    final Dialog tempDialog = new Dialog(context, R.style.Dialog_No_Title);
                    LayoutInflater inflater1 = ((Activity) context).getLayoutInflater();
                    View dialogView = inflater1.inflate(R.layout.dialog, null);
                    TextView dialogTitle = (TextView) dialogView.findViewById(R.id.dialog_title);
                    TextView dialogMessage = (TextView) dialogView.findViewById(R.id.dialog_message);
                    View dialogLayoutTwoButton = dialogView.findViewById(R.id.dialog_layout_two_button);
                    Button dialogSignleOk = (Button) dialogView.findViewById(R.id.dialog_signle_ok_btn);

                    dialogTitle.setText(R.string.Prompt);
                    dialogMessage.setText(R.string.can_not_do_this_on_their_own);
                    dialogLayoutTwoButton.setVisibility(View.GONE);
                    dialogSignleOk.setVisibility(View.VISIBLE);
                    dialogSignleOk.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View arg0) {
                            if (tempDialog != null && tempDialog.isShowing()) {
                                tempDialog.dismiss();
                            }
                        }
                    });
                    tempDialog.setContentView(dialogView);
                    tempDialog.setCancelable(false);
                    tempDialog.show();
                    
                } else { //if the member operated is not self
                    if (group.getOwners() != null && group.getOwners().contains(memberId)) {
                        //if the member operated is owner
                        
                        final Dialog tempDialog = new Dialog(context, R.style.Dialog_No_Title);
                        LayoutInflater inflater1 = ((Activity) context).getLayoutInflater();
                        View dialogView = inflater1.inflate(R.layout.dialog, null);
                        TextView dialogTitle = (TextView) dialogView.findViewById(R.id.dialog_title);
                        TextView dialogMessage = (TextView) dialogView.findViewById(R.id.dialog_message);
                        View dialogLayoutTwoButton = dialogView.findViewById(R.id.dialog_layout_two_button);
                        Button dialogSignleOk = (Button) dialogView.findViewById(R.id.dialog_signle_ok_btn);

                        dialogTitle.setText(R.string.Prompt);
                        dialogMessage.setText(R.string.the_member_is_owner);
                        dialogLayoutTwoButton.setVisibility(View.GONE);
                        dialogSignleOk.setVisibility(View.VISIBLE);
                        dialogSignleOk.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View arg0) {
                                if (tempDialog != null && tempDialog.isShowing()) {
                                    tempDialog.dismiss();
                                }
                            }
                        });
                        tempDialog.setContentView(dialogView);
                        tempDialog.setCancelable(false);
                        tempDialog.show();
                        
                    } else { //if the member operated is not owner
                        try {
                            ((LBSClientMainActivity) context).iOperateGroup.setMembersAsOwner(groupId, 
                            		memberId);
                        } catch (RemoteException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        });
        remove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (user.getUserId().contains(memberNick)) { //if the member operated is self
                    final Dialog tempDialog = new Dialog(context, R.style.Dialog_No_Title);
                    LayoutInflater inflater1 = ((Activity) context).getLayoutInflater();
                    View dialogView = inflater1.inflate(R.layout.dialog, null);
                    TextView dialogTitle = (TextView) dialogView.findViewById(R.id.dialog_title);
                    TextView dialogMessage = (TextView) dialogView.findViewById(R.id.dialog_message);
                    View dialogLayoutTwoButton = dialogView.findViewById(R.id.dialog_layout_two_button);
                    Button dialogSignleOk = (Button) dialogView.findViewById(R.id.dialog_signle_ok_btn);

                    dialogTitle.setText(R.string.Prompt);
                    dialogMessage.setText(R.string.can_not_do_this_on_their_own);
                    dialogLayoutTwoButton.setVisibility(View.GONE);
                    dialogSignleOk.setVisibility(View.VISIBLE);
                    dialogSignleOk.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View arg0) {
                            if (tempDialog != null && tempDialog.isShowing()) {
                                tempDialog.dismiss();
                            }
                        }
                    });
                    tempDialog.setContentView(dialogView);
                    tempDialog.setCancelable(false);
                    tempDialog.show();
                } else { //if the member operated is not self

                    
                    final Dialog tempDialog = new Dialog(context, R.style.Dialog_No_Title);
                    LayoutInflater inflater = ((Activity) context).getLayoutInflater();
                    View dialogView = inflater.inflate(R.layout.dialog, null);
                    TextView dialogTitle = (TextView) dialogView.findViewById(R.id.dialog_title);
                    TextView dialogMessage = (TextView) dialogView.findViewById(R.id.dialog_message);
                    Button dialogOk = (Button) dialogView.findViewById(R.id.dialog_ok);
                    Button dialogCancel = (Button) dialogView.findViewById(R.id.dialog_cancel);

                    dialogTitle.setText(R.string.Prompt);
                    dialogMessage.setText(String.format(context.getString(
                    		R.string.are_you_sure_remove_member), memberNick));
                    dialogOk.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View arg0) {
                            try {
                                ((LBSClientMainActivity) context).iOperateGroup.removeMember(groupId,
                                    memberNick + "@motolbs.com", memberNick);
                            } catch (RemoteException e) {
                                e.printStackTrace();
                            }
                            if (tempDialog != null && tempDialog.isShowing()) {
                                tempDialog.dismiss();
                            }
                        }
                    });
                    dialogCancel.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View arg0) {
                            if (tempDialog != null && tempDialog.isShowing()) {
                                tempDialog.dismiss();
                            }
                        }
                    });
                    tempDialog.setContentView(dialogView);
                    tempDialog.setCancelable(false);
                    tempDialog.show();
                }
            }
        });
        
        return convertView;
    }

    @Override
    public int getCount() {
//    	return 10;
        return members.size();
    }

    @Override
    public Object getItem(int arg0) {
        return members.get(arg0);
    }

    @Override
    public long getItemId(int arg0) {
        return arg0;
    }

}
