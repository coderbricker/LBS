package com.gplocation.lbs.listadapter;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.gplocation.lbs.R;

public class FriendDetailAdapter extends BaseAdapter {
	
	private Context context;
	private ArrayList<Drawable> icons = new ArrayList<Drawable>(); 
	private ArrayList<String> texts = new ArrayList<String>(); 
	private ArrayList<Boolean> check = new ArrayList<Boolean>();
	
	public FriendDetailAdapter(Context context) {
		this.context = context;
		
		icons.add(context.getResources().getDrawable(R.drawable.share_location_icon));
		icons.add(context.getResources().getDrawable(R.drawable.request_location_icon));
		icons.add(context.getResources().getDrawable(R.drawable.location_tracking_icon));
		icons.add(context.getResources().getDrawable(R.drawable.location_continuously_icon));
		
		texts.add(context.getString(R.string.menu_share_location));
		texts.add(context.getString(R.string.menu_request_location));
		texts.add(context.getString(R.string.menu_follow_location));
		texts.add(context.getString(R.string.menu_share_continuously_location));
		
		for (int i = 0; i < 4; ++ i) {
			check.add(false);
		}
	}

	@Override
	public int getCount() {
		return 4;
	}

	@Override
	public Object getItem(int position) {
		return null;
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	public void setFollowCheck(boolean check) {
		this.check.set(2, check);
		notifyDataSetChanged();
	}
	
	public boolean getFollowCheck() {
		return this.check.get(2);
	}
	
	
	
	public void setShareContinuouslyCheck(boolean check) {
		this.check.set(3, check);
		notifyDataSetChanged();
	}
	
	/**
	 * Hold the controls in list item. Briefly describe what this class does.
	 */
	private class ViewHolder {
		private TextView menu;
		private ImageView icon;
		private ImageView check;
	}
	
	
	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		final ViewHolder holder;
		if (convertView == null) {
			convertView = LayoutInflater.from(context).inflate(R.layout.friend_detail_list_item, null);

			holder = new ViewHolder();
			holder.menu = (TextView) convertView.findViewById(R.id.friend_menu_list_text);
			holder.icon = (ImageView) convertView.findViewById(R.id.friend_menu_list_icon);
			holder.check = (ImageView) convertView.findViewById(R.id.friend_menu_list_check);

			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		
		if (position == 0 || position == 1) {
			holder.check.setVisibility(View.GONE);
		} else {
			holder.check.setVisibility(View.VISIBLE);
			if (check.get(position)) {
				holder.check.setBackgroundResource(R.drawable.checkbox_selected);
			} else {
				holder.check.setBackgroundResource(R.drawable.checkbox);
			}
		}
		
		holder.menu.setText(texts.get(position));
		holder.icon.setBackgroundDrawable(icons.get(position));
		
		return convertView;
	}

}
