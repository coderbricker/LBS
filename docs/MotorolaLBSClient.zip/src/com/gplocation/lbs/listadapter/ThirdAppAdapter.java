package com.gplocation.lbs.listadapter;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.gplocation.lbs.R;
import com.gplocation.lbs.activity.LBSClientMainActivity;
import com.gplocation.lbs.application.MainApplication;
import com.gplocation.lbs.data.self.ThirdApp;
import com.gplocation.lbs.datamanager.DataObserver;
import com.gplocation.lbs.utils.Utils;

public class ThirdAppAdapter extends BaseAdapter implements DataObserver {

	private static final String TAG = "ThirdAppAdapter";
	private ArrayList<ThirdApp> apps = new ArrayList<ThirdApp>();
	private ArrayList<Boolean> installStatus = new ArrayList<Boolean>();
	
	private Context context;
	
	/**
	 * Hold the controls in list item. Briefly describe what this class does.
	 */
	private class ViewHolder {
		private ImageView icon;
		private TextView installTip;
		private TextView name;
		@SuppressWarnings("unused")
		private ImageView star;
		private ImageView tip;
	}
	
	public ThirdAppAdapter(Context context) {
		this.context = context;
	}
	
	
	@Override
	public int getCount() {
		return apps.size();
	}

	@Override
	public Object getItem(int position) {
		return apps.get(position);
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		
		Log.d(TAG, "getView");
		
		final ViewHolder holder;
		if (convertView == null) {
			convertView = LayoutInflater.from(context).inflate(R.layout.app_list_item, null);

			holder = new ViewHolder();
			holder.icon = (ImageView) convertView.findViewById(R.id.app_icon);
			holder.installTip = (TextView) convertView.findViewById(R.id.app_install_tip);
			holder.name = (TextView) convertView.findViewById(R.id.app_name);
			holder.star = (ImageView) convertView.findViewById(R.id.app_star);
			holder.tip = (ImageView) convertView.findViewById(R.id.app_tip);

			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		
		holder.name.setText(apps.get(position).getAppName());
		
		if (installStatus.get(position)) {
			holder.installTip.setText(R.string.app_installed);
		} else {
			holder.installTip.setText("");
		}
		
		boolean showNew = false;
		if (installStatus.get(position)) {
			String installVersion = (String) ((MainApplication) ((LBSClientMainActivity) context).getApplication())
					.thirdAppManager.getInstalledApps().get(position).get(Utils.INSTALLEDAPPSMAPVERSION);
			if (installVersion.compareToIgnoreCase(apps.get(position).getVersion()) < 0) {
				showNew = true;
			}
		}
		
		if (showNew) {
			holder.tip.setVisibility(View.VISIBLE);
		} else {
			holder.tip.setVisibility(View.GONE);
		}
		
		Bitmap bitmap = ((MainApplication) ((LBSClientMainActivity) context).getApplication())
				.iconManager.getBitmap(apps.get(position).getAppId());
		if (bitmap == null) {
			holder.icon.setImageResource(R.drawable.icon);
			
			((MainApplication) ((LBSClientMainActivity) context).getApplication())
			.iconManager.loadBitmap(apps.get(position), this);
		} else {
			holder.icon.setImageBitmap(bitmap);
		}
		
//		new DownLoadImageTask(holder.icon).execute("http://www.51freesky.com/uploads/allimg/101221/13022N000-3.jpg");
		
		
		
		
		return convertView;
	}

	public ArrayList<ThirdApp> getApps() {
		return apps;
	}

	public void setApps(ArrayList<ThirdApp> apps) {
		this.apps = apps;
	}


	@Override
	public void init() {
		
	}


	@Override
	public void update() {
		
		Log.d(TAG, "installStatus update");
		MainApplication mainApplication = (MainApplication) ((LBSClientMainActivity) context).getApplication();
		this.apps = mainApplication.thirdAppManager.getApps();
		this.installStatus = mainApplication.thirdAppManager.getInstalledThirdApps();
		
		if (installStatus.size() > 0) {
			Log.d(TAG, "installStatus=" + installStatus.get(0));
		}
		
		notifyDataSetChanged();
	}


	public ArrayList<Boolean> getInstallStatus() {
		return installStatus;
	}


	public void setInstallStatus(ArrayList<Boolean> installStatus1) {
		this.installStatus = installStatus1;
	}
	
}
