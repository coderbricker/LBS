package com.gplocation.lbs.listadapter;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.gplocation.lbs.R;
import com.gplocation.lbs.activity.GroupShowMapActivity;
import com.gplocation.lbs.activity.LBSClientMainActivity;
import com.gplocation.lbs.application.MainApplication;
import com.gplocation.lbs.datamanager.DataObserver;
import com.gplocation.lbs.datamanager.Group;
import com.gplocation.lbs.datamanager.GroupLocation;

/**
 * an extend adapter for grouplist
 */
public class GroupListAdapter extends BaseAdapter implements DataObserver {

    private static final String TAG = "GroupListAdapter";

    private ArrayList<Group> groupMembers = new ArrayList<Group>();
    private Context context;

    public GroupListAdapter(Context context) {
        this.context = context;
    }

    /**
     * @see com.gplocation.lbs.datamanager.DataObserver#init()
     */
    @Override
    public void init() {
        Log.d(TAG, "init");
        MainApplication mainApplication = (MainApplication) ((LBSClientMainActivity) context).getApplication();
        this.groupMembers = mainApplication.groupManager.getGroupMembers();
        this.notifyDataSetChanged();
    }

    /**
     * @see com.gplocation.lbs.datamanager.DataObserver#update()
     */
    @Override
    public void update() {
        Log.d(TAG, "update");
        this.notifyDataSetChanged();
    }

    public ArrayList<Group> getGroupMembers() {
        return groupMembers;
    }

    public void setGroupMembers(ArrayList<Group> groupMembers1) {
        this.groupMembers = groupMembers1;
    }

    @Override
    public int getCount() {
        return groupMembers.size();
    }

    @Override
    public Object getItem(int arg0) {
        return groupMembers.get(arg0);
    }

    @Override
    public long getItemId(int arg0) {
        return arg0;
    }

    @Override
    public View getView(int arg0, View arg1, ViewGroup arg2) {
        LayoutInflater inflater = ((LBSClientMainActivity) context).getLayoutInflater();
        View convertView = inflater.inflate(R.layout.group_list_adapter, null);

        TextView groupName = (TextView) convertView.findViewById(R.id.group_list_adapter_textview);
        groupName.setText(groupMembers.get(arg0).getGroupInfo().getGroupName());
        final String groupId = groupMembers.get(arg0).getGroupInfo().getGroupId();

        GroupLocation groupLocation = ((MainApplication) (((Activity) context).getApplication())).groupManager
            .getGroupLocations().get(groupId);

        if (groupMembers.get(arg0).isNewLocationCome() || (groupLocation != null && groupLocation.isNewLocation())) {
            ImageView shareState = (ImageView) convertView.findViewById(R.id.group_list_adapter_sharestate);
            shareState.setVisibility(ImageView.VISIBLE);
            
            final int loc = arg0;
            shareState.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                	groupMembers.get(loc).setNewLocationCome(!groupMembers.get(loc).isNewLocationCome());
                	
                    Intent intent = new Intent(context, GroupShowMapActivity.class);
                    intent.putExtra("groupId", groupId);
                    try {
                        ((Activity) (context)).startActivity(intent);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
        }
        return convertView;
    }

}
