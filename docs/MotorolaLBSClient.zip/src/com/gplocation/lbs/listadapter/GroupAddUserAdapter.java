package com.gplocation.lbs.listadapter;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.gplocation.lbs.R;
import com.gplocation.lbs.datamanager.GroupAddUser;

/**
 * an extend adapter for grouplist
 */
public class GroupAddUserAdapter extends BaseAdapter {

    @SuppressWarnings("unused")
	private static final String TAG = "GroupListAdapter";

    private List<GroupAddUser> addUsers;
    private Context context;

    public GroupAddUserAdapter(List<GroupAddUser> addUsers, Context context) {
        if (addUsers != null) {
            this.addUsers = addUsers;
        } else {
            this.addUsers = new ArrayList<GroupAddUser>();
        }
        this.context = context;
    }

    @Override
    public int getCount() {
        return addUsers.size();
    }

    @Override
    public Object getItem(int arg0) {
        return addUsers.get(arg0);
    }

    @Override
    public long getItemId(int arg0) {
        return arg0;
    }
    
    
    private class ViewHolder {
		private TextView userName;
		private ImageView checkBox;
	}

    @Override
    public View getView(int arg0, View convertView, ViewGroup arg2) {
    	final ViewHolder holder;
    	if (convertView == null) {
			convertView = LayoutInflater.from(context).inflate(R.layout.group_add_user_adapter, null);

			holder = new ViewHolder();
			holder.userName = (TextView) convertView.findViewById(R.id.group_add_user_adapter_textview);
			holder.checkBox = (ImageView) convertView.findViewById(R.id.group_add_user_adapter_check);

			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
    	
        final GroupAddUser addUser = addUsers.get(arg0);

        holder.userName.setText(addUser.getFriend().getNickName());
        
        if (addUser.isInvite()) {
        	holder.checkBox.setBackgroundResource(R.drawable.checkbox_selected);
        } else {
        	holder.checkBox.setBackgroundResource(R.drawable.checkbox);
        }
        
//        convertView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View arg0) {
//                if (addUser.isInvite()) {
//                	holder.checkBox.setBackgroundResource(R.drawable.checkbox);
//                    addUser.setInvite(false);
//                } else {
//                	holder.checkBox.setBackgroundResource(R.drawable.checkbox_selected);
//                    addUser.setInvite(true);
//                }
//
//            }
//        });

        return convertView;
    }

}
